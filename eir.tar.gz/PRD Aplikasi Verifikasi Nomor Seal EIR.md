# PRD — Aplikasi Verifikasi Nomor Seal EIR

**Versi 1.0 (Draft) · 15 Oktober 2026 · PT. NX Lemo Indonesia Logistik**

## 1. Ringkasan

Aplikasi web seluler (PWA) untuk memverifikasi kesesuaian **nomor seal pada dokumen EIR (Equipment Interchange Receipt)** dengan **nomor segel aktual** yang terpasang di container. Petugas memotret segel memakai kamera HP, sistem membaca nomornya dengan OCR, lalu membandingkannya dengan nomor di EIR. Hasil ditampilkan jelas: **hijau (Success / Sesuai)** atau **merah (Failed / Tidak Sesuai)**.

### 1.1 Latar Belakang dan Masalah

- Pencocokan nomor seal EIR dengan segel fisik dilakukan manual (mata dan tangan), sehingga rawan salah baca, lambat, dan tidak meninggalkan bukti.
- Ketidaksesuaian seal yang terlambat diketahui dapat memicu klaim, sengketa, dan temuan audit.
- Belum ada jejak digital (siapa, kapan, hasil, foto) untuk setiap pemeriksaan.

### 1.2 Tujuan

1. Mempercepat pemeriksaan seal di lapangan.
2. Mengurangi kesalahan pembacaan manual.
3. Menyimpan bukti foto dan log pemeriksaan yang dapat diaudit.

### 1.3 Indikator Keberhasilan

| Indikator | Target awal |
| --- | --- |
| Waktu satu pemeriksaan (dari buka kamera sampai hasil) | ≤ 30 detik |
| Akurasi OCR nomor seal (setelah preprocessing, sebelum koreksi manual) | ≥ 85% pada uji lapangan, ditinjau ulang setelah fase pilot |
| Pemeriksaan yang memiliki foto bukti | 100% |
| Ketersediaan sistem jam operasional | ≥ 99% |

## 2. Ruang Lingkup

**Termasuk (In Scope)**

- Login dan manajemen pengguna (Master User, Master Role).
- Input nomor seal EIR (OCR dokumen atau ketik manual).
- Pembacaan nomor segel aktual via kamera HP (OCR).
- Pencocokan otomatis dan tampilan hasil hijau/merah.
- Koreksi manual hasil OCR dan foto ulang.
- Riwayat pemeriksaan, pencarian, filter, dan rekap ke Excel sebagai catatan jangka panjang sebelum data dihapus (retensi 24 jam).
- Log audit.

**Tidak Termasuk (Out of Scope) untuk versi 1.0**

- Integrasi langsung ke aplikasi freight internal atau SAP.
- Aplikasi native Android/iOS (memakai PWA).
- Pembacaan barcode/QR segel (dapat dipertimbangkan fase berikutnya).
- Mode offline penuh.

## 3. Pengguna dan Peran

| Role | Deskripsi | Kebutuhan utama |
| --- | --- | --- |
| Admin | Pengelola sistem | Kelola user dan role, lihat semua data, pengaturan |
| Supervisor | Penanggung jawab lokasi/cabang | Pantau hasil pemeriksaan, tinjau kasus Failed, export laporan |
| Operator | Petugas lapangan (depo/terminal) | Scan dan cocokkan seal, lihat riwayat sendiri |

Hak akses detail ada di Lampiran A. Hak akses bersifat dapat diatur lewat Master Role.

## 4. Alur Proses Utama

1. Operator login (HP).
2. Operator memilih **Pemeriksaan Baru**.
3. **Langkah 1 — Nomor Seal EIR:** operator memotret dokumen EIR (OCR) atau mengetik manual. Sistem menampilkan hasil baca, operator mengonfirmasi atau mengedit.
4. **Langkah 2 — Segel Aktual:** operator memotret segel di container dengan bantuan kotak panduan di kamera. Sistem menampilkan hasil baca, operator mengonfirmasi atau mengedit/foto ulang.
5. Sistem **menormalisasi** kedua nomor lalu **membandingkan**.
6. Sistem menampilkan hasil:
   - **Sama → layar hijau, pesan "Success / Sesuai"**
   - **Berbeda → layar merah, pesan "Failed / Tidak Sesuai"**
7. Sistem menyimpan log pemeriksaan beserta foto.
8. Operator memilih **Pemeriksaan Baru** atau **Lihat Detail**.

## 5. Kebutuhan Fungsional

### 5.1 Autentikasi dan Master User

| ID | Kebutuhan | Prioritas |
| --- | --- | --- |
| SEAL-01 | Login dengan username dan password; sesi berbasis token (JWT) dengan masa berlaku yang dapat diatur | Must |
| SEAL-02 | Master User: tambah, ubah, lihat, dan nonaktifkan user (soft delete, tidak dihapus permanen karena terkait log) | Must |
| SEAL-03 | Field user: ID karyawan, nama lengkap, email, username, password, role, lokasi/cabang, status aktif | Must |
| SEAL-04 | Reset password oleh Admin; wajib ganti password saat login pertama | Must |
| SEAL-05 | Pencarian dan filter user (nama, username, role, lokasi, status) | Must |
| SEAL-06 | Master Role dengan hak akses per fitur (lihat Lampiran A) | Must |
| SEAL-07 | User sendiri dapat mengubah password dan melihat profil | Should |
| SEAL-08 | Kunci akun sementara setelah beberapa kali gagal login | Should |

### 5.2 Pemeriksaan Seal

| ID | Kebutuhan | Prioritas |
| --- | --- | --- |
| SEAL-11 | Akses kamera belakang HP langsung dari browser, dengan kotak panduan yang wajib dipakai: gambar dipotong (crop) sesuai kotak sebelum OCR karena foto penuh tidak terbaca, serta tombol flash bila perangkat mendukung | Must |
| SEAL-12 | Input nomor seal EIR melalui foto dokumen EIR berbentuk kertas (OCR) atau ketik manual | Must |
| SEAL-13 | Input segel aktual melalui foto segel dan OCR | Must |
| SEAL-14 | Hasil OCR ditampilkan dalam field yang dapat diedit sebelum dibandingkan; wajib ada tombol **Foto Ulang** | Must |
| SEAL-15 | Normalisasi dan pencocokan otomatis (lihat Bagian 6) | Must |
| SEAL-16 | Tampilan hasil layar penuh: **hijau + "Success / Sesuai"** atau **merah + "Failed / Tidak Sesuai"**, dengan menampilkan kedua nomor berdampingan | Must |
| SEAL-17 | Field opsional: nomor container, nomor EIR, nomor booking/BL, catatan | Must |
| SEAL-18 | Penyimpanan otomatis: foto EIR, foto segel, hasil OCR mentah, nomor final, hasil, user, waktu, lokasi | Must |
| SEAL-19 | Penanda bila nomor final berbeda dari hasil OCR mentah (diedit manual) agar dapat ditinjau | Should |
| SEAL-20 | Peringatan "hampir sama" bila selisih hanya 1–2 karakter mirip (mis. O/0), agar operator memeriksa ulang sebelum hasil final | Should |
| SEAL-29 | Deteksi orientasi otomatis: foto EIR dan segel sering miring, sehingga sistem mencoba rotasi 0°, 90°, 180°, dan 270° lalu memilih hasil yang paling cocok dengan pola alfanumerik 6–10 karakter | Must |
| SEAL-30 | Pembacaan barcode pada segel yang berbarcode (saat ini hanya segel Evergreen): bila barcode terbaca, nilainya dipakai sebagai hasil baca utama dan OCR menjadi cadangan; segel pelayaran lain tidak berbarcode sehingga hanya memakai OCR | Should |

### 5.3 Riwayat, Laporan, dan Audit

| ID | Kebutuhan | Prioritas |
| --- | --- | --- |
| SEAL-22 | Daftar riwayat pemeriksaan dengan filter tanggal, hasil, lokasi, user, nomor container/EIR | Must |
| SEAL-23 | Halaman detail pemeriksaan: nomor, hasil, foto, dan metadata | Must |
| SEAL-24 | Rekap ke Excel (.xlsx) sebagai catatan jangka panjang, mengikuti filter yang aktif, berisi waktu, user, nomor EIR, nomor container, nomor seal EIR dan segel aktual (final), hasil, dan penanda diedit; export harus dilakukan sebelum data dihapus otomatis (24 jam) | Must |
| SEAL-25 | Dashboard ringkas: jumlah pemeriksaan, persentase Sesuai/Tidak Sesuai, untuk data hari berjalan | Should |
| SEAL-26 | Supervisor dapat menambahkan catatan tindak lanjut pada kasus Failed | Could |
| SEAL-27 | Log audit perubahan master user dan role (siapa, kapan, apa yang berubah); tidak dihapus otomatis dan hanya dapat dihapus manual oleh Admin (lihat SEAL-31) | Must |
| SEAL-28 | Penghapusan otomatis: foto dan log pemeriksaan dihapus 1 hari (24 jam) setelah dibuat lewat job terjadwal; file foto di disk dan baris database ikut dihapus; audit log perubahan user dikecualikan | Must |
| SEAL-31 | Clear log audit: Admin dapat menghapus log audit secara manual lewat opsi Clear Log dengan konfirmasi; peran lain tidak memiliki opsi ini | Should |

## 6. Aturan Bisnis Pencocokan

1. **Normalisasi** sebelum membandingkan: ubah ke huruf besar; hapus spasi, tanda hubung, titik, dan karakter non-alfanumerik.
2. **Pencocokan** dilakukan pada nilai yang sudah dinormalisasi dan dikonfirmasi operator. Hasil **Sesuai** hanya bila kedua string identik.
3. **Koreksi karakter mirip** (O↔0, I↔1, S↔5, B↔8, Z↔2, 9↔S, 9↔G) **tidak** dipakai untuk meloloskan hasil. Fungsinya hanya memberi peringatan "hampir sama" (SEAL-20); keputusan akhir tetap pada operator dan sistem tidak otomatis menyatakan Sesuai.
4. Pengeditan manual hasil OCR dicatat (nilai OCR mentah vs nilai final) untuk audit.
5. Hasil pemeriksaan yang sudah disimpan **tidak dapat diubah**; koreksi dilakukan dengan membuat pemeriksaan baru, dengan referensi ke pemeriksaan sebelumnya.
6. Format nomor seal tidak resmi: alfanumerik, panjang 6–10 karakter, dan berbeda tiap pelayaran. Validasi hanya memeriksa karakter alfanumerik dan panjang 6–10; di luar itu sistem memberi peringatan, bukan penolakan, dan tidak ada aturan prefix.

## 7. Desain Antarmuka (Ringkas)

| Layar | Isi utama |
| --- | --- |
| Login | Username, password |
| Beranda | Tombol besar **Pemeriksaan Baru**, ringkasan pemeriksaan hari ini, akses riwayat |
| Kamera EIR / Segel | Tampilan kamera penuh, kotak panduan, tombol ambil foto, flash, ganti ke input manual |
| Konfirmasi OCR | Foto hasil crop, field hasil baca yang dapat diedit, tombol Foto Ulang dan Lanjut |
| **Hasil** | **Layar penuh hijau/merah**, ikon, pesan **Success / Sesuai** atau **Failed / Tidak Sesuai**, nomor EIR vs nomor aktual berdampingan |
| Riwayat dan Detail | Tabel/daftar dengan filter, detail dengan foto |
| Master User dan Role | Tabel dengan pencarian, form tambah/ubah, reset password |

Prinsip UI: layar hasil harus terbaca dari jarak dan di bawah sinar matahari (kontras tinggi, huruf besar); tombol besar untuk dipakai satu tangan; tema responsif untuk HP, dengan tabel master user tetap nyaman dipakai di desktop. Warna tidak boleh menjadi satu-satunya penanda hasil: selalu disertai ikon dan teks.

## 8. Arsitektur dan Tech Stack

| Layer | Teknologi |
| --- | --- |
| Frontend | React (PWA) + Tailwind CSS |
| Backend | Python FastAPI (Uvicorn/Gunicorn) |
| Database | PostgreSQL |
| OCR | Tesseract (pytesseract) dengan preprocessing OpenCV |
| Web server | Nginx (reverse proxy + file statis + HTTPS) |
| Penyimpanan foto | Volume disk lokal di VPS (dapat dipindah ke object storage) |
| Deployment | Docker Compose pada **1 VPS** |

### 8.1 Susunan pada Satu VPS

- **Nginx**: menyajikan hasil build React, meneruskan `/api` ke FastAPI, dan menangani sertifikat HTTPS (domain wajib agar kamera dapat diakses browser).
- **FastAPI**: API, autentikasi, dan modul OCR; pemrosesan OCR dijalankan di thread pool/worker agar API tidak terblokir.
- **PostgreSQL**: hanya dapat diakses dari jaringan internal Docker.
- Dengan 5 pengguna, 1 lokasi, dan sekitar 80 pemeriksaan per hari, 2 vCPU, 4 GB RAM, dan SSD 40 GB sudah memadai; foto hanya disimpan 1 hari sehingga kebutuhan disk kecil.

### 8.2 Modul OCR

- **Frontend** memotong gambar sesuai kotak panduan sebelum dikirim, sehingga yang diproses hanya area relevan.
- **Preprocessing (OpenCV)**: grayscale, perbaikan kontras (CLAHE), thresholding, penskalaan.
- **Konfigurasi Tesseract**: whitelist karakter huruf besar dan angka, mode satu baris teks (`--psm 7`).
- OCR dibungkus dalam satu modul/antarmuka tunggal sehingga engine dapat diganti (mis. PaddleOCR) tanpa mengubah bagian lain aplikasi jika akurasi di lapangan kurang.

* **Orientasi:** foto EIR dan segel sering miring; modul mencoba rotasi 0°, 90°, 180°, 270° dan memilih hasil yang cocok dengan pola alfanumerik 6–10 karakter.
* **Barcode:** pada segel berbarcode (Evergreen), barcode dibaca lebih dulu memakai library pembaca barcode; segel pelayaran lain tidak berbarcode sehingga hanya OCR. Jenis barcode pada segel perlu diverifikasi.
* **Hasil uji awal (satu pasang contoh):** nomor seal pada EIR kertas terbaca benar setelah foto diputar 90°; foto segel penuh gagal terbaca, dan setelah di-crop pada label terbaca EMCHURS175 (angka 9 terbaca S) padahal nomor sebenarnya EMCHUR9175.

## 9. Model Data (Ringkas)

**roles**: id, nama, deskripsi, hak akses (JSON/tabel relasi).

**users**: id, employee\_id (unik), full\_name, email (unik), username (unik), password\_hash (bcrypt/argon2), role\_id, location, is\_active, must\_change\_password, failed\_login\_count, last\_login\_at, created\_at, updated\_at.

**seal\_checks**: id, user\_id, location, eir\_no, container\_no, booking\_no, seal\_eir\_ocr\_raw, seal\_eir\_final, seal\_actual\_ocr\_raw, seal\_actual\_final, result (SUCCESS / FAILED), near\_match\_flag, edited\_flag, eir\_photo\_url, seal\_photo\_url, notes, checked\_at.

**audit\_logs**: id, actor\_user\_id, action, target\_type, target\_id, before\_json, after\_json, created\_at.

Indeks yang disarankan: seal\_checks (checked\_at, result, location, container\_no, eir\_no) untuk pencarian dan laporan.

## 10. Kebutuhan Non-Fungsional

| Aspek | Kebutuhan |
| --- | --- |
| Performa | Hasil OCR dan pencocokan ditampilkan ≤ 10 detik setelah foto diambil pada jaringan seluler normal; foto dikompres di sisi klien sebelum diunggah |
| Keamanan | HTTPS wajib; password di-hash; token berumur terbatas; validasi input dan batas ukuran unggahan; PostgreSQL tidak terbuka ke publik; firewall hanya port 80/443 dan SSH (dengan key) |
| Privasi dan retensi | Foto hanya dapat diakses user yang berhak; foto dan log pemeriksaan dihapus otomatis 1 hari setelah dibuat (lihat SEAL-28) |
| Ketersediaan dan backup | Backup `pg_dump` terjadwal harian dan salinan folder foto ke lokasi terpisah; uji pemulihan berkala |
| Kompatibilitas | Chrome dan Safari seluler versi terbaru (Android dan iOS); layar minimum 360 px |
| Auditabilitas | Seluruh pemeriksaan dan perubahan master tercatat dan tidak dapat dihapus oleh role Operator |
| Pemantauan | Pemantauan CPU, RAM, disk, dan status layanan (mis. Uptime Kuma atau netdata) |

## 11. Fase Pengembangan

| Fase | Cakupan | Hasil |
| --- | --- | --- |
| 1. Fondasi | Setup Docker Compose, Nginx + HTTPS, PostgreSQL, skema database, login, Master User, Master Role | Pengguna dapat login dan dikelola |
| 2. Pemeriksaan Seal | Akses kamera, kotak panduan, OCR Tesseract + preprocessing, normalisasi, pencocokan, layar hijau/merah, penyimpanan foto dan log | Alur inti end-to-end |
| 3. Riwayat dan Laporan | Riwayat, detail, filter, export Excel/CSV, dashboard | Pemantauan dan audit |
| 4. Uji Lapangan (Pilot) | Uji di depo/terminal dengan sampel foto nyata dari tiap pelayaran (termasuk segel tanpa barcode), pengukuran akurasi OCR, penyesuaian preprocessing | Keputusan: tetap Tesseract atau ganti engine |
| 5. Rilis dan Operasional | Backup, monitoring, pelatihan operator, panduan pengguna | Go-live |

## 12. Risiko dan Mitigasi

| Risiko | Dampak | Mitigasi |
| --- | --- | --- |
| Akurasi Tesseract rendah pada segel logam (pantulan, permukaan melengkung, emboss) | Banyak koreksi manual | Kotak panduan, preprocessing, whitelist karakter, flash, foto ulang, edit manual; ukur akurasi di pilot dan siapkan penggantian engine |
| Kamera diblokir karena tidak memakai HTTPS | Aplikasi tidak dapat dipakai | Domain dan sertifikat HTTPS sejak awal |
| Sinyal lemah di lokasi lapangan | Unggah foto lambat/gagal | Kompresi foto di klien, indikator progres, percobaan ulang unggahan; mode offline dipertimbangkan di fase lanjutan |
| Satu VPS sebagai titik kegagalan tunggal | Layanan berhenti bila server bermasalah | Backup terjadwal, dokumentasi pemulihan, snapshot VPS |
| Operator mengedit hasil OCR agar "Sesuai" | Hasil tidak dapat dipercaya | Simpan nilai OCR mentah vs final, penanda edit, tinjauan Supervisor |
| Beban OCR saat banyak scan bersamaan | Respons lambat | Thread pool/worker OCR, tambah core CPU atau pisahkan worker |
| Segel selain Evergreen tidak berbarcode, sehingga hanya bisa dibaca OCR | Akurasi bergantung penuh pada OCR; salah baca seperti 9 terbaca S memicu hasil keliru | Crop wajib, deteksi orientasi, tabel karakter mirip (termasuk 9/S/G), edit manual, dan uji dengan sampel dari tiap pelayaran sebelum go-live |

## 13. Asumsi dan Pertanyaan Terbuka

**Asumsi**

- Pengguna memakai HP Android/iOS dengan kamera belakang yang memadai dan koneksi data.
- Nomor seal pada EIR dan segel fisik berupa kombinasi huruf dan angka yang tercetak/terpahat jelas.
- Aplikasi berdiri sendiri; tidak ada rencana integrasi ke aplikasi freight internal maupun SAP.
- Hanya segel Evergreen yang diketahui berbarcode; segel pelayaran lain tidak berbarcode.

**Keputusan yang sudah dikonfirmasi**

- **Format nomor seal:** tidak ada format resmi; alfanumerik, panjang 6–10 karakter, berbeda tiap pelayaran (lihat Bagian 6).
- **Dokumen EIR:** berbentuk kertas, sehingga dibaca lewat foto dan OCR; contoh dokumen EIR dan foto segel dipakai untuk uji OCR di Fase 4.
- **Skala:** 5 pengguna, 1 lokasi, sekitar 80 pemeriksaan per hari.
- **Jumlah seal:** satu seal per container; dukungan beberapa seal dikeluarkan dari lingkup.
- **Retensi:** foto dan log pemeriksaan dihapus otomatis 24 jam setelah pemeriksaan (SEAL-28); audit log perubahan user tidak dihapus otomatis dan hanya dapat di-clear manual oleh Admin (SEAL-31).
- **Catatan jangka panjang:** hasil pemeriksaan direkap ke Excel (SEAL-24).
- **Login:** username dan password lokal; SSO Office 365 tidak dipakai.
- **Integrasi:** tidak ada rencana terhubung ke aplikasi freight internal.

## Lampiran A — Matriks Hak Akses Default

| Fitur | Admin | Supervisor | Operator |
| --- | --- | --- | --- |
| Kelola Master User | ✅ | ❌ | ❌ |
| Kelola Master Role | ✅ | ❌ | ❌ |
| Pemeriksaan Seal | ✅ | ✅ | ✅ |
| Lihat riwayat | Semua lokasi | Lokasi sendiri | Milik sendiri |
| Export laporan | ✅ | ✅ | ❌ |
| Dashboard | ✅ | ✅ | ❌ |
| Catatan tindak lanjut Failed | ✅ | ✅ | ❌ |
| Lihat audit log | ✅ | ❌ | ❌ |
| Clear audit log | ✅ | ❌ | ❌ |

## Lampiran B — Pesan Sistem Utama

| Kondisi | Warna | Pesan |
| --- | --- | --- |
| Nomor sama | Hijau | **Success / Sesuai** |
| Nomor berbeda | Merah | **Failed / Tidak Sesuai** |
| Hampir sama (selisih karakter mirip) | Kuning | Periksa kembali: nomor hampir sama |
| OCR tidak terbaca | Abu-abu | Nomor tidak terbaca, silakan foto ulang atau ketik manual |
