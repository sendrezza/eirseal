"""Uji integrasi end-to-end melalui HTTP sungguhan (bukan panggilan langsung).

Menjalankan alur lengkap seperti yang dilakukan browser: login → unggah foto
ke `POST /api/checks/scan` → pratinjau pencocokan → simpan pemeriksaan →
baca foto tersimpan. Memakai `urllib` bawaan Python agar tidak menambah
dependensi ke image produksi.

Pemakaian (dari root proyek):
    Get-Content backend\\tests\\integration_scan.py -Raw | docker compose exec -T api python -
"""

from __future__ import annotations

import json
import random
import uuid
from io import BytesIO
from urllib import error, request

from PIL import Image, ImageDraw, ImageFont

BASE = "http://localhost:8000"

FONT_PATHS = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
)


def _font(size: int = 96) -> object:
    for path in FONT_PATHS:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _png(img: Image.Image) -> bytes:
    buf = BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def seal_photo(text: str) -> bytes:
    """Foto segel: satu baris nomor besar di latar berbau kertas."""
    img = Image.new("L", (1200, 260), color=232)
    draw = ImageDraw.Draw(img)
    for i in range(8):
        y = 18 + i * 30
        draw.line([(8, y), (1192, y)], fill=220, width=2)
    draw.text((60, 80), text, fill=12, font=_font(104))
    return _png(img)


def eir_photo(seal_no: str) -> bytes:
    """Foto dokumen EIR: teks tersebar, nomor seal di antaranya."""
    img = Image.new("L", (1400, 1000), color=246)
    draw = ImageDraw.Draw(img)
    head, small = _font(40), _font(30)
    draw.text((60, 40), "EQUIPMENT INTERCHANGE RECEIPT", fill=20, font=head)
    rows = [
        ("TERMINAL", "JAKARTA INTERNATIONAL TERMINAL"),
        ("TANGGAL", "15/10/2026  08:41"),
        ("CONTAINER NO", "MSCU1234567"),
        ("BOOKING NO", "BKG-88213"),
        ("SHIPPER", "PT CONTOH LOGISTIK INDONESIA"),
        ("GATE", "B2"),
        ("STATUS", "EMPTY / LADEN"),
        ("SEAL NO", seal_no),
        ("VESSEL", "MV SAMUDRA 118W"),
    ]
    y = 140
    for label, value in rows:
        draw.text((70, y), label, fill=90, font=small)
        draw.text((480, y), value, fill=15, font=small)
        y += 88
    return _png(img)


def http(
    method: str,
    path: str,
    *,
    token: str | None = None,
    body: bytes | None = None,
    headers: dict[str, str] | None = None,
) -> tuple[int, object]:
    url = f"{BASE}{path}"
    head = {"Accept": "application/json"}
    if token:
        head["Authorization"] = f"Bearer {token}"
    if headers:
        head.update(headers)
    req = request.Request(url, data=body, method=method, headers=head)
    try:
        with request.urlopen(req, timeout=120) as resp:
            raw = resp.read()
            code = resp.status
    except error.HTTPError as exc:
        raw = exc.read()
        code = exc.code
    try:
        return code, json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        return code, raw


def multipart(
    fields: dict[str, str], files: dict[str, tuple[str, bytes, str]]
) -> tuple[bytes, str]:
    """Bangun body multipart/form-data tanpa pustaka tambahan."""
    boundary = f"----eir{uuid.uuid4().hex}"
    out = bytearray()
    for name, value in fields.items():
        out += f"--{boundary}\r\n".encode()
        out += f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
        out += f"{value}\r\n".encode()
    for name, (filename, data, content_type) in files.items():
        out += f"--{boundary}\r\n".encode()
        out += (
            f'Content-Disposition: form-data; name="{name}"; '
            f'filename="{filename}"\r\n'
        ).encode()
        out += f"Content-Type: {content_type}\r\n\r\n".encode()
        out += data
        out += b"\r\n"
    out += f"--{boundary}--\r\n".encode()
    return bytes(out), f"multipart/form-data; boundary={boundary}"


def confusable_free(prefix: str, length: int) -> str:
    """Buat nomor bebas karakter yang mirip (tanpa 0/O/1/I/5/S/8/B).

    Dipakai untuk menguji perpipaan aplikasi secara ketat, terpisah dari
    keterbatasan Tesseract membedakan 0↔O dan 5↔S pada gambar buram.
    Selalu memuat minimal satu huruf dan satu angka agar lolos ambang
    mode dokumen yang menuntut campuran huruf+angka.
    """
    letters = "ACDEFHJKMPQRTUVWXY"
    digits = "3467"
    body = [random.choice(letters) if i % 2 == 0 else random.choice(digits)
            for i in range(length - len(prefix))]
    if not any(c in digits for c in body):
        body[-1] = random.choice(digits)
    if not any(c in letters for c in body):
        body[0] = random.choice(letters)
    return prefix + "".join(body)


def show(label: str, ok: bool, detail: str = "") -> None:
    print(f"  {'OK  ' if ok else 'X   '}{label}{(' — ' + detail) if detail else ''}")


def main() -> None:
    problems: list[str] = []

    def check(label: str, ok: bool, detail: str = "") -> None:
        show(label, ok, detail)
        if not ok:
            problems.append(f"{label}: {detail}")

    print("=== Integrasi end-to-end melalui HTTP ===\n")

    code, body = http("GET", "/api/meta/health")
    check("health", code == 200 and body.get("database") == "up", f"HTTP {code}")
    check("OCR tersedia di health", body.get("ocr_available") is True)

    import os

    # Alur yang sama dengan operator sungguhan (SEAL-04): akun bawaan belum
    # dapat memakai API apa pun sebelum mengganti password.
    admin_user = os.environ.get("DEFAULT_ADMIN_USERNAME", "admin")
    password = os.environ.get("SMOKE_ADMIN_PASSWORD", "Admin@123")
    new_password = os.environ.get("SMOKE_ADMIN_PASSWORD_NEW", "Admin@123!")

    code, body = http(
        "POST",
        "/api/auth/login",
        body=json.dumps({"username": admin_user, "password": password}).encode(),
        headers={"Content-Type": "application/json"},
    )
    if code != 200:
        # Password sudah pernah diubah oleh run sebelumnya.
        code, body = http(
            "POST",
            "/api/auth/login",
            body=json.dumps({"username": admin_user, "password": new_password}).encode(),
            headers={"Content-Type": "application/json"},
        )
    check("login admin", code == 200 and bool(body.get("access_token")), f"HTTP {code}")
    if code != 200:
        print("  berhenti: tidak dapat login")
        raise SystemExit(1)
    token = body["access_token"]

    if body.get("must_change_password"):
        blocked = http("GET", "/api/checks?page_size=1", token=token)
        check("API terkunci sampai password diganti", blocked[0] == 403,
              f"HTTP {blocked[0]}")
        code, changed = http(
            "POST",
            "/api/auth/change-password-first",
            token=token,
            body=json.dumps({"new_password": new_password}).encode(),
            headers={"Content-Type": "application/json"},
        )
        check("admin mengganti password awal", code == 200, f"HTTP {code}")
        print(f"  catatan: password {admin_user} kini '{new_password}'")
    else:
        print("  catatan: password sudah pernah diubah; alur ganti dilewati.")

    print("\n--- Pindai foto segel (kind=seal) ---")
    # Nomor bebas karakter mirip: menguji perpipaan aplikasi, bukan batas
    # kecermatan Tesseract pada 0↔O / 5↔S (diuji terpisah di ocr_probe).
    seal_no = confusable_free("EMCH", 10)
    data, ctype = multipart(
        {"kind": "seal"},
        {"file": ("seal.png", seal_photo(seal_no), "image/png")},
    )
    code, body = http(
        "POST", "/api/checks/scan", token=token, body=data, headers={"Content-Type": ctype}
    )
    check("scan segel", code == 200, f"HTTP {code} {body if code != 200 else ''}")
    photo_url = body.get("photo_url", "")
    check("OCR membaca nomor segel", body.get("ocr_raw") == seal_no,
          f"{body.get('ocr_raw')!r} vs {seal_no!r}")
    check("photo_id & photo_url dikirim", bool(body.get("photo_id") and photo_url))
    check("peringatan kosong pada foto baik", not body.get("warnings"),
          str(body.get("warnings")))

    print("\n--- Pindai foto dokumen EIR (kind=eir) ---")
    doc_seal = confusable_free("TRK", 10)
    data, ctype = multipart(
        {"kind": "eir"},
        {"file": ("eir.png", eir_photo(doc_seal), "image/png")},
    )
    code, doc_body = http(
        "POST", "/api/checks/scan", token=token, body=data, headers={"Content-Type": ctype}
    )
    check("scan dokumen EIR", code == 200, f"HTTP {code}")
    got = doc_body.get("ocr_raw") or ""
    # Uji integrasi memeriksa perpipaan, bukan akurasi karakter Tesseract.
    # Salah baca 6↔G pada gambar buram adalah keterbatasan engine yang
    # dicakup ocr_probe; di sini cukup dibuktikan baris nomor seal yang
    # ditemukan di antara teks dokumen lain — bukan label seperti "TERMINAL".
    plausible = got.startswith(doc_seal[:3]) and len(got) == len(doc_seal)
    check(
        "OCR menemukan baris nomor seal di antara teks EIR",
        got == doc_seal or plausible,
        f"{got!r} vs {doc_seal!r}",
    )
    check("foto tersimpan", bool(doc_body.get("photo_id")))

    print("\n--- Jalur koreksi operator (OCR meleset, user memperbaiki) ---")
    # Meniru kasus nyata Tesseract: 6 terbaca menjadi G. PRD mewajibkan hasil
    # OCR dikonfirmasi/diubah pengguna sebelum disimpan, dan hasil akhir
    # memakai nilai koreksi — bukan nilai OCR mentah.
    # Kedua nilai harus berasal dari nomor yang SAMA supaya bedanya tepat
    # satu karakter; memanggil pembuat nomor dua kali akan menghasilkan
    # dua nomor acak berbeda dan menggagalkan tes.
    corrected = confusable_free("TRK", 10)
    while "6" not in corrected:
        corrected = confusable_free("TRK", 10)
    ocr_misread = corrected.replace("6", "G", 1)  # 6 dan G saling mirip
    check("kasus uji beda tepat 1 karakter", ocr_misread != corrected
          and sum(a != b for a, b in zip(ocr_misread, corrected)) == 1,
          f"{ocr_misread!r} vs {corrected!r}")
    code, body = http(
        "POST",
        "/api/checks/preview",
        token=token,
        body=json.dumps(
            {"seal_eir_final": ocr_misread, "seal_actual_final": corrected}
        ).encode(),
        headers={"Content-Type": "application/json"},
    )
    check(
        "koreksi 1 karakter mirip → FAILED + peringatan kuning",
        code == 200 and body.get("result") == "FAILED" and body.get("near_match") is True,
        f"result={body.get('result')} near={body.get('near_match')}",
    )

    code, body = http(
        "POST",
        "/api/checks/preview",
        token=token,
        body=json.dumps(
            {"seal_eir_final": corrected, "seal_actual_final": corrected}
        ).encode(),
        headers={"Content-Type": "application/json"},
    )
    check(
        "setelah dikoreksi user → SUCCESS",
        code == 200 and body.get("result") == "SUCCESS",
        f"result={body.get('result')}",
    )

    print("\n--- Pratinjau & simpan pemeriksaan ---")
    code, body = http(
        "POST",
        "/api/checks/preview",
        token=token,
        body=json.dumps({"seal_eir_final": seal_no, "seal_actual_final": seal_no}).encode(),
        headers={"Content-Type": "application/json"},
    )
    check("preview cocok → SUCCESS", code == 200 and body.get("result") == "SUCCESS")

    near_eir = "EMCHUR9175"
    near_actual = "EMCHURO175"  # 0 menggantikan O
    code, body = http(
        "POST",
        "/api/checks/preview",
        token=token,
        body=json.dumps(
            {"seal_eir_final": near_eir, "seal_actual_final": near_actual}
        ).encode(),
        headers={"Content-Type": "application/json"},
    )
    check(
        "karakter mirip → FAILED + peringatan, bukan Sesuai",
        code == 200
        and body.get("result") == "FAILED"
        and body.get("near_match") is True,
        f"result={body.get('result')} near={body.get('near_match')}",
    )

    code, created = http(
        "POST",
        "/api/checks",
        token=token,
        body=json.dumps(
            {
                "seal_eir_final": seal_no,
                "seal_actual_final": seal_no,
                "seal_eir_ocr_raw": "EMCHURS175",
                "seal_actual_ocr_raw": seal_no,
                "eir_no": "EIR-INTEGRASI-1",
                "container_no": "MSCU9998887",
                "notes": "dibuat skrip integrasi",
            }
        ).encode(),
        headers={"Content-Type": "application/json"},
    )
    check("pemeriksaan tersimpan", code == 201, f"HTTP {code} {created if code != 201 else ''}")
    check_id = created.get("id") if isinstance(created, dict) else None
    check("edited_flag aktif saat OCR mentah beda", created.get("edited_flag") is True)

    print("\n--- Foto tersimpan dapat diambil ---")
    code, raw = http("GET", photo_url, token=token)
    check("foto dapat diambil dengan token", code == 200 and len(raw) > 1000,
          f"HTTP {code}, {len(raw) if isinstance(raw, (bytes, bytearray)) else 0} byte")
    check("foto berupa PNG asli", isinstance(raw, (bytes, bytearray)) and raw[:4] == b"\x89PNG")

    code, _ = http("GET", photo_url)
    check("foto tanpa token ditolak", code in (401, 403), f"HTTP {code}")

    print("\n--- Proteksi input ---")
    junk = b"bukan gambar sama sekali"
    data, ctype = multipart({"kind": "seal"}, {"file": ("x.png", junk, "image/png")})
    code, body = http(
        "POST", "/api/checks/scan", token=token, body=data, headers={"Content-Type": ctype}
    )
    check("file bukan gambar ditolak 400", code == 400, f"HTTP {code}")

    code, body = http("GET", "/api/checks/export", token=token)
    check("export Excel berjalan", code == 200, f"HTTP {code}")

    print("\n--- Alur wajib ganti password (SEAL-04) ---")
    # Pakai user sementara agar password Admin bawaan tidak tersentuh.
    code, roles = http("GET", "/api/roles", token=token)
    operator = next((r for r in roles if r.get("name") == "Operator"), None)
    check("role Operator tersedia", operator is not None, f"HTTP {code}")

    temp_user = f"tmp{uuid.uuid4().hex[:8]}"
    temp_password = "Sementara1"
    code, created_user = http(
        "POST",
        "/api/users",
        token=token,
        body=json.dumps(
            {
                "employee_id": f"T{uuid.uuid4().hex[:6].upper()}",
                "full_name": "User Uji Integrasi",
                "email": f"{temp_user}@eir.local",
                "username": temp_user,
                "role_id": operator["id"],
                "password": temp_password,
            }
        ).encode(),
        headers={"Content-Type": "application/json"},
    )
    check("user sementara dibuat", code == 201, f"HTTP {code} {created_user if code != 201 else ''}")
    user_id = created_user.get("id") if isinstance(created_user, dict) else None

    code, fresh = http(
        "POST",
        "/api/auth/login",
        body=json.dumps({"username": temp_user, "password": temp_password}).encode(),
        headers={"Content-Type": "application/json"},
    )
    fresh_token = fresh.get("access_token") if isinstance(fresh, dict) else None
    check("user baru dapat login", code == 200 and bool(fresh_token), f"HTTP {code}")
    check(
        "user baru ditandai wajib ganti password",
        bool(fresh) and fresh.get("must_change_password") is True,
        str(fresh.get("must_change_password") if isinstance(fresh, dict) else None),
    )

    if fresh_token:
        # Endpoint terproteksi lain harus menolak selama belum ganti password.
        code, _ = http("GET", "/api/checks?page_size=1", token=fresh_token)
        check("akses ditolak selama belum ganti password", code in (401, 403, 409),
              f"HTTP {code}")

        new_password = "BaruSekali7"
        code, body = http(
            "POST",
            "/api/auth/change-password-first",
            token=fresh_token,
            body=json.dumps({"new_password": new_password}).encode(),
            headers={"Content-Type": "application/json"},
        )
        check("ganti password pertama diterima", code == 200, f"HTTP {code} {body if code != 200 else ''}")

        code, again = http(
            "POST",
            "/api/auth/login",
            body=json.dumps({"username": temp_user, "password": temp_password}).encode(),
            headers={"Content-Type": "application/json"},
        )
        check("password lama tidak berlaku lagi", code in (401, 403), f"HTTP {code}")

        code, relogin = http(
            "POST",
            "/api/auth/login",
            body=json.dumps({"username": temp_user, "password": new_password}).encode(),
            headers={"Content-Type": "application/json"},
        )
        check("password baru berlaku", code == 200, f"HTTP {code}")
        check(
            "tanda wajib ganti password sudah dilepas",
            isinstance(relogin, dict) and relogin.get("must_change_password") is False,
            str(relogin.get("must_change_password") if isinstance(relogin, dict) else None),
        )

    if user_id:
        code, _ = http(
            "DELETE", f"/api/users/{user_id}", token=token
        )
        check("user sementara dibersihkan", code in (200, 204), f"HTTP {code}")

    print("\n" + "=" * 60)
    print(f"{'SEMUA LULUS' if not problems else 'ADA MASALAH'} — {len(problems)} kegagalan")
    for item in problems:
        print(f"  ! {item}")
    raise SystemExit(1 if problems else 0)


if __name__ == "__main__":
    main()
