"""Uji OCR pada gambar nyata, memakai jalur yang sama dengan production.

Membuat beberapa varian gambar nomor seal (jelas, miring, buram, gelap,
kode batang, teks berisik) lalu membacanya lewat `OCREngine.scan()` —
antarmuka yang sama dipakai endpoint `POST /api/checks/scan`.

Pemakaian (dari root proyek):
    Get-Content backend\\tests\\ocr_probe.py -Raw | docker compose exec -T api python -
"""

from __future__ import annotations

from io import BytesIO

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

from app.ocr.engine import engine_available, get_engine
from app.ocr.matching import compare

FONT_PATHS = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
    "C:/Windows/Fonts/consolab.ttf",
    "C:/Windows/Fonts/arialbd.ttf",
)


def _font(size: int = 96) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    """Font besar dan tebal — mendekati tulisan pada segel kontainer."""
    for path in FONT_PATHS:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    # Pillow >= 10 menyediakan font skalabel bawaan; lama hanya bitmap 10px.
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()

def _canvas(width: int = 1200, height: int = 240, bg: int = 235) -> Image.Image:
    img = Image.new("L", (width, height), color=bg)
    draw = ImageDraw.Draw(img)
    # Garis tipis meniru kertas/kotak di belakang nomor seal.
    for i in range(7):
        y = 20 + i * 30
        draw.line([(10, y), (width - 10, y)], fill=bg - 12, width=2)
    return img


def _draw_text(img: Image.Image, text: str, offset: tuple[int, int] = (50, 70)) -> Image.Image:
    draw = ImageDraw.Draw(img)
    draw.text(offset, text, fill=15, font=_font(96))
    return img


def _to_png(img: Image.Image) -> bytes:
    buf = BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def make_plain(text: str) -> bytes:
    return _to_png(_draw_text(_canvas(), text))


def make_rotated(text: str, degrees: int) -> bytes:
    # expand=True penting: tanpa itu kanvas 1200x240 akan terpotong saat
    # diputar 90/270 dan isinya hilang sama sekali.
    img = _draw_text(_canvas(), text)
    return _to_png(img.rotate(degrees, resample=Image.BICUBIC, expand=True, fillcolor=235))


def make_blurred(text: str, radius: float = 2.4) -> bytes:
    img = _draw_text(_canvas(), text).filter(ImageFilter.GaussianBlur(radius))
    return _to_png(img)


def make_dark(text: str) -> bytes:
    """Teks terang di latar gelap (seal di kondisi kurang cahaya)."""
    img = Image.new("L", (1200, 240), color=35)
    draw = ImageDraw.Draw(img)
    draw.text((50, 70), text, fill=225, font=_font(96))
    return _to_png(img)


def make_noisy(text: str) -> bytes:
    """Teks + banyak karakter pengganggu di sekitarnya."""
    img = _draw_text(_canvas(1300, 400), text)
    draw = ImageDraw.Draw(img)
    small = _font(34)
    draw.text((50, 210), "TERMINAL 3  14/10/2026  08:41  GATE B2  QC-OK", fill=90, font=small)
    draw.text((50, 280), "CONTAINER MSCU1234567  BKG-88213", fill=110, font=small)
    draw.text((50, 330), "SHIPPER: PT CONTOH LOGISTIK INDONESIA", fill=120, font=small)
    return _to_png(img)


def make_barcode39(text: str) -> bytes:
    """Kode batang Code 39 sungguhan, agar jalur SEAL-03/SEAL-30 benar-benar
    teruji. Pola: 1 = lebar, 0 = sempit; 9 elemen per karakter (batang/spasi
    bergantian, diawali batang), 3 di antaranya lebar."""
    patterns = {
        "0": "000110100", "1": "100100001", "2": "001100001", "3": "101100000",
        "4": "000110001", "5": "100110000", "6": "001110000", "7": "000100101",
        "8": "100100100", "9": "001100100", "A": "100001001", "B": "001001001",
        "C": "101001000", "D": "000011001", "E": "100011000", "F": "001011000",
        "G": "000001101", "H": "100001100", "I": "001001100", "J": "000011100",
        "K": "100000011", "L": "001000011", "M": "101000010", "N": "000010011",
        "O": "100010010", "P": "001010010", "Q": "000000111", "R": "100000110",
        "S": "001000110", "T": "000010110", "U": "110000001", "V": "011000001",
        "W": "111000000", "X": "010010001", "Y": "110010000", "Z": "011010000",
        "-": "010000101", ".": "110000100", " ": "011000100", "$": "010101000",
        "/": "010100010", "+": "010001010", "%": "000101010", "*": "010010100",
    }
    # Lebar kanvas dihitung dari total elemen agar bar tidak terpotong di
    # tepi kanan; disisakan quiet zone di kedua ujung. Tanpa keduanya pyzbar
    # menolak gambar walau pola tiap karakter sudah benar.
    narrow, wide, gap, quiet = 4, 11, 4, 40
    payload = f"*{text.upper()}*"
    bars = sum((wide if bit == "1" else narrow) for ch in payload for bit in patterns[ch])
    width = quiet * 2 + bars + gap * (len(payload) - 1)

    img = Image.new("L", (width, 240), color=250)
    draw = ImageDraw.Draw(img)
    x = quiet
    for index, ch in enumerate(payload):
        if index:
            x += gap
        for i, bit in enumerate(patterns[ch]):
            elem = wide if bit == "1" else narrow
            if i % 2 == 0:  # elemen genap = batang
                draw.rectangle([x, 20, x + elem - 1, 200], fill=5)
            x += elem
    return _to_png(img)


def barcode39_with_label(text: str) -> bytes:
    """Code 39 dengan nomor tercetak di bawahnya (kasus Evergreen/SEAL-30)."""
    img = Image.open(BytesIO(make_barcode39(text))).convert("L")
    draw = ImageDraw.Draw(img)
    draw.text((60, 196), text, fill=5, font=_font(46))
    return _to_png(img)


def make_noisy_cropped(text: str) -> bytes:
    """Foto berisik yang sudah dipotong ke kotak panduan.

    PRD mewajibkan crop di klien (SEAL-11) sebelum dikirim; inilah yang
    membuat nomor seal terbaca di antara teks dokumen lainnya.
    """
    full = Image.open(BytesIO(make_noisy(text))).convert("L")
    # Kotak panduan sedikit lebih lebar dari teks agar tidak memotong huruf
    # terakhir — crop yang terlalu sempit justru menurunkan akurasi OCR.
    return _to_png(full.crop((20, 30, 820, 200)))


# (label, nomor target, pembuat gambar, harapan)
#   "ok"    → harus terbaca dan cocok
#   "fail"  → sengaja diharapkan TIDAK terbaca (dipakai sebagai kontra-bukti)
CASES: list[tuple[str, str, object, str]] = [
    ("teks jelas", "EMCHUR9175", make_plain, "ok"),
    ("rotasi 90", "EMCHUR9175", lambda t: make_rotated(t, 90), "ok"),
    ("rotasi 180", "EMCHUR9175", lambda t: make_rotated(t, 180), "ok"),
    ("rotasi 270", "EMCHUR9175", lambda t: make_rotated(t, 270), "ok"),
    ("buram ringan", "EMCHUR9175", lambda t: make_blurred(t, 1.2), "ok"),
    ("buram berat", "EMCHUR9175", lambda t: make_blurred(t, 2.4), "ok"),
    ("gelap", "EMCHUR9175", make_dark, "ok"),
    ("code39 polos", "EMCHUR9175", make_barcode39, "ok"),
    ("code39 + label", "EMCHUR9175", barcode39_with_label, "ok"),
    ("pendek 6 digit", "SEAL42", make_plain, "ok"),
    ("berisik, sudah dicrop", "EMCHUR9175", make_noisy_cropped, "ok"),
    # Kontra-bukti: tanpa crop (SEAL-11) nomor tidak boleh dipaksa terbaca.
    ("berisik tanpa crop", "EMCHUR9175", make_noisy, "fail"),
    # Huruf kecil bukan bentuk segel asli; whitelist OCR adalah huruf kapital.
    ("huruf kecil", "emchur9175", make_plain, "fail"),
]


def decode(png: bytes) -> np.ndarray:
    """Cara yang sama dengan endpoint: imdecode dari buffer JPEG/PNG."""
    return cv2.imdecode(np.frombuffer(png, dtype=np.uint8), cv2.IMREAD_COLOR)


def main() -> None:
    engine = get_engine()
    print(f"engine={engine.name} tersedia={engine_available()}\n")
    print(f"{'':2}{'skenario':<22}{'hasil OCR':<16}{'konf':>5}  sumber")
    print("-" * 80)

    passed = 0
    problems: list[str] = []
    for label, text, builder, expect in CASES:
        png = builder(text)
        image = decode(png)
        if image is None:
            problems.append(f"{label}: imdecode gagal")
            print(f"X  {label:<22}(imdecode gagal)")
            continue

        # Sama persis dengan pemanggilan di routers/checks.py
        result = engine.scan(image, mode="line", use_barcode=True)
        source = "barcode" if result.used_barcode else f"ocr/{result.best_rotation}"
        outcome = compare(text, result.text) if result.text else None
        got = outcome["result"] if outcome else "UNREADABLE"

        if expect == "ok":
            good = got == "SUCCESS"
        else:  # "fail" — memang harus tidak terbaca / tidak cocok
            good = got != "SUCCESS"

        passed += int(good)
        if not good:
            problems.append(f"{label}: harapan {expect}, dapat {got}")

        flag = "OK " if good else "X  "
        shown = result.text or "(tidak terbaca)"
        conf = f"{result.confidence:5.0f}" if result.text else f"{'-':>5}"
        print(f"{flag}{label:<22}{shown:<18}{conf}  {source:<10} target={text}")

    print("-" * 84)
    print(f"sesuai harapan: {passed}/{len(CASES)}")
    for item in problems:
        print(f"  ! {item}")

    raise SystemExit(1 if problems else 0)


if __name__ == "__main__":
    main()
