"""Model data — mengikuti Bagian 9 PRD."""

from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Hak akses (Lampiran A)
# ---------------------------------------------------------------------------

PERMISSION_CATALOG = [
    {"key": "users.manage", "label": "Kelola Master User"},
    {"key": "roles.manage", "label": "Kelola Master Role"},
    {"key": "checks.create", "label": "Pemeriksaan Seal"},
    {"key": "checks.view", "label": "Lihat riwayat"},
    {"key": "reports.export", "label": "Export laporan"},
    {"key": "dashboard.view", "label": "Dashboard"},
    {"key": "followup.manage", "label": "Catatan tindak lanjut Failed"},
    {"key": "audit.view", "label": "Lihat audit log"},
    {"key": "audit.clear", "label": "Clear audit log"},
]

HISTORY_SCOPES = ["all", "location", "own"]


class Role(Base):
    __tablename__ = "roles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(String(255))
    permissions: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    history_scope: Mapped[str] = mapped_column(
        String(20), default="own", nullable=False
    )  # all | location | own
    is_system: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False
    )

    users: Mapped[list["User"]] = relationship(back_populates="role")

    @property
    def user_count(self) -> int:
        return len(self.users)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    employee_id: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    username: Mapped[str] = mapped_column(String(60), unique=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role_id: Mapped[int] = mapped_column(
        ForeignKey("roles.id", ondelete="RESTRICT"), nullable=False
    )
    location: Mapped[str | None] = mapped_column(String(80))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    must_change_password: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False
    )  # SEAL-04
    failed_login_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False
    )

    role: Mapped["Role"] = relationship(back_populates="users", lazy="joined")

    @property
    def is_locked(self) -> bool:
        from .config import settings

        return (
            self.is_active and self.failed_login_count >= settings.max_failed_logins
        )


class SealCheck(Base):
    __tablename__ = "seal_checks"
    __table_args__ = (
        Index("ix_seal_checks_checked_at", "checked_at"),
        Index("ix_seal_checks_result", "result"),
        Index("ix_seal_checks_location", "location"),
        Index("ix_seal_checks_container_no", "container_no"),
        Index("ix_seal_checks_eir_no", "eir_no"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    location: Mapped[str | None] = mapped_column(String(80))

    eir_no: Mapped[str | None] = mapped_column(String(60))
    container_no: Mapped[str | None] = mapped_column(String(60))
    booking_no: Mapped[str | None] = mapped_column(String(60))

    seal_eir_ocr_raw: Mapped[str | None] = mapped_column(String(60))
    seal_eir_final: Mapped[str] = mapped_column(String(60), nullable=False)
    seal_actual_ocr_raw: Mapped[str | None] = mapped_column(String(60))
    seal_actual_final: Mapped[str] = mapped_column(String(60), nullable=False)

    result: Mapped[str] = mapped_column(String(10), nullable=False)  # SUCCESS | FAILED
    near_match_flag: Mapped[bool] = mapped_column(
        Boolean, default=False, nullable=False
    )  # SEAL-20
    edited_flag: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)  # SEAL-19

    eir_photo_url: Mapped[str | None] = mapped_column(String(255))
    seal_photo_url: Mapped[str | None] = mapped_column(String(255))

    notes: Mapped[str | None] = mapped_column(Text)
    follow_up_notes: Mapped[str | None] = mapped_column(Text)  # SEAL-26
    follow_up_by_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    follow_up_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ref_check_id: Mapped[int | None] = mapped_column(Integer)  # aturan bisnis no.5

    checked_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    user: Mapped["User"] = relationship(
        foreign_keys=[user_id], lazy="joined"
    )
    follow_up_by: Mapped["User | None"] = relationship(
        foreign_keys=[follow_up_by_id], lazy="joined"
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (Index("ix_audit_logs_created_at", "created_at"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_user_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    action: Mapped[str] = mapped_column(String(60), nullable=False)
    target_type: Mapped[str | None] = mapped_column(String(40))
    target_id: Mapped[str | None] = mapped_column(String(40))
    before_json: Mapped[dict | None] = mapped_column(JSON)
    after_json: Mapped[dict | None] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, nullable=False
    )

    actor: Mapped["User | None"] = relationship(lazy="joined")
