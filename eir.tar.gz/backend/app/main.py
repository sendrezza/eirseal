"""Aplikasi FastAPI — API Aplikasi Verifikasi Nomor Seal EIR."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .database import Base, SessionLocal, engine
from .routers import audit, auth, checks, meta, photos, roles, users
from .scheduler import start_scheduler, stop_scheduler
from .seed import seed

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("eir")


@asynccontextmanager
async def lifespan(_: FastAPI):
    logger.info("Menyiapkan database…")
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        seed(db)
    start_scheduler()
    logger.info("%s v%s siap.", settings.app_name, settings.app_version)
    yield
    stop_scheduler()


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description=(
            "Verifikasi kesesuaian nomor seal dokumen EIR dengan nomor segel "
            "aktual pada container, lewat OCR berbasis foto."
        ),
        lifespan=lifespan,
        docs_url=f"{settings.api_prefix}/docs",
        openapi_url=f"{settings.api_prefix}/openapi.json",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    for router in (
        auth.router,
        users.router,
        roles.router,
        checks.router,
        audit.router,
        photos.router,
        meta.router,
    ):
        app.include_router(router, prefix=settings.api_prefix)

    @app.get(f"{settings.api_prefix}/", tags=["Metadata"])
    def root():
        return {
            "name": settings.app_name,
            "version": settings.app_version,
            "docs": f"{settings.api_prefix}/docs",
        }

    return app


app = create_app()
