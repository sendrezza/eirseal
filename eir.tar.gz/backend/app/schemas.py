"""Skema permintaan/respon API (Pydantic v2)."""

import re
from datetime import datetime
from typing import Annotated

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, field_validator

from .models import PERMISSION_CATALOG

# Alamat email divalidasi dengan pola sederhana, bukan EmailStr.
# EmailStr menolak domain khusus seperti ".local" (sering dipakai di jaringan
# internal pelabuhan) sehingga Admin tidak dapat dibuat sama sekali.
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+$")


def _validate_email(value: str) -> str:
    value = (value or "").strip()
    if not _EMAIL_RE.match(value):
        raise ValueError("Format email tidak valid (harus berupa nama@domain)")
    return value.lower()


Email = Annotated[str, AfterValidator(_validate_email)]


# ---------------------------------------------------------------------------
# Autentikasi
# ---------------------------------------------------------------------------


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=60)
    password: str = Field(min_length=1, max_length=128)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    must_change_password: bool = False
    user: "UserOut"


class PasswordChange(BaseModel):
    old_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=8, max_length=128)


class PasswordChangeFirstLogin(BaseModel):
    """Wajib ganti password saat login pertama (SEAL-04)."""

    new_password: str = Field(min_length=8, max_length=128)


# ---------------------------------------------------------------------------
# Master User
# ---------------------------------------------------------------------------


class UserBase(BaseModel):
    employee_id: str = Field(min_length=1, max_length=30)
    full_name: str = Field(min_length=1, max_length=120)
    email: Email
    username: str = Field(min_length=3, max_length=60)
    role_id: int
    location: str | None = Field(default=None, max_length=80)
    is_active: bool = True


class UserCreate(UserBase):
    password: str = Field(min_length=8, max_length=128)


class UserUpdate(BaseModel):
    employee_id: str | None = Field(default=None, max_length=30)
    full_name: str | None = Field(default=None, max_length=120)
    email: Email | None = None
    username: str | None = Field(default=None, min_length=3, max_length=60)
    role_id: int | None = None
    location: str | None = Field(default=None, max_length=80)
    is_active: bool | None = None
    password: str | None = Field(default=None, min_length=8, max_length=128)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    employee_id: str
    full_name: str
    email: Email
    username: str
    role_id: int
    role_name: str | None = None
    location: str | None
    is_active: bool
    must_change_password: bool
    last_login_at: datetime | None
    created_at: datetime
    # Hak akses dan cakupan riwayat diikutkan agar sisi klien dapat
    # mengendalikan menu/tombol (Lampiran A).
    permissions: list[str] = Field(default_factory=list)
    history_scope: str = "own"

    @classmethod
    def from_user(cls, user) -> "UserOut":
        return cls(
            id=user.id,
            employee_id=user.employee_id,
            full_name=user.full_name,
            email=user.email,
            username=user.username,
            role_id=user.role_id,
            role_name=user.role.name if user.role else None,
            location=user.location,
            is_active=user.is_active,
            must_change_password=user.must_change_password,
            last_login_at=user.last_login_at,
            created_at=user.created_at,
            permissions=list(user.role.permissions) if user.role else [],
            history_scope=user.role.history_scope if user.role else "own",
        )


class PaginatedUsers(BaseModel):
    items: list[UserOut]
    total: int
    page: int
    page_size: int


# ---------------------------------------------------------------------------
# Master Role
# ---------------------------------------------------------------------------


class RoleBase(BaseModel):
    name: str = Field(min_length=1, max_length=50)
    description: str | None = Field(default=None, max_length=255)
    permissions: list[str] = Field(default_factory=list)
    history_scope: str = "own"

    @field_validator("permissions")
    @classmethod
    def _known_permissions(cls, v: list[str]) -> list[str]:
        valid = {p["key"] for p in PERMISSION_CATALOG}
        unknown = [k for k in v if k not in valid]
        if unknown:
            raise ValueError(f"Hak akses tidak dikenal: {', '.join(unknown)}")
        return sorted(set(v))

    @field_validator("history_scope")
    @classmethod
    def _known_scope(cls, v: str) -> str:
        if v not in ("all", "location", "own"):
            raise ValueError("history_scope harus all, location, atau own")
        return v


class RoleCreate(RoleBase):
    pass


class RoleUpdate(RoleBase):
    name: str | None = Field(default=None, max_length=50)
    description: str | None = Field(default=None, max_length=255)
    permissions: list[str] | None = None
    history_scope: str | None = None

    @field_validator("permissions")
    @classmethod
    def _known_permissions(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return None
        valid = {p["key"] for p in PERMISSION_CATALOG}
        unknown = [k for k in v if k not in valid]
        if unknown:
            raise ValueError(f"Hak akses tidak dikenal: {', '.join(unknown)}")
        return sorted(set(v))

    @field_validator("history_scope")
    @classmethod
    def _known_scope(cls, v: str | None) -> str | None:
        if v is not None and v not in ("all", "location", "own"):
            raise ValueError("history_scope harus all, location, atau own")
        return v


class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: str | None
    permissions: list[str]
    history_scope: str
    is_system: bool
    user_count: int = 0


# ---------------------------------------------------------------------------
# Pemeriksaan Seal
# ---------------------------------------------------------------------------


class ScanResponse(BaseModel):
    """Hasil satu pemindaian foto (SEAL-11..14, SEAL-29, SEAL-30)."""

    photo_id: str
    photo_url: str
    ocr_raw: str
    ocr_confidence: float
    engine: str
    used_barcode: bool = False
    best_rotation: int = 0
    candidates: list[dict] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class MatchPreviewRequest(BaseModel):
    seal_eir_final: str = Field(min_length=1, max_length=60)
    seal_actual_final: str = Field(min_length=1, max_length=60)


class MatchResult(BaseModel):
    normalized_eir: str
    normalized_actual: str
    result: str  # SUCCESS | FAILED
    near_match: bool
    warnings: list[str] = Field(default_factory=list)
    format_warnings: list[str] = Field(default_factory=list)


class CheckCreate(BaseModel):
    seal_eir_final: str = Field(min_length=1, max_length=60)
    seal_actual_final: str = Field(min_length=1, max_length=60)
    seal_eir_ocr_raw: str | None = Field(default=None, max_length=60)
    seal_actual_ocr_raw: str | None = Field(default=None, max_length=60)
    eir_photo_id: str | None = Field(default=None, max_length=64)
    seal_photo_id: str | None = Field(default=None, max_length=64)
    eir_no: str | None = Field(default=None, max_length=60)
    container_no: str | None = Field(default=None, max_length=60)
    booking_no: str | None = Field(default=None, max_length=60)
    notes: str | None = Field(default=None, max_length=2000)
    ref_check_id: int | None = None


class CheckOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    user_name: str | None = None
    user_username: str | None = None
    location: str | None
    eir_no: str | None
    container_no: str | None
    booking_no: str | None
    seal_eir_ocr_raw: str | None
    seal_eir_final: str
    seal_actual_ocr_raw: str | None
    seal_actual_final: str
    result: str
    near_match_flag: bool
    edited_flag: bool
    eir_photo_url: str | None
    seal_photo_url: str | None
    notes: str | None
    follow_up_notes: str | None
    follow_up_by_name: str | None = None
    follow_up_at: datetime | None
    ref_check_id: int | None
    checked_at: datetime

    @classmethod
    def from_check(cls, c) -> "CheckOut":
        return cls(
            id=c.id,
            user_id=c.user_id,
            user_name=c.user.full_name if c.user else None,
            user_username=c.user.username if c.user else None,
            location=c.location,
            eir_no=c.eir_no,
            container_no=c.container_no,
            booking_no=c.booking_no,
            seal_eir_ocr_raw=c.seal_eir_ocr_raw,
            seal_eir_final=c.seal_eir_final,
            seal_actual_ocr_raw=c.seal_actual_ocr_raw,
            seal_actual_final=c.seal_actual_final,
            result=c.result,
            near_match_flag=c.near_match_flag,
            edited_flag=c.edited_flag,
            eir_photo_url=c.eir_photo_url,
            seal_photo_url=c.seal_photo_url,
            notes=c.notes,
            follow_up_notes=c.follow_up_notes,
            follow_up_by_name=c.follow_up_by.full_name if c.follow_up_by else None,
            follow_up_at=c.follow_up_at,
            ref_check_id=c.ref_check_id,
            checked_at=c.checked_at,
        )


class PaginatedChecks(BaseModel):
    items: list[CheckOut]
    total: int
    page: int
    page_size: int


class DashboardOut(BaseModel):
    date: str
    total: int
    success: int
    failed: int
    success_pct: float
    failed_pct: float


class FollowUpRequest(BaseModel):
    notes: str = Field(min_length=1, max_length=2000)


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------


class AuditOut(BaseModel):
    id: int
    actor_id: int | None
    actor_name: str | None = None
    action: str
    target_type: str | None
    target_id: str | None
    before_json: dict | None
    after_json: dict | None
    created_at: datetime

    @classmethod
    def from_log(cls, log) -> "AuditOut":
        return cls(
            id=log.id,
            actor_id=log.actor_user_id,
            actor_name=log.actor.full_name if log.actor else None,
            action=log.action,
            target_type=log.target_type,
            target_id=log.target_id,
            before_json=log.before_json,
            after_json=log.after_json,
            created_at=log.created_at,
        )


class PaginatedAudit(BaseModel):
    items: list[AuditOut]
    total: int
    page: int
    page_size: int


class ClearLogRequest(BaseModel):
    confirmation: str = Field(min_length=1)


class Message(BaseModel):
    message: str
    detail: dict | None = None


TokenResponse.model_rebuild()
