"""Zona waktu bisnis untuk laporan dan agregasi harian."""

from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from .config import settings


def business_tz() -> ZoneInfo:
    try:
        return ZoneInfo(settings.business_timezone)
    except Exception:  # pragma: no cover
        return ZoneInfo("UTC")


def now_local() -> datetime:
    return datetime.now(business_tz())


def to_utc(local_dt: datetime) -> datetime:
    return local_dt.astimezone(timezone.utc)


def day_bounds(day: date) -> tuple[datetime, datetime]:
    """Batas awal/akhir hari dalam UTC berdasarkan zona waktu bisnis."""
    tz = business_tz()
    start = to_utc(datetime.combine(day, time.min, tzinfo=tz))
    end = to_utc(datetime.combine(day + timedelta(days=1), time.min, tzinfo=tz))
    return start, end


def parse_date(value: str | None) -> date | None:
    if not value:
        return None
    return date.fromisoformat(value)
