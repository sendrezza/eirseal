"""Pengisian data awal: role bawaan (Lampiran A) dan akun Admin."""

from __future__ import annotations

import logging

from sqlalchemy import select
from sqlalchemy.orm import Session

from .auth import hash_password
from .config import settings
from .models import Role, User

logger = logging.getLogger(__name__)

DEFAULT_ROLES = [
    {
        "name": "Admin",
        "description": "Pengelola sistem: user, role, audit log, dan pengaturan.",
        "permissions": [
            "users.manage",
            "roles.manage",
            "checks.create",
            "checks.view",
            "reports.export",
            "dashboard.view",
            "followup.manage",
            "audit.view",
            "audit.clear",
        ],
        "history_scope": "all",
    },
    {
        "name": "Supervisor",
        "description": "Penanggung jawab lokasi/cabang: pantau hasil, tinjau kasus "
        "Failed, dan export laporan.",
        "permissions": [
            "checks.create",
            "checks.view",
            "reports.export",
            "dashboard.view",
            "followup.manage",
        ],
        "history_scope": "location",
    },
    {
        "name": "Operator",
        "description": "Petugas lapangan: scan dan cocokkan seal, lihat riwayat sendiri.",
        "permissions": [
            "checks.create",
            "checks.view",
        ],
        "history_scope": "own",
    },
]


def seed_roles(db: Session) -> dict[str, Role]:
    roles: dict[str, Role] = {}
    for spec in DEFAULT_ROLES:
        role = db.scalar(select(Role).where(Role.name == spec["name"]))
        if role is None:
            role = Role(**spec, is_system=True)
            db.add(role)
            logger.info("Role dibuat: %s", spec["name"])
        else:
            # Sinkronkan hak akses bawaan tanpa menimpa kustomisasi user
            role.is_system = True
        roles[spec["name"]] = role
    db.flush()
    return roles


def seed_admin(db: Session, roles: dict[str, Role]) -> None:
    username = settings.default_admin_username
    existing = db.scalar(select(User).where(User.username == username))
    if existing is not None:
        return

    employee_id = settings.default_admin_employee_id
    if db.scalar(select(User).where(User.employee_id == employee_id)):
        employee_id = f"EMP-{9000 + 1}"

    email = settings.default_admin_email
    if db.scalar(select(User).where(User.email == email)):
        email = f"admin+{employee_id}@local"

    admin = User(
        employee_id=employee_id,
        full_name="Administrator",
        email=email,
        username=username,
        password_hash=hash_password(settings.default_admin_password),
        role_id=roles["Admin"].id,
        location="Pusat",
        is_active=True,
        must_change_password=True,
    )
    db.add(admin)
    logger.warning(
        "Akun Admin dibuat. Username: %s — wajib ganti password saat login pertama.",
        username,
    )


def seed(db: Session) -> None:
    roles = seed_roles(db)
    seed_admin(db, roles)
    db.commit()
