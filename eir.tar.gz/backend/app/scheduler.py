"""Penjadwalan job latar belakang (pembersihan retensi 24 jam)."""

from __future__ import annotations

import logging

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from .config import settings
from .services.cleanup import cleanup_old_checks

logger = logging.getLogger(__name__)

scheduler = BackgroundScheduler(timezone="UTC")


def _job() -> None:
    try:
        cleanup_old_checks()
    except Exception:  # pragma: no cover
        logger.exception("Job retensi bermasalah")


def start_scheduler() -> None:
    if not settings.cleanup_enabled:
        logger.info("Job retensi dinonaktifkan lewat konfigurasi.")
        return
    if scheduler.running:
        return
    scheduler.add_job(
        _job,
        CronTrigger(
            hour=settings.cleanup_hour,
            minute=settings.cleanup_minute,
            timezone="UTC",
        ),
        id="retention_cleanup",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )
    scheduler.start()
    logger.info(
        "Job retensi terjadwal setiap hari %02d:%02d UTC (retensi %d jam).",
        settings.cleanup_hour,
        settings.cleanup_minute,
        settings.retention_hours,
    )


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
