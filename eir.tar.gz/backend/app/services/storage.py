"""Penyimpanan & penghapusan foto pemeriksaan (SEAL-18, SEAL-28)."""

from __future__ import annotations

import logging
import re
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ..config import settings

logger = logging.getLogger(__name__)

SAFE_NAME = re.compile(r"^[A-Za-z0-9._-]+$")
ALLOWED_SUFFIX = {".jpg", ".jpeg", ".png", ".webp"}


def photo_path(filename: str) -> Path | None:
    """Peta nama file ke path di dalam upload_dir; None bila tidak aman."""

    if not filename or not SAFE_NAME.match(filename):
        return None
    path = (settings.upload_path / filename).resolve()
    if path.parent != settings.upload_path.resolve():
        return None
    if path.suffix.lower() not in ALLOWED_SUFFIX:
        return None
    return path


def save_photo(data: bytes, suffix: str = ".jpg") -> str:
    """Simpan unggahan dan kembalikan nama file (bukan path publik)."""

    suffix = suffix.lower() if suffix.lower() in ALLOWED_SUFFIX else ".jpg"
    name = f"{datetime.now(timezone.utc):%Y%m%d%H%M%S}-{uuid.uuid4().hex[:12]}{suffix}"
    dest = settings.upload_path / name
    dest.write_bytes(data)
    return name


def delete_photo(filename: str | None) -> bool:
    if not filename:
        return False
    path = photo_path(filename)
    if path is None or not path.exists():
        return False
    try:
        path.unlink()
        return True
    except OSError as exc:
        logger.warning("Gagal menghapus foto %s: %s", filename, exc)
        return False


def sweep_orphan_photos(referenced: set[str]) -> int:
    """Hapus file foto yang sudah lewat masa retensi dan tidak dirujuk check."""

    cutoff = datetime.now(timezone.utc) - timedelta(hours=settings.retention_hours)
    removed = 0
    for path in settings.upload_path.glob("*"):
        if not path.is_file() or path.suffix.lower() not in ALLOWED_SUFFIX:
            continue
        if path.name in referenced:
            continue
        try:
            mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
            if mtime < cutoff:
                path.unlink()
                removed += 1
        except OSError as exc:
            logger.warning("Gagal menyapu foto %s: %s", path.name, exc)
    return removed
