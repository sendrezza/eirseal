"""Rekap pemeriksaan ke Excel .xlsx (SEAL-24).

Export mengikuti filter yang aktif dan berisi: waktu, user, nomor EIR, nomor
container, nomor seal EIR dan segel aktual (final), hasil, dan penanda diedit.
"""

from __future__ import annotations

from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HEADERS = [
    ("Waktu Pemeriksaan", 20),
    ("User", 20),
    ("Username", 16),
    ("Lokasi", 14),
    ("Nomor EIR", 16),
    ("Nomor Container", 18),
    ("Nomor Booking/BL", 18),
    ("Seal EIR (Final)", 18),
    ("Segel Aktual (Final)", 20),
    ("Seal EIR (OCR Mentah)", 22),
    ("Segel Aktual (OCR Mentah)", 24),
    ("Hasil", 14),
    ("Hampir Sama", 13),
    ("Diedit Manual", 14),
    ("Ref. Pemeriksaan", 18),
    ("Catatan", 40),
]

FILL_HEADER = PatternFill("solid", fgColor="1F4E79")
FILL_SUCCESS = PatternFill("solid", fgColor="C6EFCE")
FILL_FAILED = PatternFill("solid", fgColor="FFC7CE")
FONT_HEADER = Font(bold=True, color="FFFFFF")


def build_checks_workbook(checks) -> BytesIO:
    wb = Workbook()
    ws = wb.active
    ws.title = "Pemeriksaan Seal"

    for col, (title, width) in enumerate(HEADERS, start=1):
        cell = ws.cell(row=1, column=col, value=title)
        cell.font = FONT_HEADER
        cell.fill = FILL_HEADER
        cell.alignment = Alignment(horizontal="center", vertical="center")
        ws.column_dimensions[get_column_letter(col)].width = width

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(HEADERS))}1"

    for row, c in enumerate(checks, start=2):
        checked_at = c.checked_at
        try:
            waktu = checked_at.strftime("%Y-%m-%d %H:%M:%S")
        except AttributeError:
            waktu = str(checked_at)

        values = [
            waktu,
            c.user.full_name if c.user else "",
            c.user.username if c.user else "",
            c.location or "",
            c.eir_no or "",
            c.container_no or "",
            c.booking_no or "",
            c.seal_eir_final or "",
            c.seal_actual_final or "",
            c.seal_eir_ocr_raw or "",
            c.seal_actual_ocr_raw or "",
            "Sesuai" if c.result == "SUCCESS" else "Tidak Sesuai",
            "Ya" if c.near_match_flag else "Tidak",
            "Ya" if c.edited_flag else "Tidak",
            c.ref_check_id or "",
            c.notes or "",
        ]
        for col, value in enumerate(values, start=1):
            cell = ws.cell(row=row, column=col, value=value)
            if col == 12:
                cell.fill = FILL_SUCCESS if c.result == "SUCCESS" else FILL_FAILED
                cell.font = Font(bold=True)

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer
