"""Penghapusan otomatis foto dan log pemeriksaan (SEAL-28).

Retensi 24 jam sejak pemeriksaan dibuat: file foto di disk dan baris database
ikut dihapus. Log audit perubahan user dikecualikan dan tidak pernah disentuh
oleh job ini.
"""

from __future__ import annotations

import logging
from datetime import timedelta

from sqlalchemy import select

from ..config import settings
from ..database import SessionLocal
from ..models import SealCheck, utcnow
from .storage import delete_photo, sweep_orphan_photos

logger = logging.getLogger(__name__)


def cleanup_old_checks() -> dict:
    """Kembalikan ringkasan jumlah yang dihapus. Aman dipanggil berulang."""

    cutoff = utcnow() - timedelta(hours=settings.retention_hours)
    deleted_checks = 0
    deleted_photos = 0

    db = SessionLocal()
    try:
        rows = db.scalars(
            select(SealCheck).where(SealCheck.checked_at < cutoff)
        ).all()

        referenced: set[str] = set()
        for check in rows:
            for url in (check.eir_photo_url, check.seal_photo_url):
                if url:
                    filename = url.rsplit("/", 1)[-1]
                    if delete_photo(filename):
                        deleted_photos += 1
            db.delete(check)
            deleted_checks += 1

        db.commit()

        # File yang tersisa (mis. unggahan yang tak pernah menjadi pemeriksaan)
        remaining = db.scalars(
            select(SealCheck.eir_photo_url).where(SealCheck.eir_photo_url.is_not(None))
        ).all()
        referenced.update(u.rsplit("/", 1)[-1] for u in remaining if u)
        remaining = db.scalars(
            select(SealCheck.seal_photo_url).where(SealCheck.seal_photo_url.is_not(None))
        ).all()
        referenced.update(u.rsplit("/", 1)[-1] for u in remaining if u)

        deleted_photos += sweep_orphan_photos(referenced)
    except Exception:
        db.rollback()
        logger.exception("Job pembersihan retensi gagal")
        raise
    finally:
        db.close()

    summary = {
        "cutoff_hours": settings.retention_hours,
        "checks_deleted": deleted_checks,
        "photos_deleted": deleted_photos,
    }
    if deleted_checks or deleted_photos:
        logger.info("Retensi dibersihkan: %s", summary)
    return summary
