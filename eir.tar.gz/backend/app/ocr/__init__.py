"""Antarmuka tunggal modul OCR (Bagian 8.2 PRD).

Seluruh pemanggilan OCR keluar dari aplikasi lewat `OCREngine.scan()` sehingga
engine dapat diganti (mis. PaddleOCR) tanpa menyentuh modul lain.
"""

from .barcode import read_barcode
from .engine import OCREngine, TesseractEngine, get_engine
from .matching import (
    FORMAT_MAX,
    FORMAT_MIN,
    compare,
    near_match,
    normalize,
    validate_format,
)

__all__ = [
    "OCREngine",
    "TesseractEngine",
    "get_engine",
    "read_barcode",
    "normalize",
    "compare",
    "near_match",
    "validate_format",
    "FORMAT_MIN",
    "FORMAT_MAX",
]
