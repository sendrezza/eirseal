"""Aturan bisnis pencocokan (Bagian 6 PRD)."""

from __future__ import annotations

import re
from difflib import SequenceMatcher

FORMAT_MIN = 6  # SEAL-11 / aturan no.6
FORMAT_MAX = 10

# Karakter serupa sengaja TIDAK dipakai untuk meloloskan hasil (aturan no.3);
# hanya untuk peringatan "hampir sama" (SEAL-20).
CONFUSABLES = {
    "O": "0QD",
    "Q": "0O",
    "D": "0O",
    "I": "1l7",
    "1": "Il7",
    "l": "1I",
    "7": "1I",
    "S": "59",
    "5": "S",
    "9": "SG",
    "G": "96",
    "6": "G",
    "B": "8",
    "8": "B",
    "Z": "2",
    "2": "Z",
}

NON_ALNUM = re.compile(r"[^A-Z0-9]")


def normalize(value: str | None) -> str:
    """Huruf besar; hapus spasi, tanda hubung, titik, dan karakter non-alfanumerik."""
    if not value:
        return ""
    return NON_ALNUM.sub("", value.upper())


def validate_format(value: str) -> list[str]:
    """Validasi ringan: hanya peringatan, bukan penolakan (aturan no.6)."""
    warnings: list[str] = []
    if not value:
        warnings.append("Nomor kosong.")
        return warnings
    if not value.isalnum():
        warnings.append("Nomor mengandung karakter non-alfanumerik.")
    if len(value) < FORMAT_MIN:
        warnings.append(
            f"Nomor lebih pendek dari rentang umum {FORMAT_MIN}–{FORMAT_MAX} karakter."
        )
    elif len(value) > FORMAT_MAX:
        warnings.append(
            f"Nomor lebih panjang dari rentang umum {FORMAT_MIN}–{FORMAT_MAX} karakter."
        )
    return warnings


def _similarity(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def near_match(a: str, b: str) -> bool:
    """True bila kedua nomor berbeda tapi selisihnya hanya 1–2 karakter mirip.

    Dipakai untuk peringatan kuning (SEAL-20 / Lampiran B), bukan untuk
    menyatakan hasil Sesuai.
    """
    if a == b or not a or not b:
        return False

    # Panjang sama dan hanya berbeda pada karakter yang saling serupa.
    if len(a) == len(b):
        diff = [(x, y) for x, y in zip(a, b) if x != y]
        if 1 <= len(diff) <= 2 and all(
            y in CONFUSABLES.get(x, "") or x in CONFUSABLES.get(y, "")
            for x, y in diff
        ):
            return True

    # Panjang berbeda 1 karakter: satu karakter disisipkan/hilang di posisi
    # yang karakter sisanya identik, atau beda tipis (mis. 9 vs S).
    if abs(len(a) - len(b)) <= 1 and _similarity(a, b) >= 0.85:
        return True
    if _similarity(a, b) >= 0.9:
        return True
    return False


def compare(eir_value: str, actual_value: str) -> dict:
    """Normalisasi + pencocokan. Sesuai hanya bila kedua string identik."""
    norm_eir = normalize(eir_value)
    norm_actual = normalize(actual_value)

    is_match = bool(norm_eir) and norm_eir == norm_actual
    format_warnings = validate_format(norm_eir) + validate_format(norm_actual)
    warnings: list[str] = []
    if not is_match and near_match(norm_eir, norm_actual):
        warnings.append("Periksa kembali: nomor hampir sama")

    return {
        "normalized_eir": norm_eir,
        "normalized_actual": norm_actual,
        "result": "SUCCESS" if is_match else "FAILED",
        "near_match": bool(warnings),
        "warnings": warnings,
        "format_warnings": format_warnings,
    }
