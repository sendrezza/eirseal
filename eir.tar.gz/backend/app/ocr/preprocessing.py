"""Preprocessing gambar untuk OCR dengan OpenCV (Bagian 8.2 PRD).

grayscale → perbaikan kontras (CLAHE) → thresholding → penskalaan.
"""

from __future__ import annotations

import cv2
import numpy as np

# Batas agar crop keselamatan tidak agresif
CROP_MIN_AREA_RATIO = 0.05
CROP_MAX_AREA_RATIO = 0.92


def to_gray(img: np.ndarray) -> np.ndarray:
    if img is None:
        raise ValueError("Gambar tidak valid")
    if len(img.shape) == 2:
        return img
    if img.shape[2] == 4:
        return cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def rotate_image(img: np.ndarray, angle: int) -> np.ndarray:
    angle = int(angle) % 360
    if angle == 0:
        return img
    if angle == 90:
        return cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    if angle == 180:
        return cv2.rotate(img, cv2.ROTATE_180)
    if angle == 270:
        return cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
    h, w = img.shape[:2]
    m = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    return cv2.warpAffine(img, m, (w, h), flags=cv2.INTER_CUBIC)


def content_crop(img: np.ndarray, margin: int = 12) -> np.ndarray:
    """Crop ke bounding box piksel non-latar — jaring pengaman bila crop di
    klien kurang pas. Hanya memotong bila hasilnya masih masuk akal."""

    gray = to_gray(img)
    h, w = gray.shape[:2]

    best: tuple[int, int, int, int] | None = None
    best_area = w * h

    for flag in (cv2.THRESH_BINARY_INV, cv2.THRESH_BINARY):
        _, th = cv2.threshold(
            gray, 0, 255, flag | cv2.THRESH_OTSU
        )
        coords = cv2.findNonZero(th)
        if coords is None:
            continue
        x, y, bw, bh = cv2.boundingRect(coords)
        area = bw * bh
        if area < best_area:
            best_area = area
            best = (x, y, bw, bh)

    if best is None:
        return img

    x, y, bw, bh = best
    ratio = best_area / float(w * h)
    if not (CROP_MIN_AREA_RATIO <= ratio <= CROP_MAX_AREA_RATIO):
        return img

    x0 = max(0, x - margin)
    y0 = max(0, y - margin)
    x1 = min(w, x + bw + margin)
    y1 = min(h, y + bh + margin)
    cropped = img[y0:y1, x0:x1]
    return cropped if cropped.size else img


def _clahe(gray: np.ndarray) -> np.ndarray:
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    return clahe.apply(gray)


def build_variants(img: np.ndarray) -> dict[str, np.ndarray]:
    """Kumpulan varian hasil preprocessing untuk dicoba satu per satu."""

    gray = _clahe(to_gray(img))
    variants: dict[str, np.ndarray] = {}

    # 1. Grayscale + CLAHE + Otsu thresholding
    variants["otsu"] = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

    # 2. Adaptive threshold (baik untuk pencahayaan tidak merata)
    variants["adaptive"] = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 10
    )

    # 3. Otsu terbalik (teks terang di latar gelap / emboss)
    variants["otsu_inv"] = cv2.threshold(
        gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU
    )[1]

    # 4. Penskalaan 2× — membantu teks kecil/segel pendek
    up = cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
    variants["scale2_otsu"] = cv2.threshold(
        up, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )[1]

    return variants


def prepare_images(img: np.ndarray) -> list[tuple[str, np.ndarray]]:
    """Pasangan (nama, gambar) yang akan diuji: varian pada gambar asli dan
    pada hasil content_crop."""

    out: list[tuple[str, np.ndarray]] = []
    for name, v in build_variants(img).items():
        out.append((name, v))

    cropped = content_crop(img)
    if cropped.shape[:2] != img.shape[:2]:
        for name, v in build_variants(cropped).items():
            out.append((f"{name}+crop", v))

    return out
