"""Pembacaan barcode pada segel (SEAL-30, prioritas Should).

Saat ini hanya segel Evergreen yang diketahui berbarcode; segel pelayaran
lain tidak berbarcode sehingga hanya memakai OCR. Kegagalan memasang
pustaka barcode tidak boleh menjatuhkan aplikasi — fungsi ini selalu aman
dipanggil dan mengembalikan None bila tidak tersedia.
"""

from __future__ import annotations

import logging

import numpy as np

logger = logging.getLogger(__name__)

_decoder = None
_available: bool | None = None


def _get_decoder():
    """Lazy import pyzbar agar aplikasi tetap jalan tanpa libzbar."""
    global _decoder, _available
    if _available is not None:
        return _decoder
    try:
        from pyzbar.pyzbar import decode as _pyzbar_decode

        _decoder = _pyzbar_decode
        _available = True
    except ImportError:  # pragma: no cover
        _available = False
        _decoder = None
        logger.warning("pyzbar tidak tersedia; pembacaan barcode dinonaktifkan.")
    return _decoder


def barcode_supported() -> bool:
    return _get_decoder() is not None


def read_barcode(img: np.ndarray) -> str | None:
    """Coba decode barcode/QR dari gambar. Mengembalikan None bila tidak ada."""

    decode = _get_decoder()
    if decode is None:
        return None

    try:
        import cv2

        candidates = [img]
        gray = img if len(img.shape) == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        candidates.append(gray)
        # Upscale membantu barcode kecil / resolusi rendah
        candidates.append(
            cv2.resize(gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
        )

        for cand in candidates:
            results = decode(cand)
            if not results:
                continue
            data = results[0].data
            if isinstance(data, bytes):
                data = data.decode("utf-8", errors="ignore")
            data = str(data).strip()
            if data:
                return data
    except Exception as exc:  # pragma: no cover
        logger.debug("Barcode gagal dibaca: %s", exc)
    return None
