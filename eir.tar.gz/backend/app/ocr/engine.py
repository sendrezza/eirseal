"""Engine OCR: Tesseract + preprocessing OpenCV (Bagian 8.2 PRD).

Dibungkus di balik kelas abstrak `OCREngine` sehingga engine dapat diganti
(mis. PaddleOCR) tanpa mengubah modul lain aplikasi.
"""

from __future__ import annotations

import logging
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from functools import lru_cache

import cv2
import numpy as np
import pytesseract

from .barcode import read_barcode
from .matching import normalize
from .preprocessing import build_variants, content_crop, rotate_image

logger = logging.getLogger(__name__)

# Rotasi yang dicoba (SEAL-29)
ROTATIONS = (0, 90, 180, 270)

WHITELIST = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

# Format nomor seal: alfanumerik 6–10 karakter (aturan bisnis no.6)
PATTERN_6_10 = re.compile(r"^[A-Z0-9]{6,10}$")
PATTERN_ANY = re.compile(r"^[A-Z0-9]{4,14}$")

# Batas sisi terpanjang gambar sebelum OCR — dokumen EIR beresolusi tinggi
# membuat Tesseract lambat tanpa menaikkan akurasi.
MAX_OCR_DIMENSION = 1800

# Ambang "hasil baca memadai". Dokumen EIR menuntut campuran huruf+angka agar
# nomor tanggal/timestamp murni angka tidak ikut menang.
GOOD_SCORE_LINE = 55
GOOD_SCORE_DOCUMENT = 100

# Ambang konfiden Tesseract (0–100) untuk berhenti mencari varian/rotasi.
# Skor kandidat hanya mencerminkan panjang dan bentuk token, sehingga hasil
# baca yang salah (tulisan terbalik, teks sekitarnya) bisa berskor sama
# tinggi dengan nomor yang benar. Tanpa syarat konfiden ini, rotasi
# berikutnya tidak pernah dicoba dan foto terbalik selalu gagal.
MIN_CONFIDENCE = 60.0

# Varian preprocessing yang dipakai untuk dokumen penuh (lebih sedikit agar
# latensi tetap dalam target ≤ 10 detik).
DOCUMENT_VARIANTS = ("otsu", "otsu_inv", "adaptive")

PSM_BY_MODE = {
    # mode "line"     → kotak panduan segel, satu baris teks  (--psm 7)
    # mode "document" → halaman EIR, teks tersebar            (--psm 11)
    "line": (7, (7, 6)),
    "document": (11, (11, 6, 4)),
}


@dataclass
class ScanResult:
    """Hasil satu kali pemindaian."""

    text: str = ""
    ocr_text: str = ""
    confidence: float = 0.0
    engine: str = "tesseract"
    used_barcode: bool = False
    best_rotation: int = 0
    best_variant: str = ""
    score: int = 0
    candidates: list[dict] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _score_token(token: str) -> int:
    """Skor kandidat: pola alfanumerik 6–10 karakter dengan huruf + angka
    diutamakan, sehingga nomor tanggal murni angka tidak menang."""

    t = normalize(token)
    if not t:
        return 0

    has_alpha = any(c.isalpha() for c in t)
    has_digit = any(c.isdigit() for c in t)

    if PATTERN_6_10.match(t):
        if has_alpha and has_digit:
            return GOOD_SCORE_DOCUMENT + len(t)  # ciri khas nomor seal
        return 55 + len(t)
    if PATTERN_ANY.match(t) and has_alpha and has_digit:
        return 40 + len(t)
    return 0


def _candidates_from_data(data: dict) -> list[tuple[str, float]]:
    """Ekstrak kandidat dari keluaran Tesseract: per kata, per baris utuh,
    dan baris tanpa spasi (nomor seal sering terpecah jadi beberapa kata)."""

    out: list[tuple[str, float]] = []
    lines: dict[tuple, list[tuple[str, float]]] = {}

    n = len(data.get("text", []))
    blocks = data.get("block_num", [0] * n)
    pars = data.get("par_num", [0] * n)
    line_nums = data.get("line_num", [0] * n)

    for i in range(n):
        raw = (data["text"][i] or "").strip()
        try:
            conf = float(data["conf"][i])
        except (ValueError, TypeError, IndexError):
            conf = -1.0
        if not raw or conf < 0:
            continue
        out.append((raw, conf))
        key = (blocks[i], pars[i], line_nums[i])
        lines.setdefault(key, []).append((raw, conf))

    for parts in lines.values():
        if not parts:
            continue
        conf = min(c for _, c in parts)
        out.append(("".join(t for t, _ in parts), conf))
        out.append((" ".join(t for t, _ in parts), conf))

    # Hilangkan duplikat, pertahankan konfiden tertinggi
    best: dict[str, float] = {}
    for txt, conf in out:
        key = normalize(txt)
        if not key:
            continue
        if key not in best or conf > best[key]:
            best[key] = conf
    return [(k, v) for k, v in best.items()]


class OCREngine(ABC):
    """Antarmuka tunggal modul OCR."""

    name: str = "abstract"

    @abstractmethod
    def scan(
        self,
        image: np.ndarray,
        *,
        mode: str = "line",
        use_barcode: bool = False,
    ) -> ScanResult:
        """Baca nomor dari gambar. `mode`: 'line' (segel) | 'document' (EIR)."""


class TesseractEngine(OCREngine):
    name = "tesseract"

    def __init__(self, tesseract_cmd: str | None = None) -> None:
        if tesseract_cmd:
            pytesseract.pytesseract.tesseract_cmd = tesseract_cmd

    # -- utilitas ----------------------------------------------------------

    @staticmethod
    def _run(img: np.ndarray, psm: int) -> tuple[list[tuple[str, float]], float]:
        cfg = f"--oem 3 --psm {psm} -c tessedit_char_whitelist={WHITELIST}"
        try:
            data = pytesseract.image_to_data(
                img, config=cfg, output_type=pytesseract.Output.DICT
            )
        except pytesseract.TesseractError as exc:
            logger.warning("Tesseract error (psm %s): %s", psm, exc)
            return [], 0.0
        except Exception as exc:  # pragma: no cover
            logger.warning("OCR gagal: %s", exc)
            return [], 0.0

        cands = _candidates_from_data(data)
        confs = [c for _, c in cands if c > 0]
        avg = float(sum(confs) / len(confs)) if confs else 0.0
        return cands, avg

    @staticmethod
    def _downscale(img: np.ndarray) -> np.ndarray:
        h, w = img.shape[:2]
        longest = max(h, w)
        if longest <= MAX_OCR_DIMENSION:
            return img
        scale = MAX_OCR_DIMENSION / float(longest)
        return cv2.resize(
            img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA
        )

    def _variant_map(self, img: np.ndarray, mode: str) -> dict[str, np.ndarray]:
        variants = build_variants(img)
        if mode == "document":
            variants = {k: v for k, v in variants.items() if k in DOCUMENT_VARIANTS}
        return variants

    def _probes(self, img: np.ndarray, mode: str) -> dict[str, np.ndarray]:
        """Varian preprocessing: pada gambar utuh dan pada hasil content_crop."""

        probes = self._variant_map(img, mode)
        cropped = content_crop(img)
        if cropped.shape[:2] != img.shape[:2]:
            for name, variant in self._variant_map(cropped, mode).items():
                probes[f"{name}+crop"] = variant
        return probes

    # -- implementasi utama ------------------------------------------------

    def scan(
        self,
        image: np.ndarray,
        *,
        mode: str = "line",
        use_barcode: bool = False,
    ) -> ScanResult:
        if image is None or getattr(image, "size", 0) == 0:
            return ScanResult(
                engine=self.name, warnings=["Gambar kosong atau tidak terbaca."]
            )

        image = self._downscale(image)
        primary_psm, psm_seq = PSM_BY_MODE.get(mode, PSM_BY_MODE["line"])
        good_score = GOOD_SCORE_DOCUMENT if mode == "document" else GOOD_SCORE_LINE

        result = ScanResult(engine=self.name)

        # --- SEAL-30: barcode dibaca lebih dulu, OCR menjadi cadangan ------
        if use_barcode:
            code = read_barcode(image)
            if code:
                result.used_barcode = True
                result.text = code
                result.warnings.append("Nomor dibaca dari barcode segel.")

        best_score = -1
        best_text = ""
        best_conf = 0.0
        best_rotation = 0
        best_variant = ""
        scored: dict[str, tuple[float, int]] = {}

        def confident_enough(score: int, conf: float) -> bool:
            """Boleh berhenti mencari hanya bila skor bagus DAN yakin.

            Tanpa syarat konfiden, hasil baca yang salah (mis. tulisan
            terbalik terbaca jadi "SZT6UNHOWS") bisa berskor sama tinggi
            dengan nomor yang benar, sehingga rotasi berikutnya tak pernah
            dicoba dan gambar terbalik selalu gagal.
            """

            return score >= good_score and conf >= MIN_CONFIDENCE

        def consider(text: str, conf: float, rotation: int, variant: str) -> tuple[int, float]:
            nonlocal best_score, best_text, best_conf, best_rotation, best_variant
            token = normalize(text)
            score = _score_token(token)
            if not token:
                return score, conf
            prev = scored.get(token)
            if prev is None or conf > prev[0]:
                scored[token] = (conf, score)
            # Menang: skor lebih tinggi, atau skor sama dengan konfiden lebih baik
            if score > best_score or (score == best_score and conf > best_conf):
                best_score, best_text, best_conf = score, token, conf
                best_rotation, best_variant = rotation, variant
            return score, conf

        # --- Fase 1: rotasi 0, seluruh varian, psm utama -------------------
        for vname, vimg in self._probes(image, mode).items():
            cands, conf = self._run(vimg, primary_psm)
            for txt, c in cands:
                s, cc = consider(txt, c, 0, vname)
                if confident_enough(s, cc):
                    break
            if confident_enough(best_score, best_conf):
                break

        # --- Fase 2: psm cadangan pada varian terbaik ----------------------
        if not confident_enough(best_score, best_conf):
            base_name = best_variant.replace("+crop", "") or "otsu"
            for psm in psm_seq:
                if psm == primary_psm or confident_enough(best_score, best_conf):
                    continue
                source = image
                if best_variant.endswith("+crop"):
                    source = content_crop(image)
                pool = self._variant_map(source, mode)
                # Jangan pakai `or` — kebenaran array numpy ambigu dan
                # memicu ValueError saat varian yang dicari memang ada.
                vimg = pool.get(base_name)
                if vimg is None:
                    vimg = next(iter(pool.values()))
                cands, conf = self._run(vimg, psm)
                for txt, c in cands:
                    s, cc = consider(txt, c, 0, f"{base_name}[psm{psm}]")
                    if confident_enough(s, cc):
                        break

        # --- Fase 3: deteksi orientasi 0/90/180/270 (SEAL-29) --------------
        if not confident_enough(best_score, best_conf):
            for rotation in ROTATIONS[1:]:
                probes = self._probes(rotate_image(image, rotation), mode)
                for vname, vimg in probes.items():
                    cands, conf = self._run(vimg, primary_psm)
                    for txt, c in cands:
                        s, cc = consider(txt, c, rotation, vname)
                        if confident_enough(s, cc):
                            break
                    if confident_enough(best_score, best_conf):
                        break
                if confident_enough(best_score, best_conf):
                    break

        # --- Susun hasil ----------------------------------------------------
        # Kandidat berskor 0 bukan nomor seal (mis. "TERMINAL3GATEB2" hasil
        # gabungan teks sekitarnya). Jangan laporkan sebagai hasil baca:
        # lebih baik user diminta mengulang foto atau mengetik manual
        # daripada menampilkan teks sampah yang bisa salah cocok.
        if best_score <= 0:
            best_text, best_conf, best_rotation, best_variant = "", 0.0, 0, ""

        result.ocr_text = best_text
        result.confidence = round(best_conf, 1)
        result.best_rotation = best_rotation
        result.best_variant = best_variant
        result.score = max(best_score, 0)

        if not result.text:
            result.text = best_text

        ranked = sorted(
            ((t, v) for t, v in scored.items() if v[1] > 0),
            key=lambda kv: (kv[1][1], kv[1][0]),
            reverse=True,
        )
        result.candidates = [
            {"text": t, "score": s, "confidence": round(c, 1)}
            for t, (c, s) in ranked[:5]
        ]

        if not result.text:
            result.warnings.append(
                "Nomor tidak terbaca, silakan foto ulang atau ketik manual."
            )
        elif not confident_enough(best_score, best_conf):
            result.warnings.append("Hasil baca kurang yakin; mohon periksa kembali isinya.")
        if best_rotation:
            result.warnings.append(f"Gambar dirotasi {best_rotation}° sebelum dibaca.")

        return result


@lru_cache(maxsize=1)
def get_engine() -> OCREngine:
    """Singleton engine OCR — titik tunggal penggantian engine di masa depan."""
    return TesseractEngine()


def engine_available() -> bool:
    try:
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False
