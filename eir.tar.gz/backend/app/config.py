from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Konfigurasi aplikasi; seluruh nilai dapat di-override lewat environment variable."""

    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )

    # --- Umum ---
    app_name: str = "EIR Seal Verification"
    app_version: str = "1.0.0"
    api_prefix: str = "/api"
    environment: str = "production"

    # --- Keamanan / Autentikasi (SEAL-01) ---
    secret_key: str = "change-me-to-a-long-random-string"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 480  # masa berlaku token dapat diatur
    max_failed_logins: int = 5  # SEAL-08 kunci akun sementara

    # --- Database ---
    database_url: str = "postgresql+psycopg2://eir:eir@db:5432/eir"

    # --- Penyimpanan foto ---
    upload_dir: str = "/data/photos"
    max_upload_mb: int = 12

    # --- Retensi (SEAL-28): hapus foto + log pemeriksaan setelah 24 jam ---
    retention_hours: int = 24
    cleanup_enabled: bool = True
    cleanup_hour: int = 0
    cleanup_minute: int = 5

    # --- Zona waktu bisnis untuk laporan/hari berjalan ---
    business_timezone: str = "Asia/Jakarta"

    # --- Akun awal ---
    default_admin_username: str = "admin"
    default_admin_password: str = "Admin@123"
    default_admin_employee_id: str = "EMP-0001"
    default_admin_email: str = "admin@eir.local"

    # --- CORS ---
    cors_origins: str = "*"

    @property
    def upload_path(self) -> Path:
        p = Path(self.upload_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
