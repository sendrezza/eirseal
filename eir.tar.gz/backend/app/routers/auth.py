"""Endpoint autentikasi (SEAL-01, SEAL-04, SEAL-07, SEAL-08)."""

from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import create_access_token, hash_password, verify_password
from ..config import settings
from ..database import get_db
from ..deps import get_current_user
from ..models import User, utcnow
from ..schemas import (
    LoginRequest,
    Message,
    PasswordChange,
    PasswordChangeFirstLogin,
    TokenResponse,
    UserOut,
)
from ..services.audit import log_action

router = APIRouter(prefix="/auth", tags=["Autentikasi"])

INVALID_CREDENTIALS = "Username atau password salah."


def validate_password(password: str, username: str = "") -> str | None:
    """Kebijakan password minimum. Mengembalikan pesan bila tidak lolos."""

    if len(password) < 8:
        return "Password minimal 8 karakter."
    if password.lower() in (username or "").lower():
        return "Password tidak boleh sama dengan username."
    if not any(c.isalpha() for c in password) or not any(c.isdigit() for c in password):
        return "Password harus memuat minimal satu huru dan satu angka."
    return None


def _issue_token(user: User) -> TokenResponse:
    token = create_access_token(
        user_id=user.id,
        username=user.username,
        role_name=user.role.name if user.role else "",
        expires_minutes=settings.access_token_expire_minutes,
    )
    return TokenResponse(
        access_token=token,
        must_change_password=user.must_change_password,
        user=UserOut.from_user(user),
    )


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.username == payload.username))

    # Pesan sengaja seragam agar tidak membocorkan keberadaan akun.
    if user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, INVALID_CREDENTIALS)

    if not user.is_active:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN, "Akun tidak aktif. Hubungi Admin."
        )

    # SEAL-08 — kunci akun sementara setelah beberapa kali gagal login
    if user.failed_login_count >= settings.max_failed_logins:
        raise HTTPException(
            status.HTTP_423_LOCKED,
            f"Akun terkunci setelah {settings.max_failed_logins} kali gagal login. "
            "Hubungi Admin untuk membuka kunci.",
        )

    if not verify_password(payload.password, user.password_hash):
        user.failed_login_count += 1
        db.commit()
        remaining = settings.max_failed_logins - user.failed_login_count
        if remaining <= 0:
            raise HTTPException(
                status.HTTP_423_LOCKED,
                "Akun dikunci sementara karena terlalu banyak percobaan gagal.",
            )
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, INVALID_CREDENTIALS)

    user.failed_login_count = 0
    user.last_login_at = utcnow()
    db.commit()
    db.refresh(user)

    return _issue_token(user)


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return UserOut.from_user(user)


@router.post("/change-password", response_model=Message)
def change_password(
    payload: PasswordChange,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not verify_password(payload.old_password, user.password_hash):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Password lama salah.")

    error = validate_password(payload.new_password, user.username)
    if error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, error)

    if verify_password(payload.new_password, user.password_hash):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, "Password baru tidak boleh sama dengan yang lama."
        )

    before = {"must_change_password": user.must_change_password}
    user.password_hash = hash_password(payload.new_password)
    user.must_change_password = False
    db.flush()
    log_action(
        db,
        user.id,
        action="user.change_password",
        target_type="user",
        target_id=user.id,
        before=before,
        after={"must_change_password": False},
    )
    db.commit()
    return Message(message="Password berhasil diubah.")


@router.post("/change-password-first", response_model=Message)
def change_password_first(
    payload: PasswordChangeFirstLogin,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Wajib ganti password saat login pertama (SEAL-04)."""

    if not user.must_change_password:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, "Anda tidak diwajibkan mengganti password."
        )

    error = validate_password(payload.new_password, user.username)
    if error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, error)

    user.password_hash = hash_password(payload.new_password)
    user.must_change_password = False
    db.flush()
    log_action(
        db,
        user.id,
        action="user.first_login_password",
        target_type="user",
        target_id=user.id,
        before={"must_change_password": True},
        after={"must_change_password": False},
    )
    db.commit()
    return Message(message="Password berhasil diubah. Silakan lanjut.")
