"""Log audit: lihat dan Clear Log (SEAL-27, SEAL-31)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_permission
from ..models import AuditLog, User
from ..schemas import ClearLogRequest, Message, PaginatedAudit, AuditOut
from ..services.audit import log_action

router = APIRouter(prefix="/audit", tags=["Audit Log"])

CONFIRM_PHRASE = "HAPUS"


@router.get("", response_model=PaginatedAudit)
def list_audit(
    db: Session = Depends(get_db),
    _: User = Depends(require_permission("audit.view")),
    action: str | None = None,
    target_type: str | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=25, ge=1, le=200),
):
    query = select(AuditLog)
    if action:
        query = query.where(AuditLog.action == action)
    if target_type:
        query = query.where(AuditLog.target_type == target_type)

    total = db.scalar(select(func.count()).select_from(query.subquery())) or 0
    rows = db.scalars(
        query.order_by(AuditLog.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    ).all()

    return PaginatedAudit(
        items=[AuditOut.from_log(r) for r in rows],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/actions")
def list_actions(
    db: Session = Depends(get_db),
    _: User = Depends(require_permission("audit.view")),
):
    rows = db.scalars(select(AuditLog.action).distinct().order_by(AuditLog.action)).all()
    return {"actions": rows}


@router.delete("", response_model=Message)
def clear_audit(
    payload: ClearLogRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(require_permission("audit.clear")),
):
    """Clear log audit manual oleh Admin (SEAL-31).

    Log audit perubahan user tidak pernah dihapus otomatis oleh job retensi;
    penghapusan hanya terjadi di sini, dengan konfirmasi, dan jejak aksi
    pembersihan itu sendiri tetap dicatat.
    """
    if payload.confirmation.strip().upper() != CONFIRM_PHRASE:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f'Konfirmasi salah. Ketik "{CONFIRM_PHRASE}" untuk melanjutkan.',
        )

    existing = db.scalar(select(func.count()).select_from(AuditLog)) or 0
    db.execute(delete(AuditLog))
    log_action(
        db,
        admin.id,
        action="audit.clear",
        target_type="audit_log",
        after={"cleared_entries": existing, "cleared_by": admin.username},
    )
    db.commit()

    return Message(
        message=f"{existing} entri log audit berhasil dihapus.",
        detail={"cleared": existing},
    )
