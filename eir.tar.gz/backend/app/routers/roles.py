"""Master Role — hak akses per fitur (SEAL-06, Lampiran A)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_permission
from ..models import PERMISSION_CATALOG, Role, User
from ..schemas import Message, RoleCreate, RoleOut, RoleUpdate
from ..services.audit import log_action

router = APIRouter(prefix="/roles", tags=["Master Role"])


def _to_out(role: Role) -> RoleOut:
    return RoleOut(
        id=role.id,
        name=role.name,
        description=role.description,
        permissions=role.permissions or [],
        history_scope=role.history_scope,
        is_system=role.is_system,
        user_count=len(role.users),
    )


def _snapshot(role: Role) -> dict:
    return {
        "name": role.name,
        "description": role.description,
        "permissions": role.permissions or [],
        "history_scope": role.history_scope,
    }


@router.get("/permissions")
def permission_catalog(_: object = Depends(require_permission("roles.manage"))):
    """Daftar hak akses yang tersedia untuk dipilih di Master Role."""
    return {
        "permissions": PERMISSION_CATALOG,
        "history_scopes": [
            {"value": "all", "label": "Semua lokasi"},
            {"value": "location", "label": "Lokasi sendiri"},
            {"value": "own", "label": "Milik sendiri"},
        ],
    }


@router.get("", response_model=list[RoleOut])
def list_roles(db: Session = Depends(get_db), _=Depends(get_current_user)):
    roles = db.scalars(select(Role).order_by(Role.id)).all()
    return [_to_out(r) for r in roles]


@router.post("", response_model=RoleOut, status_code=status.HTTP_201_CREATED)
def create_role(
    payload: RoleCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission("roles.manage")),
):
    exists = db.scalar(select(Role).where(Role.name == payload.name))
    if exists is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "Nama role sudah dipakai.")

    role = Role(**payload.model_dump())
    db.add(role)
    db.flush()
    log_action(
        db,
        actor.id,
        action="role.create",
        target_type="role",
        target_id=role.id,
        after=_snapshot(role),
    )
    db.commit()
    db.refresh(role)
    return _to_out(role)


@router.get("/{role_id}", response_model=RoleOut)
def get_role(role_id: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    role = db.get(Role, role_id)
    if role is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Role tidak ditemukan.")
    return _to_out(role)


@router.put("/{role_id}", response_model=RoleOut)
def update_role(
    role_id: int,
    payload: RoleUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission("roles.manage")),
):
    role = db.get(Role, role_id)
    if role is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Role tidak ditemukan.")

    data = payload.model_dump(exclude_unset=True)
    if "name" in data:
        dup = db.scalar(
            select(Role).where(Role.name == data["name"], Role.id != role.id)
        )
        if dup is not None:
            raise HTTPException(status.HTTP_409_CONFLICT, "Nama role sudah dipakai.")

    before = _snapshot(role)
    for field, value in data.items():
        setattr(role, field, value)
    db.flush()

    # Pastikan selalu ada minimal satu Admin aktif dengan akses user/role
    if role.name == "Admin" and not (role.permissions or []):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "Role Admin tidak boleh kehilangan seluruh hak akses.",
        )

    log_action(
        db,
        actor.id,
        action="role.update",
        target_type="role",
        target_id=role.id,
        before=before,
        after=_snapshot(role),
    )
    db.commit()
    db.refresh(role)
    return _to_out(role)


@router.delete("/{role_id}", response_model=Message)
def delete_role(
    role_id: int,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission("roles.manage")),
):
    role = db.get(Role, role_id)
    if role is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Role tidak ditemukan.")
    if role.is_system:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, "Role bawaan sistem tidak dapat dihapus."
        )
    used = (
        db.scalar(select(func.count()).select_from(User).where(User.role_id == role.id))
        or 0
    )
    if used:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"Role masih dipakai oleh {used} user. Alihkan user tersebut terlebih dahulu.",
        )

    before = _snapshot(role)
    db.delete(role)
    log_action(
        db,
        actor.id,
        action="role.delete",
        target_type="role",
        target_id=role_id,
        before=before,
    )
    db.commit()
    return Message(message="Role berhasil dihapus.")
