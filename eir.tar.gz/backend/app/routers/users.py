"""Master User (SEAL-02 .. SEAL-05). Hapus selalu bersifat soft delete."""

from __future__ import annotations

import secrets
import string

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..auth import hash_password
from ..database import get_db
from ..deps import require_permission
from ..models import Role, User
from ..schemas import Message, PaginatedUsers, UserCreate, UserOut, UserUpdate
from ..services.audit import log_action

router = APIRouter(prefix="/users", tags=["Master User"])

DepAdmin = Depends(require_permission("users.manage"))


def _snapshot(user: User) -> dict:
    return {
        "employee_id": user.employee_id,
        "full_name": user.full_name,
        "email": user.email,
        "username": user.username,
        "role_id": user.role_id,
        "role_name": user.role.name if user.role else None,
        "location": user.location,
        "is_active": user.is_active,
    }


def _ensure_unique(
    db: Session,
    field_name: str,
    value: str,
    exclude_id: int | None = None,
) -> None:
    query = select(User).where(getattr(User, field_name) == value)
    if exclude_id is not None:
        query = query.where(User.id != exclude_id)
    if db.scalar(query) is not None:
        labels = {"employee_id": "ID Karyawan", "email": "Email", "username": "Username"}
        raise HTTPException(
            status.HTTP_409_CONFLICT, f"{labels.get(field_name, field_name)} sudah dipakai."
        )


@router.get("", response_model=PaginatedUsers)
def list_users(
    db: Session = Depends(get_db),
    _=DepAdmin,
    q: str | None = Query(default=None, max_length=120),
    role_id: int | None = None,
    location: str | None = None,
    status_filter: str | None = Query(default=None, alias="status"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=200),
):
    query = select(User)
    if q:
        like = f"%{q.strip()}%"
        query = query.where(
            or_(
                User.full_name.ilike(like),
                User.username.ilike(like),
                User.employee_id.ilike(like),
                User.email.ilike(like),
            )
        )
    if role_id is not None:
        query = query.where(User.role_id == role_id)
    if location:
        query = query.where(User.location == location)
    if status_filter == "active":
        query = query.where(User.is_active.is_(True))
    elif status_filter == "inactive":
        query = query.where(User.is_active.is_(False))

    total = db.scalar(select(func.count()).select_from(query.subquery())) or 0
    rows = (
        db.scalars(
            query.order_by(User.full_name).offset((page - 1) * page_size).limit(page_size)
        ).all()
    )
    return PaginatedUsers(
        items=[UserOut.from_user(u) for u in rows],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(
    payload: UserCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission("users.manage")),
):
    if db.get(Role, payload.role_id) is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Role tidak ditemukan.")

    _ensure_unique(db, "employee_id", payload.employee_id)
    _ensure_unique(db, "email", payload.email)
    _ensure_unique(db, "username", payload.username)

    from .auth import validate_password

    error = validate_password(payload.password, payload.username)
    if error:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, error)

    user = User(
        employee_id=payload.employee_id,
        full_name=payload.full_name,
        email=payload.email,
        username=payload.username,
        password_hash=hash_password(payload.password),
        role_id=payload.role_id,
        location=payload.location,
        is_active=payload.is_active,
        must_change_password=True,
    )
    db.add(user)
    db.flush()
    log_action(
        db,
        actor.id,
        action="user.create",
        target_type="user",
        target_id=user.id,
        after=_snapshot(user),
    )
    db.commit()
    db.refresh(user)
    return UserOut.from_user(user)


@router.get("/{user_id}", response_model=UserOut)
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    _=DepAdmin,
):
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User tidak ditemukan.")
    return UserOut.from_user(user)


@router.put("/{user_id}", response_model=UserOut)
def update_user(
    user_id: int,
    payload: UserUpdate,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission("users.manage")),
):
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User tidak ditemukan.")

    data = payload.model_dump(exclude_unset=True)
    new_password = data.pop("password", None)
    before = _snapshot(user)

    if "role_id" in data and data["role_id"] is not None:
        if db.get(Role, data["role_id"]) is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Role tidak ditemukan.")

    for field in ("employee_id", "email", "username"):
        if data.get(field) and data[field] != getattr(user, field):
            _ensure_unique(db, field, data[field], exclude_id=user.id)

    for field, value in data.items():
        if value is not None or field in ("location",):
            setattr(user, field, value)

    if new_password:
        from .auth import validate_password

        error = validate_password(new_password, user.username)
        if error:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, error)
        user.password_hash = hash_password(new_password)
        user.must_change_password = True
        user.failed_login_count = 0

    db.flush()
    log_action(
        db,
        actor.id,
        action="user.update",
        target_type="user",
        target_id=user.id,
        before=before,
        after=_snapshot(user),
    )
    db.commit()
    db.refresh(user)
    return UserOut.from_user(user)


@router.delete("/{user_id}", response_model=UserOut)
def deactivate_user(
    user_id: int,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission("users.manage")),
):
    """Soft delete — user tidak dihapus permanen karena terkait log (SEAL-02)."""
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User tidak ditemukan.")
    if user.id == actor.id:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, "Tidak dapat menonaktifkan akun sendiri."
        )

    before = _snapshot(user)
    user.is_active = False
    db.flush()
    log_action(
        db,
        actor.id,
        action="user.deactivate",
        target_type="user",
        target_id=user.id,
        before=before,
        after=_snapshot(user),
    )
    db.commit()
    db.refresh(user)
    return UserOut.from_user(user)


def _temp_password(length: int = 12) -> str:
    alphabet = string.ascii_letters + string.digits
    while True:
        value = "".join(secrets.choice(alphabet) for _ in range(length))
        if any(c.isalpha() for c in value) and any(c.isdigit() for c in value):
            return value


@router.post("/{user_id}/reset-password", response_model=Message)
def reset_password(
    user_id: int,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission("users.manage")),
):
    """Reset password oleh Admin (SEAL-04) — menghasilkan password sementara
    yang wajib diganti user saat login berikutnya."""
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User tidak ditemukan.")

    temporary = _temp_password()
    user.password_hash = hash_password(temporary)
    user.must_change_password = True
    user.failed_login_count = 0
    db.flush()
    log_action(
        db,
        actor.id,
        action="user.reset_password",
        target_type="user",
        target_id=user.id,
        after={"reset_by": actor.username},
    )
    db.commit()
    return Message(
        message="Password berhasil direset.",
        detail={"temporary_password": temporary, "username": user.username},
    )
