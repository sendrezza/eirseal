"""Pemeriksaan Seal — alur inti aplikasi (SEAL-11 .. SEAL-31)."""

from __future__ import annotations

import logging

import cv2
import numpy as np
from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Query,
    Request,
    UploadFile,
    status,
)
from fastapi.responses import StreamingResponse
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session
from starlette.concurrency import run_in_threadpool

from ..config import settings
from ..database import get_db
from ..deps import (
    apply_history_scope,
    require_permission,
)
from ..models import SealCheck, User, utcnow
from ..ocr import get_engine, compare, normalize, validate_format
from ..ocr.engine import engine_available
from ..schemas import (
    CheckCreate,
    CheckOut,
    DashboardOut,
    FollowUpRequest,
    MatchPreviewRequest,
    MatchResult,
    Message,
    PaginatedChecks,
    ScanResponse,
)
from ..services.audit import log_action
from ..services.excel import build_checks_workbook
from ..services.storage import photo_path, save_photo
from ..timeutils import day_bounds, parse_date

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/checks", tags=["Pemeriksaan Seal"])

ALLOWED_KINDS = {"eir", "seal"}


# ---------------------------------------------------------------------------
# Pemindaian foto (SEAL-11, 12, 13, 29, 30)
# ---------------------------------------------------------------------------


@router.post("/scan", response_model=ScanResponse)
async def scan_photo(
    request: Request,
    file: UploadFile = File(...),
    kind: str | None = Query(default=None, pattern="^(eir|seal)$"),
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("checks.create")),
):
    """Unggah foto → crop di klien sudah dilakukan → simpan foto → OCR.

    `kind=eir`   : dokumen EIR (kertas) — mode teks tersebar, tanpa barcode.
    `kind=seal`  : segel fisik — mode satu baris; barcode dibaca lebih dulu
                   bila ada (SEAL-30), OCR menjadi cadangan.

    `kind` seharusnya dikirim sebagai parameter query. Sebagai pengaman,
    nilai yang dikirim sebagai field form masih diterima — bila tidak,
    kesalahan klien diam-diam menurunkan pemindaian dokumen EIR ke mode
    satu baris sehingga nomor seal tidak terbaca di antara teks dokumen.
    """
    if kind is None:
        try:
            form = await request.form()
        except Exception:  # pragma: no cover - multipart rusak
            form = {}
        candidate = form.get("kind")
        kind = candidate if candidate in ALLOWED_KINDS else "seal"

    if kind not in ALLOWED_KINDS:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Jenis foto tidak dikenal.")

    data = await file.read()
    if not data:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "File kosong.")
    limit = settings.max_upload_mb * 1024 * 1024
    if len(data) > limit:
        raise HTTPException(
            status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            f"Ukuran foto maksimal {settings.max_upload_mb} MB.",
        )

    buffer = np.frombuffer(data, dtype=np.uint8)
    image = cv2.imdecode(buffer, cv2.IMREAD_COLOR)
    if image is None:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "Format gambar tidak didukung. Gunakan JPG atau PNG.",
        )

    suffix = ".png" if data[:4] == b"\x89PNG" else ".jpg"
    filename = save_photo(data, suffix=suffix)

    engine = get_engine()
    use_barcode = kind == "seal"  # SEAL-30
    mode = "document" if kind == "eir" else "line"

    try:
        result = await run_in_threadpool(
            engine.scan, image, mode=mode, use_barcode=use_barcode
        )
    except Exception as exc:  # pragma: no cover
        logger.exception("OCR gagal")
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR, f"Pemrosesan OCR gagal: {exc}"
        )

    warnings = list(result.warnings)
    if not engine_available():
        warnings.append(
            "Tesseract tidak terpasang pada server; silakan ketik nomor secara manual."
        )

    return ScanResponse(
        photo_id=filename,
        photo_url=f"{settings.api_prefix}/photos/{filename}",
        ocr_raw=result.text,
        ocr_confidence=result.confidence,
        engine=result.engine,
        used_barcode=result.used_barcode,
        best_rotation=result.best_rotation,
        candidates=result.candidates,
        warnings=warnings,
    )


# ---------------------------------------------------------------------------
# Pratinjau pencocokan (SEAL-15, SEAL-20)
# ---------------------------------------------------------------------------


@router.post("/preview", response_model=MatchResult)
def preview_match(
    payload: MatchPreviewRequest,
    _: User = Depends(require_permission("checks.create")),
):
    """Hitung hasil pencocokan tanpa menyimpan — dipakai untuk menampilkan
    peringatan kuning 'hampir sama' sebelum hasil final (SEAL-20)."""
    return compare(payload.seal_eir_final, payload.seal_actual_final)


# ---------------------------------------------------------------------------
# Penyimpanan hasil pemeriksaan (SEAL-16, SEAL-18)
# ---------------------------------------------------------------------------


@router.post("", response_model=CheckOut, status_code=status.HTTP_201_CREATED)
def create_check(
    payload: CheckCreate,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("checks.create")),
):
    outcome = compare(payload.seal_eir_final, payload.seal_actual_final)

    def _url(photo_id: str | None) -> str | None:
        if not photo_id:
            return None
        if photo_path(photo_id) is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Referensi foto tidak valid.")
        return f"{settings.api_prefix}/photos/{photo_id}"

    eir_url = _url(payload.eir_photo_id)
    seal_url = _url(payload.seal_photo_id)

    edited = False
    for raw, final in (
        (payload.seal_eir_ocr_raw, payload.seal_eir_final),
        (payload.seal_actual_ocr_raw, payload.seal_actual_final),
    ):
        if raw is not None and normalize(raw) != normalize(final):
            edited = True  # SEAL-19

    check = SealCheck(
        user_id=user.id,
        location=user.location,
        eir_no=payload.eir_no,
        container_no=payload.container_no,
        booking_no=payload.booking_no,
        seal_eir_ocr_raw=payload.seal_eir_ocr_raw,
        seal_eir_final=normalize(payload.seal_eir_final) or payload.seal_eir_final.strip(),
        seal_actual_ocr_raw=payload.seal_actual_ocr_raw,
        seal_actual_final=normalize(payload.seal_actual_final)
        or payload.seal_actual_final.strip(),
        result=outcome["result"],
        near_match_flag=outcome["near_match"],
        edited_flag=edited,
        eir_photo_url=eir_url,
        seal_photo_url=seal_url,
        notes=payload.notes,
        ref_check_id=payload.ref_check_id,
    )
    db.add(check)
    db.flush()
    log_action(
        db,
        user.id,
        action="check.create",
        target_type="seal_check",
        target_id=check.id,
        after={
            "result": check.result,
            "seal_eir_final": check.seal_eir_final,
            "seal_actual_final": check.seal_actual_final,
            "edited_flag": check.edited_flag,
        },
    )
    db.commit()
    db.refresh(check)
    return CheckOut.from_check(check)


# ---------------------------------------------------------------------------
# Riwayat, dashboard, export (SEAL-22, 24, 25)
# ---------------------------------------------------------------------------


def _filtered_checks(query, params_query: dict):
    """Terapkan filter riwayat umum."""
    q = query
    date_from = parse_date(params_query.get("date_from"))
    date_to = parse_date(params_query.get("date_to"))
    if date_from:
        start, _ = day_bounds(date_from)
        q = q.where(SealCheck.checked_at >= start)
    if date_to:
        _, end = day_bounds(date_to)
        q = q.where(SealCheck.checked_at < end)
    if params_query.get("result"):
        q = q.where(SealCheck.result == params_query["result"])
    if params_query.get("location"):
        q = q.where(SealCheck.location == params_query["location"])
    if params_query.get("user_id"):
        q = q.where(SealCheck.user_id == params_query["user_id"])
    if params_query.get("container_no"):
        q = q.where(
            SealCheck.container_no.ilike(f"%{params_query['container_no'].strip()}%")
        )
    if params_query.get("eir_no"):
        q = q.where(SealCheck.eir_no.ilike(f"%{params_query['eir_no'].strip()}%"))
    keyword = (params_query.get("q") or "").strip()
    if keyword:
        like = f"%{keyword}%"
        q = q.where(
            or_(
                SealCheck.container_no.ilike(like),
                SealCheck.eir_no.ilike(like),
                SealCheck.booking_no.ilike(like),
                SealCheck.seal_eir_final.ilike(like),
                SealCheck.seal_actual_final.ilike(like),
            )
        )
    return q


@router.get("", response_model=PaginatedChecks)
def list_checks(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("checks.view")),
    date_from: str | None = None,
    date_to: str | None = None,
    result: str | None = Query(default=None, pattern="^(SUCCESS|FAILED)$"),
    location: str | None = None,
    user_id: int | None = None,
    container_no: str | None = None,
    eir_no: str | None = None,
    q: str | None = None,
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=200),
):
    params = dict(
        date_from=date_from,
        date_to=date_to,
        result=result,
        location=location,
        user_id=user_id,
        container_no=container_no,
        eir_no=eir_no,
        q=q,
    )
    query = apply_history_scope(select(SealCheck), user, SealCheck)
    query = _filtered_checks(query, params)

    total = db.scalar(select(func.count()).select_from(query.subquery())) or 0
    rows = db.scalars(
        query.order_by(SealCheck.checked_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    ).all()

    return PaginatedChecks(
        items=[CheckOut.from_check(c) for c in rows],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/dashboard", response_model=DashboardOut)
def dashboard(
    db: Session = Depends(get_db),
    _: User = Depends(require_permission("dashboard.view")),
    date: str | None = None,
):
    """Ringkasan pemeriksaan hari berjalan (SEAL-25)."""
    from datetime import date as date_cls

    day = parse_date(date) or date_cls.today()
    start, end = day_bounds(day)

    base = select(SealCheck).where(
        SealCheck.checked_at >= start, SealCheck.checked_at < end
    )
    rows = db.scalars(base).all()
    total = len(rows)
    success = sum(1 for c in rows if c.result == "SUCCESS")
    failed = total - success

    return DashboardOut(
        date=day.isoformat(),
        total=total,
        success=success,
        failed=failed,
        success_pct=round(success * 100 / total, 1) if total else 0.0,
        failed_pct=round(failed * 100 / total, 1) if total else 0.0,
    )


@router.get("/export")
def export_checks(
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("reports.export")),
    date_from: str | None = None,
    date_to: str | None = None,
    result: str | None = Query(default=None, pattern="^(SUCCESS|FAILED)$"),
    location: str | None = None,
    user_id: int | None = None,
    container_no: str | None = None,
    eir_no: str | None = None,
    q: str | None = None,
):
    """Rekap ke Excel mengikuti filter yang aktif (SEAL-24).

    Penting: data pemeriksaan hanya bertahan 24 jam (SEAL-28), sehingga export
    harus dilakukan sebelum penghapusan otomatis.
    """
    params = dict(
        date_from=date_from,
        date_to=date_to,
        result=result,
        location=location,
        user_id=user_id,
        container_no=container_no,
        eir_no=eir_no,
        q=q,
    )
    query = apply_history_scope(select(SealCheck), user, SealCheck)
    query = _filtered_checks(query, params).order_by(SealCheck.checked_at.desc())

    rows = db.scalars(query.limit(50000)).all()
    buffer = build_checks_workbook(rows)

    filename = f"pemeriksaan-seal-{utcnow():%Y%m%d-%H%M%S}.xlsx"
    return StreamingResponse(
        buffer,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Total-Rows": str(len(rows)),
            "X-Retention-Note": (
                f"Pemeriksaan dihapus otomatis {settings.retention_hours} jam "
                "setelah dibuat; ekspor ini adalah catatan jangka panjang."
            ),
        },
    )


# ---------------------------------------------------------------------------
# Detail dan tindak lanjut (SEAL-23, SEAL-26)
# ---------------------------------------------------------------------------


def _load_check(db: Session, user: User, check_id: int) -> SealCheck:
    check = db.get(SealCheck, check_id)
    if check is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Pemeriksaan tidak ditemukan.")

    scope = user.role.history_scope if user.role else "own"
    allowed = (
        scope == "all"
        or (scope == "location" and user.location and check.location == user.location)
        or (scope == "own" and check.user_id == user.id)
    )
    if not allowed:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Anda tidak memiliki akses melihat pemeriksaan ini.",
        )
    return check


@router.get("/{check_id}", response_model=CheckOut)
def get_check(
    check_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("checks.view")),
):
    return CheckOut.from_check(_load_check(db, user, check_id))


@router.post("/{check_id}/follow-up", response_model=CheckOut)
def add_follow_up(
    check_id: int,
    payload: FollowUpRequest,
    db: Session = Depends(get_db),
    user: User = Depends(require_permission("followup.manage")),
):
    """Catatan tindak lanjut Supervisor/Admin pada kasus Failed (SEAL-26)."""
    check = _load_check(db, user, check_id)
    if check.result != "FAILED":
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "Tindak lanjut hanya dapat diberikan pada kasus Tidak Sesuai.",
        )

    before = {"follow_up_notes": check.follow_up_notes}
    check.follow_up_notes = payload.notes
    check.follow_up_by_id = user.id
    check.follow_up_at = utcnow()
    db.flush()
    log_action(
        db,
        user.id,
        action="check.follow_up",
        target_type="seal_check",
        target_id=check.id,
        before=before,
        after={"follow_up_notes": check.follow_up_notes},
    )
    db.commit()
    db.refresh(check)
    return CheckOut.from_check(check)


__all__ = ["router", "validate_format"]
