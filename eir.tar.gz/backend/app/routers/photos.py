"""Penyajian foto pemeriksaan — hanya untuk user yang berhak (Bagian 10)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user
from ..models import User
from ..services.storage import photo_path

router = APIRouter(prefix="/photos", tags=["Foto"])

MEDIA_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
}


@router.get("/{filename}")
def get_photo(
    filename: str,
    _: Session = Depends(get_db),
    __: User = Depends(get_current_user),
):
    path = photo_path(filename)
    if path is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Nama file tidak valid.")
    if not path.is_file():
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            "Foto tidak tersedia (kemungkinan sudah melewati masa retensi).",
        )
    media = MEDIA_TYPES.get(path.suffix.lower(), "application/octet-stream")
    # Tanpa `filename` agar FastAPI tidak menambah header Content-Disposition
    # attachment, yang dapat menggagalkan penampilan <img> di browser.
    return FileResponse(path, media_type=media)
