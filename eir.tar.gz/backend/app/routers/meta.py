"""Endpoint metadata dan kesehatan sistem."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..deps import get_current_user
from ..models import SealCheck, User
from ..ocr.engine import engine_available, get_engine

router = APIRouter(prefix="/meta", tags=["Metadata"])


@router.get("/health")
def health(db: Session = Depends(get_db)):
    """Uji cepat: status database dan ketersediaan engine OCR."""
    db_ok = True
    try:
        db.execute(select(func.count()).select_from(User))
    except Exception:
        db_ok = False

    ocr_ok = engine_available()
    return {
        "status": "ok" if db_ok else "degraded",
        "version": settings.app_version,
        "database": "up" if db_ok else "down",
        "ocr_engine": get_engine().name,
        "ocr_available": ocr_ok,
        "retention_hours": settings.retention_hours,
        "timezone": settings.business_timezone,
    }


@router.get("/locations")
def locations(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """Daftar lokasi/cabang untuk filter riwayat dan form master."""
    user_locs = db.scalars(
        select(User.location)
        .where(User.location.is_not(None))
        .where(User.location != "")
        .distinct()
    ).all()
    check_locs = db.scalars(
        select(SealCheck.location)
        .where(SealCheck.location.is_not(None))
        .where(SealCheck.location != "")
        .distinct()
    ).all()
    return {"locations": sorted(set(user_locs) | set(check_locs))}


@router.get("/app-info")
def app_info(_: User = Depends(get_current_user)):
    """Informasi aplikasi yang berguna di layar (retensi, dsb.)."""
    return {
        "app_name": settings.app_name,
        "version": settings.app_version,
        "retention_hours": settings.retention_hours,
        "max_upload_mb": settings.max_upload_mb,
        "timezone": settings.business_timezone,
        "max_failed_logins": settings.max_failed_logins,
        "token_expire_minutes": settings.access_token_expire_minutes,
    }
