"""Dependency autentikasi dan kontrol hak akses (peran + Lampiran A)."""

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from .auth import decode_access_token
from .config import settings
from .database import get_db
from .models import User

bearer_scheme = HTTPBearer(auto_error=False)

# Selama user wajib mengganti password (SEAL-04), hanya rute berikut yang
# boleh dipakai. Rute lain ditolak di tingkat API — penguncian di sisi
# antarmuka saja tidak cukup karena token tetap sah dan dapat dipakai
# langsung lewat klien HTTP.
PASSWORD_CHANGE_ALLOWED = {
    f"{settings.api_prefix}/auth/me",
    f"{settings.api_prefix}/auth/change-password",
    f"{settings.api_prefix}/auth/change-password-first",
}


def _unauthorized(detail: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=detail,
        headers={"WWW-Authenticate": "Bearer"},
    )


def get_current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User:
    if credentials is None or not credentials.credentials:
        raise _unauthorized("Token tidak ditemukan. Silakan login ulang.")

    try:
        payload = decode_access_token(credentials.credentials)
    except Exception:
        raise _unauthorized("Sesi tidak valid atau kedaluwarsa. Silakan login ulang.")

    user = db.get(User, int(payload.get("sub", 0)))
    if user is None:
        raise _unauthorized("Akun tidak ditemukan.")
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Akun tidak aktif."
        )
    if user.must_change_password and request.url.path not in PASSWORD_CHANGE_ALLOWED:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Anda wajib mengganti password terlebih dahulu.",
        )
    return user


def get_optional_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User | None:
    if credentials is None:
        return None
    try:
        return get_current_user(request, credentials, db)
    except HTTPException:
        return None


def require_permission(permission: str):
    """Factory dependency: hanya lolos bila role user memiliki `permission`."""

    def checker(user: User = Depends(get_current_user)) -> User:
        perms = user.role.permissions if user.role else []
        if permission not in perms:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Anda tidak memiliki akses: {permission}",
            )
        return user

    return checker


def require_admin(user: User = Depends(get_current_user)) -> User:
    if (user.role.permissions if user.role else []).count("users.manage") == 0:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hanya Admin yang dapat melakukan aksi ini.",
        )
    return user


def scope_location(user: User) -> str:
    """Riwayat yang boleh dilihat user: all | location | own (Lampiran A)."""
    return (user.role.history_scope if user.role else "own") or "own"


def apply_history_scope(query, user: User, model):
    """Batasi query pemeriksaan sesuai cakupan riwayat role."""
    scope = scope_location(user)
    if scope == "all":
        return query
    if scope == "location":
        if not user.location:
            return query.filter(model.user_id == user.id)
        return query.filter(model.location == user.location)
    return query.filter(model.user_id == user.id)
