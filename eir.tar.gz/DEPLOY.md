# Deploy ke VPS Ubuntu

Panduan memasang aplikasi ini di VPS Ubuntu Linux (22.04 / 24.04 LTS) dengan
Docker Compose + HTTPS (Let's Encrypt). HTTPS wajib karena akses kamera HP
hanya diizinkan browser pada konteks aman (SEAL‑11 / Bagian 10 PRD).

---

## 1. Prasyarat

| Kebutuhan | Keterangan |
| --- | --- |
| OS | Ubuntu 22.04 / 24.04 LTS (user dengan `sudo`) |
| RAM | minimal 2 GB (4 GB nyaman); bila VPS 1 GB, buat swap — lihat §9 |
| Domain | **Disarankan** — `eir.contoh.com` yang A‑record mengarah ke IP VPS. Tanpa domain hanya bisa memakai sertifikat self‑signed (uji/intranet) |
| Port | 80 (HTTP) dan 443 (HTTPS) terbuka — di firewall VPS **dan** firewall cloud (security group) |
| Resource disk | ± 3 GB untuk image Docker + build |

## 2. Install Docker Engine + Docker Compose plugin

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl

sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
https://download.docker.com/linux/ubuntu \
$(. /etc/os-release && echo "${VERSION_CODENAME}") stable" | \
sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io \
  docker-buildx-plugin docker-compose-plugin

# Agar tidak perlu sudo tiap kali menjalankan docker (lalu logout/login):
sudo usermod -aG docker "$USER"
```

Pastikan engine menyala:

```bash
sudo systemctl enable --now docker
docker version
docker compose version
```

## 3. Salin proyek ke VPS

Dari mesin Windows (di folder proyek `D:\Project App\eir`):

```powershell
# 1. Kemas proyek tanpa file yang tidak perlu
tar czf $env:TEMP\eir.tar.gz `
  --exclude node_modules --exclude dist --exclude .git `
  --exclude .env --exclude nginx/certs .

# 2. Unggah + ekstrak
scp $env:TEMP\eir.tar.gz user@IP-VPS:/tmp/
ssh user@IP-VPS "mkdir -p /opt/eir && tar xzf /tmp/eir.tar.gz -C /opt/eir && rm /tmp/eir.tar.gz"
```

Bila proyek sudah di‑host di GitLab/GitHub, cukup:

```bash
sudo git clone <url-repo> /opt/eir
```

> `.env` sengaja **tidak** ikut disalin — dibuat segar di VPS (§4).
> `nginx/certs` juga tidak ikut — berisi sertifikat self‑signed lokal.

## 4. Buat file `.env` di VPS

```bash
cd /opt/eir
cp .env.example .env
nano .env        # atau: vi .env
```

**Wajib diganti** (semua nilai acak panjang):

```bash
openssl rand -hex 32   # jalankan sekali, tempel hasilnya ke POSTGRES_PASSWORD
openssl rand -hex 32   # jalankan lagi, tempel hasilnya ke SECRET_KEY
```

Selain itu periksa:

| Variabel | Saran |
| --- | --- |
| `BUSINESS_TIMEZONE` | `Asia/Jakarta` (bawaan) |
| `DEFAULT_ADMIN_PASSWORD` | ganti agar akun awal bukan `Admin@123` |
| `RETENTION_HOURS` | `24` (bawaan, sesuai PRD) |
| `CLEANUP_HOUR` / `CLEANUP_MINUTE` | jam UTC pembersihan otomatis |

> ⚠️ `POSTGRES_PASSWORD` hanya dipakai saat **inisialisasi** volume database
> pertama kali. Mengubahnya setelah data ada harus disertai
> `ALTER USER eir WITH PASSWORD '...'` di dalam Postgres.

## 5. Sertifikat TLS

### 5a. Let's Encrypt (disarankan — butuh domain)

```bash
sudo apt-get install -y certbot

# Port 80 masih bebas karena stack belum dijalankan:
sudo certbot certonly --standalone --non-interactive --agree-tos \
  -m email@contoh.com -d eir.contoh.com

mkdir -p /opt/eir/nginx/certs
sudo cp /etc/letsencrypt/live/eir.contoh.com/fullchain.pem /opt/eir/nginx/certs/
sudo cp /etc/letsencrypt/live/eir.contoh.com/privkey.pem  /opt/eir/nginx/certs/
sudo chown "$USER" /opt/eir/nginx/certs/*.pem
```

**Perpanjangan otomatis.** Certbot renewal memakai mode standalone yang butuh
port 80 bebas, sedangkan container Nginx memegang port 80. Selesaikan dengan
hook:

```bash
sudo mkdir -p /etc/letsencrypt/renewal-hooks/{pre,post,deploy}

sudo tee /etc/letsencrypt/renewal-hooks/pre/eir-stop-web.sh >/dev/null <<'EOF'
#!/bin/sh
docker compose -f /opt/eir/docker-compose.yml -f /opt/eir/docker-compose.prod.yml stop web
EOF

sudo tee /etc/letsencrypt/renewal-hooks/post/eir-start-web.sh >/dev/null <<'EOF'
#!/bin/sh
docker compose -f /opt/eir/docker-compose.yml -f /opt/eir/docker-compose.prod.yml start web
EOF

sudo tee /etc/letsencrypt/renewal-hooks/deploy/eir-copy-certs.sh >/dev/null <<EOF
#!/bin/sh
cp /etc/letsencrypt/live/eir.contoh.com/fullchain.pem /opt/eir/nginx/certs/fullchain.pem
cp /etc/letsencrypt/live/eir.contoh.com/privkey.pem  /opt/eir/nginx/certs/privkey.pem
chown $USER /opt/eir/nginx/certs/*.pem
EOF

sudo chmod +x /etc/letsencrypt/renewal-hooks/*/*.sh
```

Urutan kerjanya saat `certbot renew` (berjalan otomatis lewat
`certbot.timer`): stop Nginx → validasi + terbitkan sertifikat baru → salin
sertifikat → start Nginx (langsung memakai sertifikat baru). Uji manual dengan:

```bash
sudo certbot renew --dry-run
```

### 5b. Self‑signed (tanpa domain — hanya uji/intranet)

```bash
mkdir -p /opt/eir/nginx/certs
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -subj "/CN=eir.local" \
  -keyout /opt/eir/nginx/certs/privkey.pem \
  -out    /opt/eir/nginx/certs/fullchain.pem
```

Browser akan memperingatkan sertifikat tidak tepercaya; lanjutkan saja untuk
uji. Untuk pemakaian nyata, gunakan domain + Let's Encrypt (5a).

## 6. Firewall

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status
```

Jangan lupa membuka port yang sama di firewall penyedia VPS (AWS Security
Group, GCP Firewall Rules, panel DigitalOcean/dll).

## 7. Jalankan stack

```bash
cd /opt/eir
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build
```

Build pertama memakan waktu beberapa menit (apt Tesseract, pip, npm build
React). Pantau:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml logs -f api
docker compose -f docker-compose.yml -f docker-compose.prod.yml ps
```

Semua container harus `healthy`/`Up`:

```bash
curl -s https://localhost/api/meta/health -k
```

## 8. Verifikasi akhir

1. Buka `https://eir.contoh.com` dari HP → halaman Login muncul.
2. Login `admin` / password awal → **wajib** ganti password (SEAL‑04).
3. Buat user Operator + Supervisor di Master User.
4. Pemeriksaan Baru → izinkan kamera → foto dua nomor yang sama → layar hijau.
5. Ulangi dengan nomor berbeda → layar merah.
6. Riwayat → filter → Ekspor Excel.
7. Sebagai Admin: Log Audit → Clear Log → ketik `HAPUS`.

## 9. Catatan resource (VPS kecil)

Bila RAM hanya 1 GB, tambah swap sebelum build (proses npm/pip bisa memakan
± 1 GB):

```bash
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

## 10. Operasional harian

Semua perintah dijalankan dari `/opt/eir` dengan
`-f docker-compose.yml -f docker-compose.prod.yml` (singkat: `-f`).

```bash
alias eir='docker compose -f /opt/eir/docker-compose.yml -f /opt/eir/docker-compose.prod.yml'

eir ps            # status container
eir logs -f api   # log backend (OCR, login, retensi)
eir restart api   # restart satu layanan
eir up -d --build # terapkan perubahan kode / rebuild
```

**Container otomatis nyala lagi saat VPS reboot** (`restart: unless-stopped` +
Docker service yang aktif by default).

**Backup terjadwal** (audit log adalah satu‑satunya data yang bertahan > 24 jam,
jadi backup database adalah yang terpenting):

```bash
sudo tee /etc/cron.daily/eir-backup >/dev/null <<'EOF'
#!/bin/sh
set -e
d=$(date +%F)
mkdir -p "/opt/backups/$d"
docker compose -f /opt/eir/docker-compose.yml exec -T db \
  pg_dump -U eir eir > "/opt/backups/$d/eir.sql"
docker run --rm -v eir-seal_photos:/data -v "/opt/backups/$d":/out \
  alpine tar czf /out/photos.tgz -C /data . 2>/dev/null || true
find /opt/backups -maxdepth 1 -type d -mtime +14 -exec rm -rf {} + 2>/dev/null || true
EOF
sudo chmod +x /etc/cron.daily/eir-backup
```

Pulihkan database:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml exec -T \
  db psql -U eir -d eir < backup/eir-2026-10-16.sql
```

**Monitoring**: pantau `GET /api/meta/health` (cek DB + engine OCR) dengan
Uptime Kuma / netdata / dst.

## 11. Pembaruan versi

```bash
# 1. Unggah versi baru (§3), pastikan .env lama tidak tertimpa
cd /opt/eir
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build
```

Volume `eir-seal_pgdata` dan `eir-seal_photos` tetap utuh — data tidak hilang
saat rebuild. `docker compose down` **tanpa** `-v` juga tidak menghapus data.

## 12. Pemecahan masalah

| Gejala | Penyebab | Solusi |
| --- | --- | --- |
| Halaman kosong / `502 Bad Gateway` | Container `api` mati | `docker compose ... logs api` |
| `Isi POSTGRES_PASSWORD di file .env` | `.env` belum ada / kosong | §4 |
| Login 500 pertama kali | Seeder Admin gagal (email/DB) | `docker compose ... logs api`, cek `DEFAULT_ADMIN_*` |
| Kamera tidak bisa dibuka | Diakses lewat `http://` | wajib HTTPS (§5); cek redirect 80→443 |
| `curl: (60) SSL certificate problem` | sertifikat self‑signed | normal untuk self‑signed; pakai `curl -k` |
| Nginx restart terus | `fullchain.pem` / `privkey.pem` tidak ada di `nginx/certs/` | §5 |
| OCR selalu gagal di VPS | RAM kurang / proses dibunuh OOM | tambah swap (§9), cek `dmesg | grep -i oom` |
| Perubahan password DB tidak terbawa | `POSTGRES_PASSWORD` diubah setelah volume terisi | `ALTER USER eir WITH PASSWORD '...'` |
