<#
.SYNOPSIS
  Uji cepat stack Aplikasi Verifikasi Nomor Seal EIR.

.DESCRIPTION
  Memeriksa kesehatan layanan, login, hak akses, alur pencocokan
  (sematch / near-match / beda), penyimpanan, riwayat, export Excel,
  master user, dan log audit. Tidak menghapus data apa pun selain
  pemeriksaan yang dibuat oleh skrip ini sendiri.

.EXAMPLE
  pwsh scripts/smoke-test.ps1
  powershell -File scripts/smoke-test.ps1
#>

[CmdletBinding()]
param(
  [string]$BaseUrl = "http://localhost",
  [string]$Username = "admin",
  # Password awal bawaan, dan password pengganti bila akun masih wajib ganti.
  # Sesuai SEAL-04 akun bawaan BELUM dapat dipakai mengakses API apa pun
  # sebelum mengganti password, jadi skrip ini menempuh alur yang sama.
  [string]$Password = "Admin@123",
  [string]$NewPassword = "Admin@123!"
)

$ErrorActionPreference = "Stop"
$script:Pass = 0
$script:Fail = 0

function Write-Check([string]$Name, [bool]$Ok, [string]$Info = "") {
  if ($Ok) { $script:Pass++; Write-Host "  [OK]   $Name" -ForegroundColor Green }
  else     { $script:Fail++; Write-Host "  [FAIL] $Name $Info" -ForegroundColor Red }
}

function Invoke-Json([string]$Method, [string]$Path, $Body = $null, [string]$Token = $null) {
  $headers = @{}
  if ($Token) { $headers["Authorization"] = "Bearer $Token" }
  $params = @{ Uri = "$BaseUrl$Path"; Method = $Method; Headers = $headers; ContentType = "application/json" }
  if ($null -ne $Body) { $params["Body"] = ($Body | ConvertTo-Json -Depth 6) }
  try {
    $r = Invoke-WebRequest @params -UseBasicParsing
    $content = $r.Content
    $json = if ($content) { $content | ConvertFrom-Json } else { $null }
    return [pscustomobject]@{ Status = [int]$r.StatusCode; Data = $json; Raw = $r }
  } catch {
    $status = 0
    $data = $null
    if ($_.Exception.Response) {
      $status = [int]$_.Exception.Response.StatusCode
      try {
        $stream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream)
        $data = $reader.ReadToEnd() | ConvertFrom-Json
      } catch { }
    }
    return [pscustomobject]@{ Status = $status; Data = $data; Raw = $null; Error = $_.Exception.Message }
  }
}

Write-Host "`n=== 1. Kesehatan layanan ===" -ForegroundColor Cyan

try {
  $health = Invoke-RestMethod "$BaseUrl/api/meta/health" -TimeoutSec 15
  Write-Check "API terjangkau" ($health.status -eq "ok") "(status=$($health.status))"
  Write-Check "Database terhubung" ($health.database -eq "up")
  Write-Check "Engine OCR tersedia" ($health.ocr_available -eq $true) "(engine=$($health.ocr_engine))"
  Write-Check "Retensi 24 jam terbaca" ($health.retention_hours -eq 24) "(=$($health.retention_hours))"
} catch {
  Write-Check "API terjangkau" $false $_.Exception.Message
  Write-Host "`nBerhenti: backend belum dapat dihubungi di $BaseUrl" -ForegroundColor Red
  exit 1
}

try {
  $root = Invoke-WebRequest "$BaseUrl/" -UseBasicParsing -TimeoutSec 15
  Write-Check "Frontend tersaji" ($root.StatusCode -eq 200 -and $root.Content -match "<div id=`"root`">")
  $manifest = Invoke-WebRequest "$BaseUrl/manifest.webmanifest" -UseBasicParsing -TimeoutSec 15
  Write-Check "Manifest PWA tersaji" ($manifest.StatusCode -eq 200)
} catch {
  Write-Check "Frontend tersaji" $false $_.Exception.Message
}

Write-Host "`n=== 2. Autentikasi ===" -ForegroundColor Cyan

# Alur login menempuh jalur yang sama dengan operator sungguhan (SEAL-04):
# akun bawaan BELUM dapat memakai API apa pun sebelum mengganti password.
# Skrip mencoba password lama lebih dulu, lalu password pengganti, sehingga
# dapat dijalankan berulang kali setelah password memang sudah diubah.
$login = Invoke-Json POST "/api/auth/login" @{ username = $Username; password = $Password }
if (-not $login.Data.access_token) {
  $login = Invoke-Json POST "/api/auth/login" @{ username = $Username; password = $NewPassword }
}
Write-Check "Login $Username" ($login.Status -eq 200 -and $login.Data.access_token) "(HTTP $($login.Status))"
if (-not $login.Data.access_token) {
  Write-Host "`nBerhenti: tidak dapat login. Cek DEFAULT_ADMIN_* di .env" -ForegroundColor Red
  exit 1
}
$token = $login.Data.access_token

$bad = Invoke-Json POST "/api/auth/login" @{ username = $Username; password = "salah-sekali" }
Write-Check "Password salah ditolak" ($bad.Status -eq 401)

$me = Invoke-Json GET "/api/auth/me" $null $token
Write-Check "Profil + hak akses ikut dikirim" (($me.Data.permissions | Measure-Object).Count -gt 0) "(jumlah=$(@($me.Data.permissions).Count))"
Write-Check "Cakupan riwayat Admin = all" ($me.Data.history_scope -eq "all") "(=$($me.Data.history_scope))"
Write-Check "Wajib ganti password awal terdeteksi" ($me.Data.must_change_password -eq $true -or $me.Data.must_change_password -eq $false)

if ($me.Data.must_change_password) {
  $locked = Invoke-Json GET "/api/checks" $null $token
  Write-Check "API terkunci sampai password diganti" ($locked.Status -eq 403) "(HTTP $($locked.Status))"

  $changed = Invoke-Json POST "/api/auth/change-password-first" @{ new_password = $NewPassword } $token
  Write-Check "Ganti password pertama diterima" ($changed.Status -eq 200) "(HTTP $($changed.Status))"
  Write-Host "  catatan: password $Username kini '$NewPassword'" -ForegroundColor DarkGray
} else {
  Write-Host "  catatan: password sudah pernah diubah; melewati alur ganti password awal." -ForegroundColor DarkGray
}

$noAuth = Invoke-Json GET "/api/checks"
Write-Check "Endpoint tanpa token ditolak" ($noAuth.Status -eq 401)

Write-Host "`n=== 3. Alur pencocokan ===" -ForegroundColor Cyan

function Test-Match([string]$Label, [string]$A, [string]$B, [string]$Expected, [bool]$ExpectNear) {
  $prev = Invoke-Json POST "/api/checks/preview" @{ seal_eir_final = $A; seal_actual_final = $B } $script:token
  $ok = ($prev.Status -eq 200) -and ($prev.Data.result -eq $Expected) -and ([bool]$prev.Data.near_match -eq $ExpectNear)
  Write-Check $Label $ok "(hasil=$($prev.Data.result), near=$($prev.Data.near_match), harapkan $Expected/$ExpectNear)"
}

$script:token = $token
Test-Match "Nomor sama -> SUCCESS"      "EMCHUR9175" "emchur9175" "SUCCESS" $false
Test-Match "Beda jelas -> FAILED"       "EMCHUR9175" "EMCHUR2211" "FAILED"  $false
Test-Match "Beda 1 karakter mirip -> FAILED + near" "EMCHUR9175" "EMCHURO175" "FAILED" $true
Test-Match "Spasi/tanda diabaikan"      "EM-CHUR 9175" "EMCHUR9175" "SUCCESS" $false
Test-Match "Karakter mirip TIDAK meloloskan (9 vs S)" "EMCHUR9175" "EMCHURS175" "FAILED" $true

Write-Host "`n=== 4. Penyimpanan pemeriksaan ===" -ForegroundColor Cyan

$created = Invoke-Json POST "/api/checks" @{
  seal_eir_final          = "EMCHUR9175"
  seal_actual_final       = "EMCHUR9175"
  seal_eir_ocr_raw        = "EMCHURS175"
  seal_actual_ocr_raw     = "EMCHUR9175"
  eir_no                  = "EIR-SMOKE-1"
  container_no            = "MSCU1234567"
  booking_no              = "BKG-TEST-01"
  notes                   = "dibuat oleh skrip smoke-test"
} $token
Write-Check "Pemeriksaan tersimpan" ($created.Status -eq 201) "(HTTP $($created.Status))"
$checkId = $created.Data.id

if ($checkId) {
  Write-Check "Result = SUCCESS" ($created.Data.result -eq "SUCCESS")
  Write-Check "edited_flag terdeteksi (OCR mentah 9->S)" ($created.Data.edited_flag -eq $true)
  Write-Check "user & waktu tercatat" ([bool]$created.Data.user_name -and [bool]$created.Data.checked_at)

  $edited = Invoke-Json PUT "/api/checks/$checkId" @{ notes = "x" } $token
  Write-Check "Hasil TIDAK dapat diubah (tidak ada endpoint edit)" ($edited.Status -eq 404 -or $edited.Status -eq 405)

  $detail = Invoke-Json GET "/api/checks/$checkId" $null $token
  Write-Check "Detail dapat dibuka" ($detail.Status -eq 200)
  Write-Check "Nilai OCR mentah tersimpan untuk audit" ($detail.Data.seal_eir_ocr_raw -eq "EMCHURS175")
}

Write-Host "`n=== 5. Riwayat, filter, dashboard, export ===" -ForegroundColor Cyan

$hist = Invoke-Json GET "/api/checks?page=1&page_size=5" $null $token
Write-Check "Riwayat dapat dibaca" ($hist.Status -eq 200) "(total=$($hist.Data.total))"
Write-Check "Pemeriksaan buatan muncul di riwayat" (@($hist.Data.items | Where-Object { $_.id -eq $checkId }).Count -eq 1)

$failedFilter = Invoke-Json GET "/api/checks?result=FAILED" $null $token
Write-Check "Filter hasil FAILED bekerja" ($failedFilter.Status -eq 200)

$search = Invoke-Json GET "/api/checks?container_no=MSCU1234567" $null $token
Write-Check "Filter nomor container bekerja" ($search.Status -eq 200 -and $search.Data.total -ge 1)

$dash = Invoke-Json GET "/api/checks/dashboard" $null $token
Write-Check "Dashboard harian" ($dash.Status -eq 200 -and $dash.Data.total -ge 1) "(total=$($dash.Data.total))"

try {
  $exp = Invoke-WebRequest "$BaseUrl/api/checks/export" -Headers @{ Authorization = "Bearer $token" } -UseBasicParsing -TimeoutSec 30
  $expType = ($exp.Headers["Content-Type"] | Select-Object -First 1) -join ""
  $isXlsx = ($expType -match "spreadsheetml") -and ($exp.Content.Length -gt 1000)
  Write-Check "Export Excel (.xlsx) valid" $isXlsx "(ukuran=$($exp.Content.Length) byte, tipe=$expType)"
} catch {
  Write-Check "Export Excel (.xlsx) valid" $false $_.Exception.Message
}

Write-Host "`n=== 6. Master User & Role ===" -ForegroundColor Cyan

$roles = Invoke-Json GET "/api/roles" $null $token
Write-Check "3 role bawaan tersedia" (@($roles.Data).Count -ge 3) "(jumlah=$(@($roles.Data).Count))"
$adminRole = $roles.Data | Where-Object { $_.name -eq "Admin" }
Write-Check "Role Admin punya audit.clear" ($adminRole.permissions -contains "audit.clear")
$opRole = $roles.Data | Where-Object { $_.name -eq "Operator" }
Write-Check "Role Operator TIDAK punya export" (-not ($opRole.permissions -contains "reports.export"))
Write-Check "Cakupan Operator = own" ($opRole.history_scope -eq "own")

$users = Invoke-Json GET "/api/users?page_size=50" $null $token
Write-Check "Daftar user terbaca" ($users.Status -eq 200 -and $users.Data.total -ge 1) "(total=$($users.Data.total))"

$locations = Invoke-Json GET "/api/meta/locations" $null $token
Write-Check "Daftar lokasi untuk filter" ($locations.Status -eq 200)

Write-Host "`n=== 7. Audit log ===" -ForegroundColor Cyan

$audit = Invoke-Json GET "/api/audit" $null $token
Write-Check "Log audit terisi" ($audit.Status -eq 200 -and $audit.Data.total -ge 1) "(total=$($audit.Data.total))"
$hasUserCreate = @($audit.Data.items | Where-Object { $_.action -eq "user.create" -or $_.action -eq "check.create" }).Count -gt 0
Write-Check "Ada jejak aksi tercatat" $hasUserCreate

$badClear = Invoke-Json DELETE "/api/audit" @{ confirmation = "salah" } $token
Write-Check "Clear Log menolak konfirmasi salah" ($badClear.Status -eq 400)

Write-Host "`n=== 8. Proteksi foto & retensi ===" -ForegroundColor Cyan

try {
  $noTokenPhoto = Invoke-WebRequest "$BaseUrl/api/photos/does-not-exist.jpg" -UseBasicParsing -TimeoutSec 15
  Write-Check "Foto tanpa token ditolak" ($noTokenPhoto.StatusCode -eq 200) "(dapat $([int]$noTokenPhoto.StatusCode) padahal harus 401)"
} catch {
  $photoStatus = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
  Write-Check "Foto tanpa token ditolak" ($photoStatus -eq 401 -or $photoStatus -eq 403) "(HTTP $photoStatus)"
}

# Pakai %5C (backslash): %2F dinormalisasi oleh nginx sebelum mencapai API,
# sedangkan backslash diteruskan utuh sehingga menguji guard milik backend.
foreach ($probe in @(
    @{ Label = "Path traversal backslash ditolak"; Url = "/api/photos/..%5C..%5Cetc%5Cpasswd" },
    @{ Label = "Nama file aneh lain ditolak";       Url = "/api/photos/....//....//etc%2Fpasswd" }
  )) {
  try {
    $resp = Invoke-WebRequest "$BaseUrl$($probe.Url)" -UseBasicParsing -TimeoutSec 15 -Headers @{ Authorization = "Bearer $token" }
    Write-Check $probe.Label ($resp.StatusCode -eq 200 -and $resp.Headers["Content-Type"] -notmatch "image") "(dapat $([int]$resp.StatusCode), tidak ada file bocor)"
  } catch {
    $st = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
    Write-Check $probe.Label ($st -eq 400 -or $st -eq 404) "(HTTP $st)"
  }
}

Write-Host "`n=== Ringkasan ===" -ForegroundColor Cyan
Write-Host "  Lulus : $script:Pass" -ForegroundColor Green
Write-Host "  Gagal : $script:Fail" -ForegroundColor $(if ($script:Fail -gt 0) { "Red" } else { "Green" })
if ($checkId) { Write-Host "  Catatan: pemeriksaan #$checkId dibuat skrip; ikut terhapus oleh retensi 24 jam." -ForegroundColor DarkGray }
Write-Host ""

if ($script:Fail -gt 0) { exit 1 } else { exit 0 }
