# Aplikasi Verifikasi Nomor Seal EIR

PWA untuk memverifikasi kesesuaian **nomor seal pada dokumen EIR** dengan
**nomor segel aktual** yang terpasang di container. Petugas memotret segel
memakai kamera HP, sistem membaca nomornya dengan OCR, lalu membandingkannya
dengan nomor di EIR — hasilnya **hijau (Success / Sesuai)** atau
**merah (Failed / Tidak Sesuai)**.

Implementasi mengikuti `PRD Aplikasi Verifikasi Nomor Seal EIR.md` v1.0 (15 Okt 2026).

---

## 1. Tech Stack

| Layer | Teknologi |
| --- | --- |
| Frontend | React 18 + Vite + Tailwind CSS, di‑PWA‑kan (manifest + service worker) |
| Backend | Python FastAPI (Uvicorn) |
| Database | PostgreSQL 16 |
| OCR | Tesseract (`pytesseract`) + preprocessing OpenCV |
| Barcode | `pyzbar` (sempat dipakai untuk segel Evergreen) |
| Web server | Nginx (reverse proxy, statis, HTTPS) |
| Deployment | Docker Compose pada 1 VPS |

## 2. Struktur Proyek

```
eir/
├── PRD Aplikasi Verifikasi Nomor Seal EIR.md
├── docker-compose.yml          # lokal / dev (HTTP :80)
├── docker-compose.prod.yml     # override produksi (HTTPS :443)
├── .env.example                # salin menjadi .env
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   └── app/
│       ├── main.py             # aplikasi FastAPI + lifespan
│       ├── config.py           # seluruh konfigurasi lewat env
│       ├── models.py           # roles, users, seal_checks, audit_logs
│       ├── schemas.py          # skema API
│       ├── auth.py             # bcrypt + JWT
│       ├── deps.py             # penjaga role/hak akses + cakupan riwayat
│       ├── seed.py             # role bawaan + akun Admin
│       ├── scheduler.py        # job retensi 24 jam
│       ├── timeutils.py        # zona waktu bisnis untuk laporan
│       ├── ocr/
│       │   ├── engine.py       # OCREngine abstrak + TesseractEngine
│       │   ├── preprocessing.py# grayscale, CLAHE, threshold, penskalaan
│       │   ├── barcode.py      # pembaca barcode (SELALU aman dipanggil)
│       │   └── matching.py     # normalisasi, pencocokan, "hampir sama"
│       ├── routers/            # auth, users, roles, checks, audit, photos, meta
│       └── services/           # storage (foto), excel, audit, cleanup
├── frontend/
│   ├── Dockerfile              # multi-stage: node build → nginx
│   ├── scripts/gen-icons.mjs   # generate ikon PNG tanpa dependensi
│   └── src/
│       ├── pages/              # Login, Home, CheckNew, History, Dashboard, ...
│       ├── components/         # Layout, CameraView, Modal, PhotoView, ...
│       ├── context/            # AuthContext (sesi + hak akses)
│       └── utils/              # camera (crop+kompresi), matching
└── nginx/
    ├── nginx.conf              # dev (HTTP)
    └── nginx.prod.conf         # produksi (HTTPS, redirect 80→443)
```

## 3. Menjalankan

### 3.1 Prasyarat

- Docker Desktop dengan **WSL2 backend** (Docker Engine harus menyala)
- Node.js 20+ (hanya bila ingin menjalankan frontend tanpa Docker)

### 3.2 Konfigurasi

```powershell
Copy-Item .env.example .env
notepad .env
```

**Wajib diubah:** `POSTGRES_PASSWORD` dan `SECRET_KEY`.

### 3.3 Mode lokal / dev (tanpa TLS)

```powershell
docker compose up -d --build
```

- Aplikasi: <http://localhost>
- API docs: <http://localhost/api/docs>
- Cek sehat: <http://localhost/api/meta/health>

> Kamera HP **tidak** dapat dibuka lewat `http://` dari perangkat lain.
> Untuk uji kamera dari HP, pakai mode produksi (3.4) atau jalankan Vite dev
> server lewat HTTPS.

### 3.4 Mode produksi (HTTPS — wajib)

```powershell
# 1. Buat sertifikat (uji lokal) — ganti dengan Let's Encrypt untuk publik
New-Item -ItemType Directory -Force nginx/certs
openssl req -x509 -nodes -days 365 -newkey rsa:2048 `
  -subj "/CN=eir.local" `
  -keyout nginx/certs/privkey.pem -out nginx/certs/fullchain.pem

# 2. Jalankan dengan override TLS
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build
```

### 3.5 Mode pengembangan frontend

```powershell
cd frontend
npm install
npm run build     # hasil di frontend/dist
# atau server dev dengan proxy ke backend:
$env:VITE_API_PROXY = "http://localhost:80"; npm run dev
```

> Setelah mengubah frontend untuk mode Docker, jalankan ulang
> `docker compose build web` karena build React berada di dalam image Nginx.

### 3.6 Akun awal

| Field | Nilai |
| --- | --- |
| Username | `admin` (dari `DEFAULT_ADMIN_USERNAME`) |
| Password | `Admin@123` (dari `DEFAULT_ADMIN_PASSWORD`) |

User **wajib** mengganti password saat login pertama (SEAL‑04). Ini juga
dijaga di tingkat API: selama password belum diganti, hanya `/api/auth/me`
dan kedua rute ganti password yang dapat dipanggil — endpoint lain menolak
dengan `403`.

> Catatan lingkungan pengembang: rangkaian uji di §9 mengganti password
> `admin` menjadi `Admin@123!` saat pertama dijalankan. Untuk instalasi
> produksi yang segar, password awal tetap `Admin@123` sampai diganti
> pengguna.

Role bawaan yang dibuat otomatis: **Admin**, **Supervisor**, **Operator**
sesuai Lampiran A.

## 4. Alur Pemeriksaan

```
Beranda → Pemeriksaan Baru
  ├─ Langkah 1 — Foto dokumen EIR  (crop sesuai kotak panduan → OCR)
  │    └─ Konfirmasi: foto hasil crop, field bisa diedit, [Foto Ulang] [Lanjut]
  ├─ Langkah 2 — Foto segel        (crop + flash bila didukung → OCR/barcode)
  │    └─ Konfirmasi + data pendukung opsional → [Cocokkan]
  ├─ Pratinjau pencocokan (server)
  │    ├─ hampir sama → layar KUNING, opsi [Periksa Kembali] / [Tetap Lanjut]
  │    └─ selain itu  → simpan log → layar HASIL
  └─ Hasil: hijau "Success / Sesuai" atau merah "Failed / Tidak Sesuai"
            (ikon + teks, kedua nomor berdampingan) → [Pemeriksaan Baru] [Lihat Detail]
```

## 5. Peta Pemenuhan PRD

### Kebutuhan fungsional

| ID | Implementasi |
| --- | --- |
| SEAL‑01..08 | `routers/auth.py`, `routers/users.py`, `routers/roles.py`, `deps.py` |
| SEAL‑11 | `components/CameraView.jsx` — kamera belakang, kotak panduan wajib, crop di klien, tombol flash |
| SEAL‑12/13 | `routers/checks.py → /checks/scan?kind=eir|seal` |
| SEAL‑14 | Layar konfirmasi OCR dengan field teredit + tombol **Foto Ulang** |
| SEAL‑15 | `ocr/matching.py` (server) + `/checks/preview` |
| SEAL‑16 | Layar hasil penuh hijau/merah, ikon + teks, nomor berdampingan |
| SEAL‑17 | Field opsional EIR, container, booking/BL, catatan |
| SEAL‑18 | Penyimpanan foto, OCR mentah, nomor final, hasil, user, waktu, lokasi |
| SEAL‑19 | `edited_flag` — final ≠ hasil OCR mentah |
| SEAL‑20 | Peringatan kuning "hampir sama" **sebelum** hasil final |
| SEAL‑22/23 | `pages/History.jsx`, `pages/HistoryDetail.jsx` |
| SEAL‑24 | `/checks/export` → `.xlsx` (openpyxl) mengikuti filter aktif |
| SEAL‑25 | `/checks/dashboard` + `pages/Dashboard.jsx` |
| SEAL‑26 | Catatan tindak lanjut pada detail kasus Failed |
| SEAL‑27 | `audit_logs` tidak pernah dihapus otomatis |
| SEAL‑28 | `services/cleanup.py` + APScheduler: hapus foto & log setelah 24 jam |
| SEAL‑29 | `ocr/engine.py` mencoba rotasi 0°/90°/180°/270° |
| SEAL‑30 | Barcode dibaca lebih dulu, OCR sebagai cadangan (khusus `kind=seal`) |
| SEAL‑31 | `/audit` (DELETE) — hanya Admin, konfirmasi ketik `HAPUS` |

### Aturan bisnis (Bagian 6)

1. Normalisasi huruf besar, hapus non‑alfanumerik → `ocr/matching.normalize`
2. "Sesuai" hanya bila kedua string identik → `ocr/matching.compare`
3. Koreksi karakter mirip **tidak** meloloskan hasil → hanya menghasilkan
   `near_match=true` (peringatan), keputusan tetap pada operator
4. Nilai OCR mentah vs final disimpan untuk audit
5. Hasil tersimpan tidak dapat diubah; koreksi = pemeriksaan baru
   (tombol "Pemeriksaan baru (referensi)" diisi `ref_check_id`)
6. Validasi 6–10 karakter alfanumerik hanya memberi **peringatan**

### Non‑fungsional (Bagian 10)

- **HTTPS** wajib untuk kamera → `nginx/nginx.prod.conf` + redirect 80→443
- Password di‑bcrypt, token JWT berumur terbatas (`ACCESS_TOKEN_EXPIRE_MINUTES`)
- Foto dikompres di klien (JPEG 0.85, maks 1600 px) sebelum diunggah
- PostgreSQL tidak punya `ports:` — hanya di jaringan internal Docker
- Batas unggahan `MAX_UPLOAD_MB` (default 12 MB), Nginx `client_max_body_size`
- Foto hanya dapat diakses lewat `/api/photos/{file}` ber‑otentikasi
- Retensi 24 jam untuk foto & log; audit log dikecualikan
- Backup: `pg_dump` terjadwal + salinan folder foto (lihat §7)

## 6. Endpoint API Utama

| Method | Path | Keterangan |
| --- | --- | --- |
| POST | `/api/auth/login` | Login, kunci akun setelah N kali gagal |
| GET | `/api/auth/me` | Profil + hak akses |
| POST | `/api/auth/change-password-first` | Wajib ganti password awal |
| GET/POST/PUT/DELETE | `/api/users` | Master User (soft delete) |
| POST | `/api/users/{id}/reset-password` | Reset → password sementara |
| GET/POST/PUT/DELETE | `/api/roles` | Master Role + `/api/roles/permissions` |
| POST | `/api/checks/scan?kind=eir\|seal` | Unggah foto → simpan + OCR |
| POST | `/api/checks/preview` | Pratinjau pencocokan (tanpa simpan) |
| POST | `/api/checks` | Simpan hasil pemeriksaan |
| GET | `/api/checks` | Riwayat + filter + paginasi |
| GET | `/api/checks/dashboard` | Rekap harian |
| GET | `/api/checks/export` | Unduh `.xlsx` |
| GET | `/api/checks/{id}` | Detail |
| POST | `/api/checks/{id}/follow-up` | Catatan tindak lanjut Failed |
| GET/DELETE | `/api/audit` | Log audit + Clear Log (Admin) |
| GET | `/api/photos/{file}` | Foto (otentikasi) |
| GET | `/api/meta/health` | Kesehatan DB & engine OCR |

## 7. Operasional di VPS

> Panduan lengkap pemasangan di VPS Ubuntu (install Docker, sertifikat
> Let's Encrypt, firewall, backup otomatis, pemecahan masalah) ada di
> [`DEPLOY.md`](DEPLOY.md).

**Backup terjadwal** (Bagian 10 — Ketersediaan dan backup):

```bash
# Backup database
docker compose exec db pg_dump -U eir eir > backup/eir-$(date +%F).sql

# Salin folder foto (akan berisi < 24 jam data aktif)
docker cp eir-seal-api-1:/data/photos backup/photos-$(date +%F)
```

**Monitoring**: `GET /api/meta/health` cocok dipantau Uptime Kuma/netdata.

**Pembersihan retensi** berjalan otomatis tiap hari pada `CLEANUP_HOUR`:
`CLEANUP_MINUTE` UTC (`RETENTION_HOURS`, default 24). Dapat dimatikan dengan
`CLEANUP_ENABLED=false`.

## 8. Catatan Teknis Penting

- **Modul OCR** dibungkus kelas `OCREngine`. Mengganti Tesseract ke PaddleOCR
  cukup dengan mengimplementasikan kelas baru dan mengubah `get_engine()`
  di `backend/app/ocr/engine.py` — tidak ada modul lain yang berubah.
- **Crop wajib di klien**: seluruh pengujian menunjukkan foto penuh tidak
  terbaca. `CameraView` menghitung ulang persegi panduan ke piksel asli video
  (`object-fit: cover`) sehingga crop presisi.
- **Skor kandidat OCR** mengutamakan token 6–10 karakter yang memuat huruf
  **dan** angka, agar nomor tanggal murni angka pada dokumen EIR tidak menang.
- **Mode dokumen vs segel**: EIR memakai `--psm 11` (teks tersebar), segel
  memakai `--psm 7` (satu baris).
- **Hasil uji awal di PRD** (`EMCHURS175` vs `EMCHUR9175`) adalah alasan
  adanya koreksi manual, penanda `edited_flag`, dan Fase 4 (uji lapangan).

## 9. Uji Otomatis

Tiga rangkaian uji tersedia. Semua berjalan di dalam kontainer sehingga tidak
memerlukan Python di mesin pengembang.

```powershell
# 1. OCR pada gambar nyata — 13 skenario (rotasi, buram, gelap, berisik,
#    Code 39, dan kontra-bukti: tanpa crop & huruf kecil memang harus gagal)
Get-Content backend\tests\ocr_probe.py -Raw | docker compose exec -T api python -

# 2. Integrasi HTTP end-to-end — alur lengkap seperti browser:
#    login → unggah foto segel & dokumen EIR → pratinjau → simpan →
#    ambil foto → proteksi input → export Excel
Get-Content backend\tests\integration_scan.py -Raw | docker compose exec -T api python -

# 3. Smoke test API — 42 pemeriksaan hak akses, riwayat, audit, retensi
powershell -File scripts\smoke-test.ps1
```

Skrip uji dikirim lewat stdin (`Get-Content ... |`) sehingga berkas tes tidak
 ikut dibakar ke image produksi.

### Temuan yang diperbaiki saat pengujian

| Temuan | Dampak | Perbaikan |
| --- | --- | --- |
| `kind` dikirim sebagai field form, bukan parameter query | **Foto dokumen EIR diproses dengan mode satu baris**, sehingga nomor seal di antara teks dokumen tidak terbaca | `CheckNew.jsx` mengirim `?kind=...`; endpoint juga menerima field form sebagai pengaman |
| Kebenaran array numpy dipakai sebagai syarat | `ValueError` saat fase 2 OCR | Ganti `pool.get(x) or ...` dengan pengecekan `is None` |
| Fase 1 berhenti pada token berskor tinggi tanpa syarat konfiden | Foto **terbalik (180°/270°) selalu gagal** — hasil sampah berskor sama dengan hasil benar | Tambah ambang `MIN_CONFIDENCE` sebelum berhenti mencari |
| Kandidat berskor 0 masih dilaporkan sebagai hasil | Teks sampah seperti `TERMINAL3GATEB2` ditampilkan sebagai nomor | Kandidat berskor 0 dibuang; user diminta foto ulang/ketik manual |
| Email `admin@local` ditolak validasi Pydantic | Admin bawaan gagal dibuat → login 500 | Ganti `EmailStr` dengan pola yang menerima domain internal |
| `must_change_password` hanya dijaga antarmuka | **Token tetap sah setelah login pertama** — endpoint mana pun masih bisa dipanggil langsung lewat klien HTTP | Dijaga di `get_current_user`: hanya `/auth/me` dan dua rute ganti password yang diizinkan |
| `--workers 2` | Lifespan (seeder + job retensi) berjalan dua kali | Turunkan ke 1 worker — OCR tetap paralel via threadpool |

**Keterbatasan yang disengaja** (sesuai PRD, bukan bug): Tesseract masih salah
baca `0`↔`O` dan `5`↔`S` pada gambar buram — terukur ~10% pada teks dokumen
30px. PRD menanganinya lewat wajib-konfirmasi hasil OCR oleh operator, dan
peringatan "hampir sama" yang **tidak pernah** mengubah hasil menjadi Sesuai.

## 10. Checklist Uji Cepat

1. `docker compose up -d --build` → buka `http://localhost`
2. Login `admin` / `Admin@123` → dipaksa ganti password
3. Buat user **Operator** + **Supervisor**, login sebagai Operator
4. Pemeriksaan Baru → izinkan kamera → foto dua nomor yang **sama**
   → layar hijau *Success / Sesuai*
5. Ulangi dengan nomor berbeda → layar merah *Failed / Tidak Sesuai*
6. Uji beda 1 karakter mirip (mis. `O`↔`0`) → layar kuning "hampir sama"
7. Buka Riwayat → filter → **Ekspor Excel**
8. Sebagai Admin: Master User → Reset password; Master Role → ubah hak akses
9. Tunggu lewat `RETENTION_HOURS` (atau set `RETENTION_HOURS=0` sementara)
   → baris & foto terhapus, log audit tetap ada
10. Sebagai Admin: Log Audit → Clear Log → ketik `HAPUS`
