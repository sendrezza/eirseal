import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { api, tokenStore, userStore } from "../api/client";

const AuthContext = createContext(null);

/** Daftar hak akses role yang sedang login. */
function permissionsOf(user) {
  return user?.permissions || [];
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => userStore.get());
  const [booting, setBooting] = useState(() => Boolean(tokenStore.get()));

  // Pulihkan sesi saat aplikasi dibuka
  useEffect(() => {
    let alive = true;
    if (!tokenStore.get()) {
      setBooting(false);
      return () => {};
    }
    api("/auth/me")
      .then((profile) => {
        if (!alive) return;
        userStore.set(profile);
        setUser(profile);
      })
      .catch(() => {
        if (alive) {
          tokenStore.clear();
          setUser(null);
        }
      })
      .finally(() => alive && setBooting(false));
    return () => {
      alive = false;
    };
  }, []);

  const login = useCallback(async (username, password) => {
    const data = await api("/auth/login", {
      method: "POST",
      body: { username, password },
    });
    tokenStore.set(data.access_token);

    // Ambil profil lengkap beserta hak akses role dari /auth/me
    const profile = await api("/auth/me").catch(() => data.user);
    const enriched = {
      ...profile,
      permissions: profile?.permissions || [],
      history_scope: profile?.history_scope || "own",
    };
    userStore.set(enriched);
    setUser(enriched);
    return enriched;
  }, []);

  const logout = useCallback(() => {
    tokenStore.clear();
    setUser(null);
  }, []);

  const refreshUser = useCallback(async () => {
    const profile = await api("/auth/me");
    const enriched = {
      ...profile,
      permissions: profile?.permissions || [],
      history_scope: profile?.history_scope || "own",
    };
    userStore.set(enriched);
    setUser(enriched);
    return enriched;
  }, []);

  const value = useMemo(() => {
    const permissions = permissionsOf(user);
    return {
      user,
      booting,
      login,
      logout,
      refreshUser,
      permissions,
      has: (perm) => permissions.includes(perm),
      scope: user?.history_scope || "own",
      mustChangePassword: Boolean(user?.must_change_password),
    };
  }, [user, booting, login, logout, refreshUser]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth harus dipakai di dalam AuthProvider");
  return ctx;
}
