/**
 * Utilitas kamera belakang HP (SEAL-11).
 *
 * Prinsip PRD: foto wajib di-crop sesuai kotak panduan sebelum OCR, karena
 * foto penuh tidak terbaca. Crop dilakukan di sisi klien terhadap piksel asli
 * video (bukan terhadap gambar yang dilihat), sehingga hasilnya presisi.
 */

export class CameraError extends Error {
  constructor(message, code = "camera") {
    super(message);
    this.name = "CameraError";
    this.code = code;
  }
}

/** Kamera butuh HTTPS (atau localhost) — risiko Bagian 12 PRD. */
export function cameraAllowedByContext() {
  if (typeof window === "undefined") return false;
  const { protocol, hostname } = window.location;
  return (
    protocol === "https:" ||
    hostname === "localhost" ||
    hostname === "127.0.0.1" ||
    hostname === "[::1]"
  );
}

export async function startCamera() {
  if (!cameraAllowedByContext()) {
    throw new CameraError(
      "Kamera hanya dapat dibuka lewat HTTPS. Buka aplikasi dengan alamat https://.",
      "insecure",
    );
  }
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new CameraError(
      "Perangkat/browser ini tidak mendukung akses kamera.",
      "unsupported",
    );
  }

  try {
    return await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        facingMode: { ideal: "environment" },
        width: { ideal: 1922 },
        height: { ideal: 1080 },
      },
    });
  } catch (err) {
    if (err instanceof CameraError) throw err;
    if (err?.name === "NotAllowedError") {
      throw new CameraError(
        "Izin kamera ditolak. Izinkan akses kamera di pengaturan browser, lalu coba lagi.",
        "denied",
      );
    }
    if (err?.name === "NotFoundError" || err?.name === "OverconstrainedError") {
      throw new CameraError(
        "Kamera tidak ditemukan pada perangkat ini. Gunakan input manual.",
        "notfound",
      );
    }
    if (err?.name === "NotReadableError") {
      throw new CameraError(
        "Kamera sedang dipakai aplikasi lain. Tutup aplikasi tersebut lalu coba lagi.",
        "busy",
      );
    }
    throw new CameraError("Kamera tidak dapat dibuka.", "unknown");
  }
}

export function stopStream(stream) {
  if (!stream) return;
  stream.getTracks().forEach((track) => {
    try {
      track.stop();
    } catch {
      /* sudah berhenti */
    }
  });
}

export function torchSupported(track) {
  if (!track || typeof track.getCapabilities !== "function") return false;
  try {
    return Boolean(track.getCapabilities().torch);
  } catch {
    return false;
  }
}

export async function setTorch(track, enabled) {
  if (!track) return false;
  try {
    await track.applyConstraints({ advanced: [{ torch: enabled }] });
    return true;
  } catch {
    return false;
  }
}

/**
 * Petakan persegi panduan (koordinat elemen container) ke piksel sumber video.
 * Video memakai object-fit: cover, jadi perlu dihitung ulang.
 */
function sourceRect(guideRect, video, containerRect) {
  const vw = video.videoWidth;
  const vh = video.videoHeight;
  if (!vw || !vh) return null;

  const scale = Math.max(containerRect.width / vw, containerRect.height / vh);
  const offsetX = (containerRect.width - vw * scale) / 2;
  const offsetY = (containerRect.height - vh * scale) / 2;

  let sx = (guideRect.left - containerRect.left - offsetX) / scale;
  let sy = (guideRect.top - containerRect.top - offsetY) / scale;
  let sw = guideRect.width / scale;
  let sh = guideRect.height / scale;

  // Jaga agar sumber selalu berada di dalam frame video
  sx = Math.max(0, Math.min(sx, vw - 1));
  sy = Math.max(0, Math.min(sy, vh - 1));
  sw = Math.max(1, Math.min(sw, vw - sx));
  sh = Math.max(1, Math.min(sh, vh - sy));

  return { sx, sy, sw, sh };
}

function toBlob(canvas, quality) {
  return new Promise((resolve) => {
    if (canvas.toBlob) canvas.toBlob(resolve, "image/jpeg", quality);
    else resolve(null);
  });
}

/**
 * Ambil foto sesuai kotak panduan, lalu kompresi di sisi klien sebelum
 * diunggah (kebutuhan performa Bagian 10).
 *
 * @param {HTMLVideoElement} video
 * @param {HTMLElement} container elemen induk video (posisi/ukuran layar)
 * @param {HTMLElement} guide    elemen kotak panduan
 * @param {{maxDim?:number, quality?:number}} opts
 * @returns {Promise<Blob>}
 */
export async function captureInGuide(video, container, guide, opts = {}) {
  if (!video || !container || !guide) {
    throw new CameraError("Komponen kamera belum siap.", "notready");
  }
  if (!video.videoWidth) {
    throw new CameraError("Gambar kamera belum siap, coba lagi.", "notready");
  }

  const rect = sourceRect(guide.getBoundingClientRect(), video, container.getBoundingClientRect());
  if (!rect) throw new CameraError("Ukuran video belum tersedia.", "notready");

  const quality = opts.quality ?? 0.85;
  const maxDim = opts.maxDim ?? 1600;

  let w = Math.round(rect.sw);
  let h = Math.round(rect.sh);
  const longest = Math.max(w, h);
  if (longest > maxDim) {
    const ratio = maxDim / longest;
    w = Math.max(1, Math.round(w * ratio));
    h = Math.max(1, Math.round(h * ratio));
  }

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(
    video,
    rect.sx,
    rect.sy,
    rect.sw,
    rect.sh,
    0,
    0,
    w,
    h,
  );

  const blob = await toBlob(canvas, quality);
  if (!blob) throw new CameraError("Gagal mengubah hasil potret menjadi gambar.", "encode");
  return blob;
}
