/**
 * Aturan pencocokan sisi klien — sengaja identik dengan backend
 * (Bagian 6 PRD) hanya untuk menampilkan pratinjau/warning secara instan.
 * Keputusan hasil tetap dihitung oleh server.
 */

const NON_ALNUM = /[^A-Z0-9]/g;

// Dipakai HANYA untuk peringatan "hampir sama" (SEAL-20), tidak pernah untuk
// menyatakan hasil Sesuai (aturan bisnis no.3).
const CONFUSABLES = {
  O: "0QD",
  Q: "0O",
  D: "0O",
  I: "1l7",
  1: "Il7",
  l: "1I",
  7: "1I",
  S: "59",
  5: "S",
  9: "SG",
  G: "96",
  6: "G",
  B: "8",
  8: "B",
  Z: "2",
  2: "Z",
};

export const FORMAT_MIN = 6;
export const FORMAT_MAX = 10;

export function normalize(value) {
  if (!value) return "";
  return String(value).toUpperCase().replace(NON_ALNUM, "");
}

export function validateFormat(value) {
  const warnings = [];
  if (!value) {
    warnings.push("Nomor kosong.");
    return warnings;
  }
  if (!/^[A-Z0-9]+$/.test(value)) {
    warnings.push("Nomor mengandung karakter non-alfanumerik.");
  }
  if (value.length < FORMAT_MIN) {
    warnings.push(`Nomor lebih pendek dari rentang umum ${FORMAT_MIN}–${FORMAT_MAX} karakter.`);
  } else if (value.length > FORMAT_MAX) {
    warnings.push(`Nomor lebih panjang dari rentang umum ${FORMAT_MIN}–${FORMAT_MAX} karakter.`);
  }
  return warnings;
}

function similarity(a, b) {
  if (!a || !b) return 0;
  const m = a.length;
  const n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 1; i <= m; i += 1) {
    for (let j = 1; j <= n; j += 1) {
      dp[i][j] =
        a[i - 1] === b[j - 1]
          ? dp[i - 1][j - 1] + 1
          : Math.max(dp[i - 1][j], dp[i][j - 1]);
    }
  }
  const lcs = dp[m][n];
  return (2 * lcs) / (m + n);
}

export function isNearMatch(a, b) {
  if (!a || !b || a === b) return false;

  if (a.length === b.length) {
    const diff = [];
    for (let i = 0; i < a.length; i += 1) {
      if (a[i] !== b[i]) diff.push([a[i], b[i]]);
    }
    const onlyConfusables =
      diff.length >= 1 &&
      diff.length <= 2 &&
      diff.every(
        ([x, y]) =>
          (CONFUSABLES[x] || "").includes(y) || (CONFUSABLES[y] || "").includes(x),
      );
    if (onlyConfusables) return true;
  }

  if (Math.abs(a.length - b.length) <= 1 && similarity(a, b) >= 0.85) return true;
  if (similarity(a, b) >= 0.9) return true;
  return false;
}

/** Hasil pratinjau — server tetap sumber kebenaran lewat POST /checks/preview. */
export function previewMatch(eirValue, actualValue) {
  const normEir = normalize(eirValue);
  const normActual = normalize(actualValue);
  const matched = Boolean(normEir) && normEir === normActual;
  return {
    normalized_eir: normEir,
    normalized_actual: normActual,
    result: matched ? "SUCCESS" : "FAILED",
    near_match: !matched && isNearMatch(normEir, normActual),
    warnings: !matched && isNearMatch(normEir, normActual)
      ? ["Periksa kembali: nomor hampir sama"]
      : [],
    format_warnings: [...validateFormat(normEir), ...validateFormat(normActual)],
  };
}

/** Tampilan hasil sesuai Lampiran B. */
export const RESULT_STYLES = {
  SUCCESS: {
    label: "Success",
    labelId: "Sesuai",
    short: "Sesuai",
    bg: "bg-success",
    text: "text-white",
    light: "bg-success-light",
    border: "border-success",
    ring: "text-success",
    icon: "check",
  },
  FAILED: {
    label: "Failed",
    labelId: "Tidak Sesuai",
    short: "Tidak Sesuai",
    bg: "bg-danger",
    text: "text-white",
    light: "bg-danger-light",
    border: "border-danger",
    ring: "text-danger",
    icon: "x",
  },
};

export const RESULT_LABELS = {
  SUCCESS: "Sesuai",
  FAILED: "Tidak Sesuai",
};
