import { useEffect } from "react";
import Icon from "./Icon";

/** Dialog/modal dasar — menutup lewat tombol atau Esc, tidak lewat klik latar
 *  agar operator lapangan tidak salah menutup saat berjalan. */
export default function Modal({
  open,
  title,
  onClose,
  children,
  footer,
  wide = false,
  dismissible = true,
}) {
  useEffect(() => {
    if (!open) return () => {};
    const onKey = (e) => {
      if (e.key === "Escape" && dismissible) onClose?.();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, dismissible, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-slate-900/50" aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`relative flex max-h-[92dvh] w-full flex-col rounded-t-3xl bg-white shadow-2xl sm:max-h-[88dvh] sm:rounded-3xl ${
          wide ? "sm:max-w-3xl" : "sm:max-w-lg"
        }`}
      >
        <header className="flex items-center justify-between gap-3 border-b border-slate-200 px-4 py-3.5">
          <h2 className="text-base font-bold text-slate-900">{title}</h2>
          {dismissible ? (
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100"
              aria-label="Tutup"
            >
              <Icon name="close" className="h-5 w-5" />
            </button>
          ) : null}
        </header>

        <div className="flex-1 overflow-y-auto px-4 py-4">{children}</div>

        {footer ? (
          <footer className="border-t border-slate-200 px-4 py-3.5">{footer}</footer>
        ) : null}
      </div>
    </div>
  );
}
