import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import Icon from "./Icon";
import Modal from "./Modal";

function BottomLink({ to, icon, label, end = false }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        `flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-semibold ${
          isActive ? "text-brand" : "text-slate-500"
        }`
      }
    >
      {({ isActive }) => (
        <>
          <Icon name={icon} className="h-6 w-6" strokeWidth={isActive ? 2.4 : 2} />
          <span>{label}</span>
        </>
      )}
    </NavLink>
  );
}

/**
 * Kerangka aplikasi: bar atas + navigasi bawah besar (mudah dijangkau satu
 * tangan) + lembar "Kelola" untuk menu admin (Bagian 7 PRD).
 */
export default function Layout({ children, title, subtitle, back, actions }) {
  const { user, logout, has } = useAuth();
  const [sheet, setSheet] = useState(false);

  const canDashboard = has("dashboard.view");
  const canManage =
    has("users.manage") || has("roles.manage") || has("audit.view");
  const showManageInBar = canManage || !canDashboard;

  const manageItems = [
    { show: has("users.manage"), to: "/kelola/user", icon: "users", label: "Master User" },
    { show: has("roles.manage"), to: "/kelola/role", icon: "shield", label: "Master Role" },
    { show: has("audit.view"), to: "/kelola/audit", icon: "list", label: "Log Audit" },
    { show: true, to: "/profil", icon: "user", label: "Profil & Password" },
  ].filter((i) => i.show);

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-5xl flex-col bg-slate-100">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="flex items-center gap-3 px-3 py-2.5">
          {back ? (
            <button
              type="button"
              onClick={back}
              className="-ml-1 rounded-lg p-2 text-slate-600 hover:bg-slate-100"
              aria-label="Kembali"
            >
              <Icon name="back" className="h-6 w-6" />
            </button>
          ) : (
            <Link to="/" className="flex items-center gap-2" aria-label="Beranda">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand text-white">
                <Icon name="check" className="h-5 w-5" strokeWidth={3} />
              </span>
            </Link>
          )}

          <div className="min-w-0 flex-1">
            <h1 className="truncate text-base font-bold leading-tight text-slate-900">
              {title}
            </h1>
            {subtitle ? (
              <p className="truncate text-xs text-slate-500">{subtitle}</p>
            ) : null}
          </div>

          {actions}
        </div>
      </header>

      <main className="flex-1 px-3 pb-28 pt-4">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-slate-200 bg-white pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto flex w-full max-w-5xl">
          <BottomLink to="/" icon="home" label="Beranda" end />
          {has("checks.view") ? (
            <BottomLink to="/riwayat" icon="history" label="Riwayat" />
          ) : null}
          {canDashboard ? (
            <BottomLink to="/dashboard" icon="chart" label="Dashboard" />
          ) : null}
          {showManageInBar ? (
            <button
              type="button"
              onClick={() => setSheet(true)}
              className="flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-semibold text-slate-500"
            >
              <Icon name="menu" className="h-6 w-6" />
              <span>Kelola</span>
            </button>
          ) : null}
        </div>
      </nav>

      <Modal open={sheet} title="Kelola & Akun" onClose={() => setSheet(false)}>
        <div className="flex flex-col gap-1">
          <div className="mb-2 rounded-xl bg-slate-50 px-3 py-3">
            <p className="text-sm font-bold text-slate-900">{user?.full_name}</p>
            <p className="text-xs text-slate-500">
              {user?.role_name} · {user?.location || "Tanpa lokasi"}
            </p>
          </div>

          {manageItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setSheet(false)}
              className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              <span className="text-brand">
                <Icon name={item.icon} className="h-5 w-5" />
              </span>
              {item.label}
            </Link>
          ))}

          <button
            type="button"
            onClick={() => {
              setSheet(false);
              logout();
            }}
            className="mt-2 flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-danger hover:bg-danger-light"
          >
            <Icon name="logout" className="h-5 w-5" />
            Keluar
          </button>
        </div>
      </Modal>
    </div>
  );
}
