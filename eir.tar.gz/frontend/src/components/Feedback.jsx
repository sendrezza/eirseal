import Icon from "./Icon";

export function Spinner({ label = "Memuat…", className = "h-6 w-6" }) {
  return (
    <span
      className={`inline-block animate-spin rounded-full border-2 border-slate-300 border-t-brand ${className}`}
      role="status"
      aria-label={label}
    />
  );
}

export function LoadingScreen({ label = "Memuat…" }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3 text-slate-500">
      <Spinner label={label} className="h-9 w-9" />
      <p className="text-sm">{label}</p>
    </div>
  );
}

/** Overlay pemrosesan (mis. OCR berjalan) dengan latar yang menutupi layar. */
export function ProcessingOverlay({ title, detail }) {
  return (
    <div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-4 bg-slate-900/70 px-6 text-center backdrop-blur-sm"
      role="alert"
      aria-live="assertive"
    >
      <Spinner className="h-12 w-12 border-white/30 border-t-white" />
      <div>
        <p className="text-lg font-bold text-white">{title}</p>
        {detail ? <p className="mt-1 text-sm text-white/80">{detail}</p> : null}
      </div>
    </div>
  );
}

export function EmptyState({ icon = "list", title, hint, action }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center">
      <span className="text-slate-300">
        <Icon name={icon} className="h-10 w-10" />
      </span>
      <p className="font-semibold text-slate-700">{title}</p>
      {hint ? <p className="max-w-sm text-sm text-slate-500">{hint}</p> : null}
      {action}
    </div>
  );
}

/** Pesan galat ringan yang selalu disertai ikon agar tidak hanya warna. */
export function ErrorNote({ children }) {
  if (!children) return null;
  return (
    <p className="flex items-start gap-2 rounded-xl bg-danger-light px-3 py-2.5 text-sm font-medium text-danger-dark">
      <span className="mt-0.5 shrink-0">
        <Icon name="warning" className="h-4 w-4" />
      </span>
      <span>{children}</span>
    </p>
  );
}
