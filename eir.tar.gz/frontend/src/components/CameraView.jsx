import { useCallback, useEffect, useRef, useState } from "react";
import {
  CameraError,
  captureInGuide,
  setTorch,
  startCamera,
  stopStream,
  torchSupported,
} from "../utils/camera";
import Icon from "./Icon";
import { ErrorNote, Spinner } from "./Feedback";

/**
 * Layar kamera dengan kotak panduan wajib (SEAL-11).
 *
 * Gambar dipotong sesuai kotak sebelum OCR karena foto penuh tidak terbaca.
 * Tersedia pula tombol flash bila perangkat mendukung dan pintasan ke
 * input manual.
 */
export default function CameraView({
  title,
  hint,
  aspect = 4,
  onCapture,
  onCancel,
  onManual,
  captureLabel = "Ambil Foto",
}) {
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const guideRef = useRef(null);
  const streamRef = useRef(null);

  const [error, setError] = useState(null);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [torchAvailable, setTorchAvailable] = useState(false);
  const [torchOn, setTorchOn] = useState(false);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const stream = await startCamera();
        if (cancelled) {
          stopStream(stream);
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (!video) return;
        video.srcObject = stream;
        video.onloadedmetadata = async () => {
          try {
            await video.play();
          } catch {
            /* autoplay ditolak — pengguna harus menekan tombol */
          }
          if (cancelled) return;
          setReady(true);
          const track = stream.getVideoTracks()[0];
          setTorchAvailable(torchSupported(track));
        };
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof CameraError
              ? err.message
              : "Kamera tidak dapat dibuka.",
          );
        }
      }
    })();

    return () => {
      cancelled = true;
      stopStream(streamRef.current);
      streamRef.current = null;
    };
  }, []);

  const toggleTorch = useCallback(async () => {
    const track = streamRef.current?.getVideoTracks()?.[0];
    const next = !torchOn;
    const ok = await setTorch(track, next);
    setTorchOn(ok ? next : false);
  }, [torchOn]);

  const handleCapture = useCallback(async () => {
    if (busy || !ready) return;
    setBusy(true);
    setError(null);
    try {
      const blob = await captureInGuide(
        videoRef.current,
        containerRef.current,
        guideRef.current,
      );
      await onCapture?.(blob);
    } catch (err) {
      setError(
        err instanceof CameraError ? err.message : "Gagal mengambil foto.",
      );
    } finally {
      setBusy(false);
    }
  }, [busy, ready, onCapture]);

  return (
    <div className="fixed inset-0 z-40 bg-black">
      <div ref={containerRef} className="absolute inset-0 overflow-hidden">
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className="absolute inset-0 h-full w-full object-cover"
        />

        {/* Area di luar kotak panduan diredupkan */}
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center px-4">
          <div className="relative w-full" style={{ maxWidth: "42rem" }}>
            <div
              ref={guideRef}
              className="relative mx-auto border-[3px] border-white/90 bg-white/5 shadow-[0_0_0_9999px_rgba(0,0,0,0.6)]"
              style={{ aspectRatio: String(aspect) }}
              aria-label="Kotak panduan"
            >
              {/* Sudut panduan */}
              <span className="absolute -left-[3px] -top-[3px] h-6 w-6 border-l-4 border-t-4 border-brand" />
              <span className="absolute -right-[3px] -top-[3px] h-6 w-6 border-r-4 border-t-4 border-brand" />
              <span className="absolute -bottom-[3px] -left-[3px] h-6 w-6 border-b-4 border-l-4 border-brand" />
              <span className="absolute -bottom-[3px] -right-[3px] h-6 w-6 border-b-4 border-r-4 border-brand" />
            </div>
            {hint ? (
              <p className="mx-auto mt-4 max-w-md rounded-xl bg-black/60 px-3 py-2 text-center text-sm font-medium text-white">
                {hint}
              </p>
            ) : null}
          </div>
        </div>

        {!ready && !error ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-white">
            <Spinner className="h-10 w-10 border-white/30 border-t-white" />
            <p className="text-sm">Membuka kamera…</p>
          </div>
        ) : null}
      </div>

      {/* Judul */}
      <div className="absolute inset-x-0 top-0 bg-gradient-to-b from-black/80 to-transparent px-4 pb-8 pt-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="rounded-lg p-2 text-white hover:bg-white/15"
            aria-label="Batal"
          >
            <Icon name="close" className="h-6 w-6" />
          </button>
          <h2 className="text-base font-bold text-white">{title}</h2>
        </div>
      </div>

      {/* Galat kamera — tetap menawarkan jalan pintas ke input manual */}
      {error ? (
        <div className="absolute inset-x-0 bottom-36 px-4">
          <ErrorNote>{error}</ErrorNote>
        </div>
      ) : null}

      {/* Kontrol bawah */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-4 pb-8 pt-10">
        <div className="mx-auto flex max-w-md items-center justify-between gap-3">
          <button type="button" onClick={onCancel} className="btn-ghost !text-white">
            Batal
          </button>

          <button
            type="button"
            onClick={handleCapture}
            disabled={!ready || busy}
            className="flex h-20 w-20 items-center justify-center rounded-full border-4 border-white bg-white/20 transition active:scale-95 disabled:opacity-40"
            aria-label={captureLabel}
          >
            {busy ? (
              <Spinner className="h-8 w-8 border-white/40 border-t-white" />
            ) : (
              <span className="h-14 w-14 rounded-full bg-white" />
            )}
          </button>

          {torchAvailable ? (
            <button
              type="button"
              onClick={toggleTorch}
              className={`btn-ghost ${torchOn ? "!text-amber-300" : "!text-white"}`}
              aria-pressed={torchOn}
            >
              <Icon name="flash" className="h-6 w-6" />
            </button>
          ) : (
            <span className="w-[72px]" aria-hidden="true" />
          )}
        </div>

        {onManual ? (
          <button
            type="button"
            onClick={onManual}
            className="mx-auto mt-4 flex items-center gap-2 rounded-full bg-white/15 px-4 py-2 text-sm font-semibold text-white hover:bg-white/25"
          >
            <Icon name="edit" className="h-4 w-4" />
            Ketik manual
          </button>
        ) : null}
      </div>
    </div>
  );
}
