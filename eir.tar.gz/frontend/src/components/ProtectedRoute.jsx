import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { LoadingScreen } from "./Feedback";

/** Penjaga rute + penjaga hak akses. */
export default function ProtectedRoute({ permission, children }) {
  const { user, booting, has } = useAuth();
  const location = useLocation();

  if (booting) return <LoadingScreen label="Memeriksa sesi…" />;

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  // Wajib ganti password saat login pertama (SEAL-04)
  if (user.must_change_password && location.pathname !== "/ganti-password") {
    return <Navigate to="/ganti-password" replace />;
  }

  if (permission && !has(permission)) {
    return <Navigate to="/akses-ditolak" replace state={{ from: location.pathname }} />;
  }

  return children;
}
