import { useEffect, useState } from "react";
import { fetchPhotoUrl } from "../api/client";
import { Spinner } from "./Feedback";

/**
 * Menampilkan foto pemeriksaan. Foto hanya dapat diakses user yang berhak
 * (Bagian 10 PRD), sehingga diambil lewat endpoint ber-otentikasi lalu
 * ditampilkan sebagai object URL — bukan lewat <img src> polos.
 */
export default function PhotoView({ url, alt, className = "" }) {
  const [src, setSrc] = useState(null);
  const [state, setState] = useState(url ? "loading" : "missing");

  useEffect(() => {
    let alive = true;
    let objectUrl = null;
    if (!url) {
      setState("missing");
      return () => {};
    }
    setState("loading");
    fetchPhotoUrl(url)
      .then((value) => {
        if (!alive) {
          if (value) URL.revokeObjectURL(value);
          return;
        }
        if (value) {
          objectUrl = value;
          setSrc(value);
          setState("ready");
        } else {
          setState("missing");
        }
      })
      .catch(() => alive && setState("missing"));

    return () => {
      alive = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [url]);

  if (state === "loading") {
    return (
      <div
        className={`flex items-center justify-center bg-slate-100 ${className}`}
        aria-label="Memuat foto"
      >
        <Spinner className="h-6 w-6" />
      </div>
    );
  }

  if (state !== "ready" || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center gap-1 bg-slate-100 px-3 py-6 text-center ${className}`}
      >
        <p className="text-xs font-semibold text-slate-500">
          Foto tidak tersedia
        </p>
        <p className="text-[11px] text-slate-400">
          Kemungkinan sudah melewati masa retensi 24 jam.
        </p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      className={`object-contain ${className}`}
    />
  );
}
