/** Ikon SVG inline — warna tidak boleh menjadi satu-satunya penanda hasil,
 *  sehingga setiap status selalu disertai ikon dan teks (Bagian 7 PRD). */

const PATHS = {
  home: "M3 10.5 12 3l9 7.5M5 9.5V21h14V9.5M9 21v-6h6v6",
  history:
    "M12 8v4l3 2M3.05 11a9 9 0 1 1 .5 4M3 5v6h6",
  chart: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  menu: "M4 7h16M4 12h16M4 17h16",
  check: "M4 12.5 9.5 18 20 6.5",
  x: "M6 6l12 12M18 6 6 18",
  camera: "M4 8h3l1.5-2h7L17 8h3v11H4zM12 16.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z",
  flash: "M13 2 4 14h6l-1 8 9-12h-6z",
  refresh: "M20 11a8 8 0 1 0-.7 4.3M20 5v6h-6",
  back: "M15 5l-7 7 7 7",
  plus: "M12 5v14M5 12h14",
  search: "M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM20 20l-4-4",
  download: "M12 3v12M7.5 10.5 12 15l4.5-4.5M4 20h16",
  user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4.5 20a7.5 7.5 0 0 1 15 0",
  users: "M9 12a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM2.5 20a6.5 6.5 0 0 1 13 0M16 5.5a3.5 3.5 0 0 1 0 7M18 20a6.4 6.4 0 0 0-2-4.6",
  shield: "M12 3l7.5 3v5.5c0 4.6-3.1 8.2-7.5 9.5-4.4-1.3-7.5-4.9-7.5-9.5V6z",
  list: "M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01",
  logout: "M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10",
  warning: "M12 4l9 16H3zM12 10v4M12 17h.01",
  clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3.5 2",
  image: "M4 5h16v14H4zM4 15l4.5-4.5L13 15l3-3 4 4M9 9.5h.01",
  edit: "M4 20h4l10-10-4-4L4 16zM14 6l4 4",
  filter: "M3 5h18l-7 8v6l-4 2v-8z",
  chevron: "M9 6l6 6-6 6",
  close: "M6 6l12 12M18 6 6 18",
  eye: "M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
  key: "M14.5 4a5 5 0 1 0-4.3 7.6L4 17.8V21h3.2l.9-.9v-2h2v-2h2l1.2-1.2A5 5 0 0 0 14.5 4z",
  link: "M14 4h6v6M20 4l-8 8M18 14v6H4V6h6",
  location: "M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11zM12 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z",
  barcode: "M4 6v12M7 6v12M10 6v8M13 6v12M16 6v8M19 6v12M22 6v12",
  info: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 11v5M12 8h.01",
};

export default function Icon({ name, className = "h-5 w-5", strokeWidth = 2 }) {
  const d = PATHS[name];
  if (!d) return null;
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      <path d={d} />
    </svg>
  );
}

/** Ikon bulat besar khusus layar hasil — selalu bersama teks, bukan warna saja. */
export function ResultGlyph({ kind, className = "h-24 w-24" }) {
  const success = kind === "check";
  return (
    <span
      className={`inline-flex items-center justify-center rounded-full border-4 ${
        success ? "border-white/70" : "border-white/70"
      } ${className}`}
      aria-hidden="true"
    >
      <Icon
        name={success ? "check" : "close"}
        className="h-3/5 w-3/5"
        strokeWidth={3}
      />
    </span>
  );
}
