import { Navigate, Route, Routes } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import AuditLog from "./pages/AuditLog";
import ChangePassword from "./pages/ChangePassword";
import CheckNew from "./pages/CheckNew";
import Dashboard from "./pages/Dashboard";
import Denied from "./pages/Denied";
import History from "./pages/History";
import HistoryDetail from "./pages/HistoryDetail";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Profile from "./pages/Profile";
import Roles from "./pages/Roles";
import Users from "./pages/Users";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route
        path="/ganti-password"
        element={
          <ProtectedRoute>
            <ChangePassword />
          </ProtectedRoute>
        }
      />

      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Home />
          </ProtectedRoute>
        }
      />

      <Route
        path="/pemeriksaan/baru"
        element={
          <ProtectedRoute permission="checks.create">
            <CheckNew />
          </ProtectedRoute>
        }
      />

      <Route
        path="/riwayat"
        element={
          <ProtectedRoute permission="checks.view">
            <History />
          </ProtectedRoute>
        }
      />
      <Route
        path="/riwayat/:id"
        element={
          <ProtectedRoute permission="checks.view">
            <HistoryDetail />
          </ProtectedRoute>
        }
      />

      <Route
        path="/dashboard"
        element={
          <ProtectedRoute permission="dashboard.view">
            <Dashboard />
          </ProtectedRoute>
        }
      />

      <Route
        path="/profil"
        element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        }
      />

      <Route
        path="/kelola/user"
        element={
          <ProtectedRoute permission="users.manage">
            <Users />
          </ProtectedRoute>
        }
      />
      <Route
        path="/kelola/role"
        element={
          <ProtectedRoute permission="roles.manage">
            <Roles />
          </ProtectedRoute>
        }
      />
      <Route
        path="/kelola/audit"
        element={
          <ProtectedRoute permission="audit.view">
            <AuditLog />
          </ProtectedRoute>
        }
      />

      <Route
        path="/akses-ditolak"
        element={
          <ProtectedRoute>
            <Denied />
          </ProtectedRoute>
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
