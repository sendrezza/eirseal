/**
 * Klien API + penyimpanan sesi token.
 *
 * Semua permintaan memakai token Bearer dari localStorage. Galat jaringan dan
 * pesan dari server diterjemahkan ke `ApiError` agar bisa ditampilkan apa
 * adanya di UI.
 */

const TOKEN_KEY = "eir.token";
const USER_KEY = "eir.user";
const API_BASE = "/api";

export class ApiError extends Error {
  constructor(message, status = 0, detail = null) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.detail = detail;
  }
}

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },
};

export const userStore = {
  get: () => {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY) || "null");
    } catch {
      return null;
    }
  },
  set: (u) => localStorage.setItem(USER_KEY, JSON.stringify(u)),
};

function authHeaders(extra = {}) {
  const token = tokenStore.get();
  return token ? { ...extra, Authorization: `Bearer ${token}` } : { ...extra };
}

async function readError(response) {
  let detail = null;
  let message = `Permintaan gagal (HTTP ${response.status}).`;
  try {
    const body = await response.json();
    detail = body?.detail ?? null;
    if (typeof detail === "string") message = detail;
    else if (Array.isArray(detail) && detail[0]?.msg)
      message = detail[0].msg;
    else if (body?.message) message = body.message;
  } catch {
    /* respons bukan JSON */
  }
  return new ApiError(message, response.status, detail);
}

export async function api(path, { method = "GET", body, signal, raw = false } = {}) {
  const headers = authHeaders();
  const options = { method, headers, signal };

  if (body !== undefined) {
    if (body instanceof FormData) {
      options.body = body;
    } else {
      headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(body);
    }
  }

  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, options);
  } catch (err) {
    if (err?.name === "AbortError") throw err;
    throw new ApiError(
      "Tidak dapat terhubung ke server. Periksa koneksi internet Anda.",
      0,
    );
  }

  if (response.status === 401) {
    // Sesi kedaluwarsa — biarkan penjaga rute yang mengarahkan ke login.
    if (!path.startsWith("/auth/login")) {
      tokenStore.clear();
    }
    throw await readError(response);
  }

  if (!response.ok) throw await readError(response);

  if (raw) return response;
  if (response.status === 204) return null;
  return response.json();
}

/** Unduh berkas (export Excel) sebagai Blob. */
export async function apiDownload(path) {
  const response = await api(path, { raw: true });
  const blob = await response.blob();
  const disposition = response.headers.get("Content-Disposition") || "";
  const match = disposition.match(/filename="?([^";]+)"?/i);
  const filename = match ? match[1] : "export.xlsx";
  return { blob, filename };
}

/** Ambil foto pemeriksaan sebagai URL objek (foto butuh otentikasi). */
export async function fetchPhotoUrl(url) {
  if (!url) return null;
  try {
    const response = await api(url.replace(API_BASE, ""), { raw: true });
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  } catch {
    return null;
  }
}

export function withQuery(path, params = {}) {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || value === null || value === "") return;
    search.set(key, String(value));
  });
  const qs = search.toString();
  return qs ? `${path}?${qs}` : path;
}
