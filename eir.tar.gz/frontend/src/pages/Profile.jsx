import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import Layout from "../components/Layout";
import Icon from "../components/Icon";
import { ErrorNote } from "../components/Feedback";

export default function Profile() {
  const { user, logout, permissions, scope } = useAuth();
  const navigate = useNavigate();
  const [appInfo, setAppInfo] = useState(null);

  useEffect(() => {
    api("/meta/app-info")
      .then(setAppInfo)
      .catch(() => {});
  }, []);

  const scopeLabel = {
    all: "Semua lokasi",
    location: "Lokasi sendiri",
    own: "Milik sendiri",
  }[scope] || "Milik sendiri";

  const rows = [
    ["ID Karyawan", user?.employee_id],
    ["Email", user?.email],
    ["Username", user?.username],
    ["Role", user?.role_name],
    ["Lokasi / cabang", user?.location],
    ["Status", user?.is_active ? "Aktif" : "Nonaktif"],
    ["Login terakhir", user?.last_login_at ? new Date(user.last_login_at).toLocaleString("id-ID") : "—"],
    ["Cakupan riwayat", scopeLabel],
  ];

  return (
    <Layout title="Profil" subtitle="Akun dan keamanan" back={() => navigate(-1)}>
      <div className="mb-4 flex items-center gap-3 rounded-2xl bg-brand p-4 text-white">
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/15 text-lg font-extrabold ring-1 ring-white/30">
          {user?.full_name?.slice(0, 2).toUpperCase()}
        </span>
        <div className="min-w-0">
          <p className="truncate text-lg font-extrabold">{user?.full_name}</p>
          <p className="truncate text-sm text-white/80">
            {user?.role_name} · {user?.location || "Tanpa lokasi"}
          </p>
        </div>
      </div>

      {user?.must_change_password ? (
        <div className="mb-4 flex items-start gap-2.5 rounded-2xl border border-warning/40 bg-warning-light px-4 py-3 text-warning-dark">
          <Icon name="key" className="mt-0.5 h-5 w-5 shrink-0" />
          <div className="flex-1 text-sm">
            <p className="font-semibold">Password awal belum diganti</p>
            <p className="mt-0.5 text-xs">Anda wajib mengganti password sebelum melanjutkan.</p>
          </div>
          <button
            type="button"
            className="btn-warning btn-sm shrink-0"
            onClick={() => navigate("/ganti-password")}
          >
            Ganti
          </button>
        </div>
      ) : null}

      <section className="card mb-4">
        <h2 className="mb-1 text-sm font-bold uppercase tracking-wide text-slate-500">
          Data akun
        </h2>
        <dl className="divide-y divide-slate-100">
          {rows.map(([label, value]) => (
            <div key={label} className="flex items-start justify-between gap-4 py-2">
              <dt className="text-sm text-slate-500">{label}</dt>
              <dd className="text-right text-sm font-semibold text-slate-900">{value ?? "—"}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="card mb-4">
        <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-500">
          Hak akses ({permissions.length})
        </h2>
        <div className="flex flex-wrap gap-1.5">
          {permissions.length ? (
            permissions.map((p) => (
              <span key={p} className="chip bg-brand-light text-brand-dark">
                {p}
              </span>
            ))
          ) : (
            <span className="text-sm text-slate-500">Tidak ada hak akses khusus.</span>
          )}
        </div>
      </section>

      {appInfo ? (
        <section className="card mb-4">
          <h2 className="mb-1 text-sm font-bold uppercase tracking-wide text-slate-500">
            Informasi sistem
          </h2>
          <dl className="divide-y divide-slate-100">
            <div className="flex items-start justify-between gap-4 py-2">
              <dt className="text-sm text-slate-500">Versi aplikasi</dt>
              <dd className="text-sm font-semibold">{appInfo.version}</dd>
            </div>
            <div className="flex items-start justify-between gap-4 py-2">
              <dt className="text-sm text-slate-500">Retensi foto & log</dt>
              <dd className="text-sm font-semibold">{appInfo.retention_hours} jam</dd>
            </div>
            <div className="flex items-start justify-between gap-4 py-2">
              <dt className="text-sm text-slate-500">Masa berlaku sesi</dt>
              <dd className="text-sm font-semibold">
                {Math.round(appInfo.token_expire_minutes / 60)} jam
              </dd>
            </div>
            <div className="flex items-start justify-between gap-4 py-2">
              <dt className="text-sm text-slate-500">Batas gagal login</dt>
              <dd className="text-sm font-semibold">{appInfo.max_failed_logins} kali</dd>
            </div>
          </dl>
        </section>
      ) : null}

      <div className="grid gap-2 sm:grid-cols-2">
        <button
          type="button"
          className="btn-secondary"
          onClick={() => navigate("/ganti-password")}
        >
          <Icon name="key" className="h-5 w-5" />
          Ubah password
        </button>
        <button type="button" className="btn-danger" onClick={logout}>
          <Icon name="logout" className="h-5 w-5" />
          Keluar
        </button>
      </div>
    </Layout>
  );
}
