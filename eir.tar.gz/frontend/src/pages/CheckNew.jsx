import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { api } from "../api/client";
import { normalize, RESULT_STYLES, validateFormat } from "../utils/matching";
import CameraView from "../components/CameraView";
import Icon, { ResultGlyph } from "../components/Icon";
import { ErrorNote, ProcessingOverlay, Spinner } from "../components/Feedback";

const STEP = {
  EIR_CAPTURE: "eir_capture",
  EIR_CONFIRM: "eir_confirm",
  SEAL_CAPTURE: "seal_capture",
  SEAL_CONFIRM: "seal_confirm",
  NEAR_MATCH: "near_match",
  RESULT: "result",
};

const emptyField = () => ({
  photoId: null,
  photoUrl: null,
  ocrRaw: null, // null = ketik manual, "" = OCR jalan tapi gagal
  final: "",
  warnings: [],
  confidence: null,
  manual: false,
  usedBarcode: false,
});

/* ------------------------------------------------------------------ */
/* Layar konfirmasi hasil OCR (SEAL-14)                                */
/* ------------------------------------------------------------------ */

function ConfirmScreen({
  stepTitle,
  photoUrl,
  value,
  onChange,
  ocrRaw,
  warnings,
  confidence,
  usedBarcode,
  manual,
  onRetake,
  onNext,
  nextLabel,
  busy,
  children,
}) {
  const formatWarnings = useMemo(() => validateFormat(value.trim()), [value]);

  return (
    <div className="mx-auto w-full max-w-2xl">
      <div className="mb-3 flex items-center gap-2">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-brand text-xs font-bold text-white">
          2
        </span>
        <h2 className="text-base font-bold text-slate-900">{stepTitle}</h2>
      </div>

      <div className="card mb-3 p-0">
        {photoUrl ? (
          <img
            src={photoUrl}
            alt="Hasil crop foto"
            className="max-h-64 w-full rounded-t-2xl bg-slate-900 object-contain"
          />
        ) : (
          <div className="flex items-center justify-center gap-2 rounded-t-2xl bg-slate-100 py-8 text-sm font-medium text-slate-500">
            <Icon name="edit" className="h-5 w-5" />
            Diisi secara manual (tanpa foto)
          </div>
        )}

        <div className="p-4">
          <div className="mb-1 flex items-baseline justify-between gap-2">
            <label className="label !mb-0" htmlFor="ocr-final">
              Hasil baca — periksa dan koreksi bila perlu
            </label>
            {confidence != null && !manual ? (
              <span className="text-xs text-slate-400">
                keyakinan {Math.round(confidence)}%
              </span>
            ) : null}
          </div>

          <input
            id="ocr-final"
            className="input !text-xl !font-bold uppercase tracking-wider"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="cth. EMCHUR9175"
            autoCapitalize="characters"
            autoComplete="off"
            spellCheck={false}
            inputMode="text"
          />

          <p className="mt-1.5 text-xs text-slate-500">
            {manual
              ? "Nomor diketik manual."
              : ocrRaw
                ? `Dibaca sebagai: ${ocrRaw}`
                : "Nomor tidak terbaca, silakan foto ulang atau ketik manual."}
          </p>

          {usedBarcode ? (
            <p className="mt-2 flex items-center gap-1.5 rounded-lg bg-brand-light px-2.5 py-1.5 text-xs font-semibold text-brand-dark">
              <Icon name="barcode" className="h-4 w-4" />
              Nomor dibaca dari barcode segel
            </p>
          ) : null}

          <div className="mt-2 space-y-1.5">
            {warnings?.map((w) => (
              <p
                key={w}
                className="flex items-start gap-1.5 rounded-lg bg-warning-light px-2.5 py-1.5 text-xs font-medium text-warning-dark"
              >
                <Icon name="warning" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {w}
              </p>
            ))}
            {formatWarnings.map((w) => (
              <p
                key={w}
                className="flex items-start gap-1.5 rounded-lg bg-slate-100 px-2.5 py-1.5 text-xs font-medium text-slate-600"
              >
                <Icon name="info" className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {w}
              </p>
            ))}
          </div>
        </div>
      </div>

      {children}

      <div className="grid grid-cols-2 gap-3">
        <button type="button" className="btn-secondary" onClick={onRetake}>
          <Icon name="refresh" className="h-5 w-5" />
          Foto Ulang
        </button>
        <button
          type="button"
          className="btn-primary"
          onClick={onNext}
          disabled={busy || !value.trim()}
        >
          {busy ? <Spinner className="h-5 w-5 border-white/40 border-t-white" /> : null}
          {nextLabel}
        </button>
      </div>

      {!value.trim() ? (
        <p className="mt-2 text-center text-xs text-slate-500">
          Isi nomor terlebih dahulu untuk melanjutkan.
        </p>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Halaman utama                                                       */
/* ------------------------------------------------------------------ */

export default function CheckNew() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const refCheckId = useMemo(() => {
    const raw = params.get("ref");
    const n = Number.parseInt(raw || "", 10);
    return Number.isFinite(n) ? n : null;
  }, [params]);

  const [step, setStep] = useState(STEP.EIR_CAPTURE);
  const [eir, setEir] = useState(emptyField());
  const [seal, setSeal] = useState(emptyField());
  const [meta, setMeta] = useState({
    eir_no: "",
    container_no: "",
    booking_no: "",
    notes: "",
  });
  const [match, setMatch] = useState(null);
  const [saved, setSaved] = useState(null);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  const eirUrlRef = useRef(null);
  const sealUrlRef = useRef(null);

  // Bersihkan object URL saat komponen dilepas
  useEffect(
    () => () => {
      if (eirUrlRef.current) URL.revokeObjectURL(eirUrlRef.current);
      if (sealUrlRef.current) URL.revokeObjectURL(sealUrlRef.current);
    },
    [],
  );

  const uploadPhoto = useCallback(async (blob, kind) => {
    const form = new FormData();
    form.append("file", blob, kind === "eir" ? "eir.jpg" : "seal.jpg");
    // `kind` harus dikirim sebagai parameter query: endpoint /checks/scan
    // mendeklarasikannya dengan Query(), bukan Form(). Bila dikirim sebagai
    // field form, nilainya jatuh ke default "seal" sehingga foto dokumen EIR
    // diproses dengan mode satu baris (--psm 7) dan nomor seal di antara
    // teks dokumen tidak terbaca.
    return api(`/checks/scan?kind=${encodeURIComponent(kind)}`, {
      method: "POST",
      body: form,
    });
  }, []);

  const handleCapture = useCallback(
    async (blob) => {
      setError(null);
      setBusy(true);
      try {
        const result = await uploadPhoto(blob, step === STEP.EIR_CAPTURE ? "eir" : "seal");
        if (step === STEP.EIR_CAPTURE) {
          if (eirUrlRef.current) URL.revokeObjectURL(eirUrlRef.current);
          eirUrlRef.current = URL.createObjectURL(blob);
          setEir({
            photoId: result.photo_id,
            photoUrl: eirUrlRef.current,
            ocrRaw: result.ocr_raw || "",
            final: result.ocr_raw || "",
            warnings: result.warnings || [],
            confidence: result.ocr_confidence,
            manual: false,
            usedBarcode: Boolean(result.used_barcode),
          });
          setStep(STEP.EIR_CONFIRM);
        } else {
          if (sealUrlRef.current) URL.revokeObjectURL(sealUrlRef.current);
          sealUrlRef.current = URL.createObjectURL(blob);
          setSeal({
            photoId: result.photo_id,
            photoUrl: sealUrlRef.current,
            ocrRaw: result.ocr_raw || "",
            final: result.ocr_raw || "",
            warnings: result.warnings || [],
            confidence: result.ocr_confidence,
            manual: false,
            usedBarcode: Boolean(result.used_barcode),
          });
          setStep(STEP.SEAL_CONFIRM);
        }
      } catch (err) {
        setError(err?.message || "Gagal memproses foto.");
      } finally {
        setBusy(false);
      }
    },
    [step, uploadPhoto],
  );

  const goManual = useCallback(() => {
    setError(null);
    if (step === STEP.EIR_CAPTURE) {
      setEir({ ...emptyField(), manual: true, photoUrl: null });
      setStep(STEP.EIR_CONFIRM);
    } else {
      setSeal({ ...emptyField(), manual: true, photoUrl: null });
      setStep(STEP.SEAL_CONFIRM);
    }
  }, [step]);

  const saveAndShowResult = useCallback(
    async (preview) => {
      setBusy(true);
      setError(null);
      try {
        const record = await api("/checks", {
          method: "POST",
          body: {
            seal_eir_final: eir.final.trim(),
            seal_actual_final: seal.final.trim(),
            seal_eir_ocr_raw: eir.manual ? null : eir.ocrRaw || "",
            seal_actual_ocr_raw: seal.manual ? null : seal.ocrRaw || "",
            eir_photo_id: eir.photoId,
            seal_photo_id: seal.photoId,
            eir_no: meta.eir_no.trim() || null,
            container_no: meta.container_no.trim() || null,
            booking_no: meta.booking_no.trim() || null,
            notes: meta.notes.trim() || null,
            ref_check_id: refCheckId,
          },
        });
        setSaved(record);
        setMatch(preview);
        setStep(STEP.RESULT);
      } catch (err) {
        setError(err?.message || "Gagal menyimpan hasil pemeriksaan.");
      } finally {
        setBusy(false);
      }
    },
    [eir, seal, meta, refCheckId],
  );

  const runMatch = useCallback(async () => {
    setBusy(true);
    setError(null);
    try {
      const preview = await api("/checks/preview", {
        method: "POST",
        body: {
          seal_eir_final: eir.final.trim(),
          seal_actual_final: seal.final.trim(),
        },
      });
      if (preview.near_match) {
        setMatch(preview);
        setStep(STEP.NEAR_MATCH);
      } else {
        await saveAndShowResult(preview);
      }
    } catch (err) {
      setError(err?.message || "Gagal membandingkan nomor.");
    } finally {
      setBusy(false);
    }
  }, [eir, seal, saveAndShowResult]);

  const reset = useCallback(() => {
    if (eirUrlRef.current) URL.revokeObjectURL(eirUrlRef.current);
    if (sealUrlRef.current) URL.revokeObjectURL(sealUrlRef.current);
    eirUrlRef.current = null;
    sealUrlRef.current = null;
    setEir(emptyField());
    setSeal(emptyField());
    setMeta({ eir_no: "", container_no: "", booking_no: "", notes: "" });
    setMatch(null);
    setSaved(null);
    setError(null);
    setStep(STEP.EIR_CAPTURE);
  }, []);

  /* ------------------------- Layar hasil ------------------------- */

  if (step === STEP.RESULT && saved) {
    const style = RESULT_STYLES[saved.result];
    const success = saved.result === "SUCCESS";
    return (
      <div
        className={`fixed inset-0 z-40 flex flex-col ${style.bg} ${style.text} overflow-y-auto`}
        role="status"
        aria-live="assertive"
      >
        <div className="flex min-h-full flex-col items-center justify-center px-5 py-8 text-center">
          <ResultGlyph kind={style.icon} className="h-24 w-24" />

          <h1 className="result-title mt-5">{style.label}</h1>
          <p className="mt-1 text-2xl font-extrabold uppercase tracking-wide">
            {style.labelId}
          </p>

          {/* Kedua nomor berdampingan (SEAL-16) */}
          <div className="mt-7 grid w-full max-w-xl grid-cols-2 gap-3">
            <div className="rounded-2xl bg-black/15 p-3">
              <p className="text-[11px] font-bold uppercase tracking-widest opacity-80">
                Seal EIR
              </p>
              <p className="result-number mt-1">{normalize(saved.seal_eir_final)}</p>
            </div>
            <div className="rounded-2xl bg-black/15 p-3">
              <p className="text-[11px] font-bold uppercase tracking-widest opacity-80">
                Segel Aktual
              </p>
              <p className="result-number mt-1">{normalize(saved.seal_actual_final)}</p>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-sm font-semibold">
            <span className="chip bg-black/15">
              <Icon name="clock" className="h-4 w-4" />
              {new Date(saved.checked_at).toLocaleString("id-ID")}
            </span>
            {saved.edited_flag ? (
              <span className="chip bg-black/15">
                <Icon name="edit" className="h-4 w-4" />
                Diedit manual
              </span>
            ) : null}
            {saved.near_match_flag ? (
              <span className="chip bg-black/15">
                <Icon name="warning" className="h-4 w-4" />
                Pernah hampir sama
              </span>
            ) : null}
          </div>

          {!success ? (
            <p className="mt-4 max-w-md text-sm font-medium opacity-90">
              Nomor pada dokumen EIR tidak cocok dengan segel aktual. Periksa
              kembali container dan segel sebelum melanjutkan.
            </p>
          ) : null}

          {error ? (
            <div className="mt-4 w-full max-w-md">
              <ErrorNote>{error}</ErrorNote>
            </div>
          ) : null}

          <div className="mt-8 grid w-full max-w-xl gap-3 sm:grid-cols-2">
            <button
              type="button"
              className="btn bg-white text-slate-900 hover:bg-slate-100"
              onClick={reset}
            >
              <Icon name="plus" className="h-5 w-5" />
              Pemeriksaan Baru
            </button>
            <button
              type="button"
              className="btn border-2 border-white/70 text-white hover:bg-white/10"
              onClick={() => navigate(`/riwayat/${saved.id}`)}
            >
              <Icon name="eye" className="h-5 w-5" />
              Lihat Detail
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* -------------------- Peringatan hampir sama -------------------- */

  if (step === STEP.NEAR_MATCH && match) {
    return (
      <div className="fixed inset-0 z-40 flex flex-col overflow-y-auto bg-warning-light">
        <div className="flex min-h-full flex-col items-center justify-center px-5 py-8 text-center">
          <span className="flex h-24 w-24 items-center justify-center rounded-full border-4 border-warning text-warning-dark">
            <Icon name="warning" className="h-12 w-12" strokeWidth={2.5} />
          </span>

          <h1 className="mt-5 text-4xl font-extrabold uppercase leading-none text-warning-dark sm:text-5xl">
            Periksa Kembali
          </h1>
          <p className="mt-2 text-xl font-bold text-warning-dark">
            {match.warnings[0] || "Periksa kembali: nomor hampir sama"}
          </p>

          <p className="mt-3 max-w-md text-sm font-medium text-warning-dark/90">
            Kedua nomor hanya berbeda pada karakter yang mirip (misalnya O/0 atau
            9/S). Sistem <strong>tidak menyatakan Sesuai</strong> — keputusan ada
            pada Anda.
          </p>

          <div className="mt-6 grid w-full max-w-xl grid-cols-2 gap-3">
            <div className="rounded-2xl border-2 border-warning/50 bg-white p-3">
              <p className="text-[11px] font-bold uppercase tracking-widest text-slate-500">
                Seal EIR
              </p>
              <p className="result-number mt-1 text-slate-900">
                {match.normalized_eir}
              </p>
            </div>
            <div className="rounded-2xl border-2 border-warning/50 bg-white p-3">
              <p className="text-[11px] font-bold uppercase tracking-widest text-slate-500">
                Segel Aktual
              </p>
              <p className="result-number mt-1 text-slate-900">
                {match.normalized_actual}
              </p>
            </div>
          </div>

          {error ? (
            <div className="mt-4 w-full max-w-md">
              <ErrorNote>{error}</ErrorNote>
            </div>
          ) : null}

          <div className="mt-7 grid w-full max-w-xl gap-3 sm:grid-cols-2">
            <button
              type="button"
              className="btn-warning"
              onClick={() => setStep(STEP.SEAL_CONFIRM)}
              disabled={busy}
            >
              <Icon name="back" className="h-5 w-5" />
              Periksa Kembali
            </button>
            <button
              type="button"
              className="btn bg-slate-900 text-white hover:bg-slate-800"
              onClick={() => saveAndShowResult(match)}
              disabled={busy}
            >
              {busy ? <Spinner className="h-5 w-5 border-white/40 border-t-white" /> : null}
              Tetap Lanjutkan
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* ------------------------- Layar kamera ------------------------- */

  if (step === STEP.EIR_CAPTURE || step === STEP.SEAL_CAPTURE) {
    const isEir = step === STEP.EIR_CAPTURE;
    return (
      <>
        <CameraView
          title={isEir ? "Langkah 1 — Foto Dokumen EIR" : "Langkah 2 — Foto Segel"}
          hint={
            isEir
              ? "Posisikan nomor seal pada dokumen EIR di dalam kotak. Pastikan terang dan tidak blur."
              : "Posisikan nomor pada segel di dalam kotak. Bila segel memantul, gunakan flash."
          }
          aspect={isEir ? 1.35 : 4}
          captureLabel={isEir ? "Ambil foto dokumen EIR" : "Ambil foto segel"}
          onCapture={handleCapture}
          onCancel={() => (isEir ? navigate("/") : setStep(STEP.EIR_CONFIRM))}
          onManual={goManual}
        />
        {busy ? (
          <ProcessingOverlay
            title="Membaca nomor…"
            detail="Foto sedang dipotong dan diproses OCR."
          />
        ) : null}
        {error ? (
          <div className="fixed inset-x-4 bottom-4 z-50">
            <ErrorNote>{error}</ErrorNote>
          </div>
        ) : null}
      </>
    );
  }

  /* ------------------- Layar konfirmasi OCR ------------------- */

  if (step === STEP.EIR_CONFIRM) {
    return (
      <div className="min-h-screen bg-slate-100 px-4 py-6">
        <div className="mb-4 flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-brand text-xs font-bold text-white">
            1
          </span>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Langkah 1 — Nomor Seal EIR
            </h2>
            <p className="text-xs text-slate-500">Konfirmasi hasil pembacaan</p>
          </div>
        </div>

        <ConfirmScreen
          stepTitle="Periksa nomor seal pada dokumen EIR"
          photoUrl={eir.photoUrl}
          value={eir.final}
          onChange={(v) => setEir((s) => ({ ...s, final: v }))}
          ocrRaw={eir.ocrRaw}
          warnings={eir.warnings}
          confidence={eir.confidence}
          usedBarcode={eir.usedBarcode}
          manual={eir.manual}
          onRetake={() => setStep(STEP.EIR_CAPTURE)}
          onNext={() => setStep(STEP.SEAL_CAPTURE)}
          nextLabel="Lanjut"
          busy={busy}
        />

        <div className="mt-4 grid gap-2">
          <label className="label">Data pendukung (opsional)</label>
          <input
            className="input"
            placeholder="Nomor EIR"
            value={meta.eir_no}
            onChange={(e) => setMeta((m) => ({ ...m, eir_no: e.target.value }))}
          />
          <input
            className="input"
            placeholder="Nomor container"
            value={meta.container_no}
            onChange={(e) => setMeta((m) => ({ ...m, container_no: e.target.value }))}
          />
        </div>

        <button
          type="button"
          className="btn-ghost mt-4 w-full"
          onClick={() => navigate("/")}
        >
          Batalkan pemeriksaan
        </button>
      </div>
    );
  }

  // STEP.SEAL_CONFIRM
  return (
    <div className="min-h-screen bg-slate-100 px-4 py-6">
      {error ? (
        <div className="mb-3">
          <ErrorNote>{error}</ErrorNote>
        </div>
      ) : null}

      <ConfirmScreen
        stepTitle="Periksa nomor pada segel container"
        photoUrl={seal.photoUrl}
        value={seal.final}
        onChange={(v) => setSeal((s) => ({ ...s, final: v }))}
        ocrRaw={seal.ocrRaw}
        warnings={seal.warnings}
        confidence={seal.confidence}
        usedBarcode={seal.usedBarcode}
        manual={seal.manual}
        onRetake={() => setStep(STEP.SEAL_CAPTURE)}
        onNext={runMatch}
        nextLabel="Cocokkan"
        busy={busy}
      >
        <div className="mb-3 grid gap-2 rounded-2xl border border-slate-200 bg-white p-4">
          <p className="text-sm font-bold text-slate-900">Data pendukung (opsional)</p>
          <input
            className="input input-sm"
            placeholder="Nomor EIR"
            value={meta.eir_no}
            onChange={(e) => setMeta((m) => ({ ...m, eir_no: e.target.value }))}
          />
          <input
            className="input input-sm"
            placeholder="Nomor container"
            value={meta.container_no}
            onChange={(e) => setMeta((m) => ({ ...m, container_no: e.target.value }))}
          />
          <input
            className="input input-sm"
            placeholder="Nomor booking / BL"
            value={meta.booking_no}
            onChange={(e) => setMeta((m) => ({ ...m, booking_no: e.target.value }))}
          />
          <textarea
            className="input input-sm"
            rows={2}
            placeholder="Catatan"
            value={meta.notes}
            onChange={(e) => setMeta((m) => ({ ...m, notes: e.target.value }))}
          />
        </div>
      </ConfirmScreen>

      {refCheckId ? (
        <p className="mt-3 flex items-center justify-center gap-1.5 text-center text-xs text-slate-500">
          <Icon name="link" className="h-3.5 w-3.5" />
          Merujuk pemeriksaan #{refCheckId}
        </p>
      ) : null}

      <button
        type="button"
        className="btn-ghost mt-4 w-full"
        onClick={() => navigate("/")}
      >
        Batalkan pemeriksaan
      </button>

      {busy ? (
        <ProcessingOverlay
          title="Membandingkan nomor…"
          detail="Normalisasi dan pencocokan sedang dijalankan."
        />
      ) : null}
    </div>
  );
}
