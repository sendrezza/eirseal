import { useLocation, useNavigate } from "react-router-dom";
import Layout from "../components/Layout";
import Icon from "../components/Icon";

export default function Denied() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <Layout title="Akses Ditolak" back={() => navigate("/")}>
      <div className="flex flex-col items-center gap-3 rounded-2xl border border-slate-200 bg-white px-5 py-12 text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-danger-light text-danger">
          <Icon name="shield" className="h-8 w-8" />
        </span>
        <h2 className="text-xl font-extrabold text-slate-900">
          Anda tidak memiliki akses
        </h2>
        <p className="max-w-sm text-sm text-slate-500">
          Role Anda tidak diizinkan membuka halaman ini. Hubungi Admin bila Anda
          memerlukan hak akses tersebut.
        </p>
        <p className="font-mono text-xs text-slate-400">{location.state?.from || "/"}</p>
        <div className="mt-2 grid w-full max-w-xs gap-2">
          <button type="button" className="btn-primary" onClick={() => navigate("/")}>
            Ke Beranda
          </button>
          <button type="button" className="btn-secondary" onClick={() => navigate(-1)}>
            Kembali
          </button>
        </div>
      </div>
    </Layout>
  );
}
