import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import Layout from "../components/Layout";
import Icon from "../components/Icon";
import { EmptyState, Spinner } from "../components/Feedback";

function StatTile({ label, value, tone = "default" }) {
  const tones = {
    default: "bg-white text-slate-900",
    success: "bg-success-light text-success-dark",
    danger: "bg-danger-light text-danger-dark",
  };
  return (
    <div className={`rounded-2xl border border-slate-200 p-3 text-center ${tones[tone]}`}>
      <p className="text-2xl font-extrabold leading-none">{value}</p>
      <p className="mt-1 text-[11px] font-semibold uppercase tracking-wide opacity-80">
        {label}
      </p>
    </div>
  );
}

export default function Home() {
  const { user, has } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [appInfo, setAppInfo] = useState(null);
  const [loading, setLoading] = useState(has("dashboard.view"));

  useEffect(() => {
    let alive = true;
    api("/meta/app-info")
      .then((info) => alive && setAppInfo(info))
      .catch(() => {});

    if (has("dashboard.view")) {
      api("/checks/dashboard")
        .then((data) => alive && setStats(data))
        .catch(() => alive && setStats(null))
        .finally(() => alive && setLoading(false));
    } else {
      setLoading(false);
    }
    return () => {
      alive = false;
    };
  }, [has]);

  const hour = new Date().getHours();
  const greeting =
    hour < 11 ? "Selamat pagi" : hour < 15 ? "Selamat siang" : hour < 19 ? "Selamat sore" : "Selamat malam";

  return (
    <Layout title="Beranda" subtitle={user?.role_name}>
      {/* Sapaan */}
      <div className="mb-4">
        <p className="text-sm text-slate-500">{greeting},</p>
        <p className="text-xl font-extrabold text-slate-900">{user?.full_name}</p>
        <p className="flex items-center gap-1.5 text-sm text-slate-500">
          <Icon name="location" className="h-4 w-4" />
          {user?.location || "Tanpa lokasi"}
        </p>
      </div>

      {/* Aksi utama */}
      <button
        type="button"
        onClick={() => navigate("/pemeriksaan/baru")}
        className="group mb-4 flex w-full items-center gap-4 rounded-3xl bg-brand p-5 text-left text-white shadow-lg shadow-brand/25 transition active:scale-[0.99] hover:bg-brand-dark"
      >
        <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/30">
          <Icon name="camera" className="h-8 w-8" />
        </span>
        <span className="flex-1">
          <span className="block text-lg font-extrabold">Pemeriksaan Baru</span>
          <span className="block text-sm text-white/80">
            Foto dokumen EIR, lalu foto segel container
          </span>
        </span>
        <Icon name="chevron" className="h-6 w-6 shrink-0 opacity-70" />
      </button>

      {/* Ringkasan hari ini */}
      {has("dashboard.view") ? (
        <section className="mb-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wide text-slate-500">
              Pemeriksaan hari ini
            </h2>
            <Link to="/dashboard" className="text-sm font-semibold text-brand">
              Detail
            </Link>
          </div>

          {loading ? (
            <div className="card flex items-center justify-center py-8">
              <Spinner />
            </div>
          ) : stats ? (
            <div className="grid grid-cols-3 gap-2">
              <StatTile label="Total" value={stats.total} />
              <StatTile label="Sesuai" value={stats.success} tone="success" />
              <StatTile label="Tidak Sesuai" value={stats.failed} tone="danger" />
            </div>
          ) : (
            <EmptyState
              icon="chart"
              title="Belum ada ringkasan"
              hint="Ringkasan akan tampil setelah ada pemeriksaan."
            />
          )}
        </section>
      ) : null}

      {/* Akses cepat */}
      <section className="mb-4 grid grid-cols-2 gap-3">
        {has("checks.view") ? (
          <Link to="/riwayat" className="card flex items-center gap-3">
            <span className="text-brand">
              <Icon name="history" className="h-6 w-6" />
            </span>
            <span>
              <span className="block text-sm font-bold text-slate-900">Riwayat</span>
              <span className="block text-xs text-slate-500">Cari & filter</span>
            </span>
          </Link>
        ) : null}

        {has("reports.export") ? (
          <Link to="/riwayat?export=1" className="card flex items-center gap-3">
            <span className="text-success">
              <Icon name="download" className="h-6 w-6" />
            </span>
            <span>
              <span className="block text-sm font-bold text-slate-900">Rekap Excel</span>
              <span className="block text-xs text-slate-500">Catatan jangka panjang</span>
            </span>
          </Link>
        ) : null}

        {has("dashboard.view") ? (
          <Link to="/dashboard" className="card flex items-center gap-3">
            <span className="text-brand">
              <Icon name="chart" className="h-6 w-6" />
            </span>
            <span>
              <span className="block text-sm font-bold text-slate-900">Dashboard</span>
              <span className="block text-xs text-slate-500">Statistik harian</span>
            </span>
          </Link>
        ) : null}

        <Link to="/profil" className="card flex items-center gap-3">
          <span className="text-slate-500">
            <Icon name="user" className="h-6 w-6" />
          </span>
          <span>
            <span className="block text-sm font-bold text-slate-900">Profil</span>
            <span className="block text-xs text-slate-500">Ganti password</span>
          </span>
        </Link>
      </section>

      {/* Pengingat retensi */}
      <div className="flex items-start gap-3 rounded-2xl border border-warning/30 bg-warning-light px-4 py-3">
        <span className="mt-0.5 shrink-0 text-warning-dark">
          <Icon name="clock" className="h-5 w-5" />
        </span>
        <div className="text-sm text-warning-dark">
          <p className="font-semibold">
            Foto & log pemeriksaan dihapus otomatis setelah{" "}
            {appInfo?.retention_hours ?? 24} jam
          </p>
          <p className="mt-0.5 text-xs leading-relaxed">
            {has("reports.export")
              ? "Lakukan Ekspor Excel pada halaman Riwayat sebagai catatan jangka panjang."
              : "Hubungi Supervisor/Admin untuk ekspor Excel sebagai catatan jangka panjang."}
          </p>
        </div>
      </div>
    </Layout>
  );
}
