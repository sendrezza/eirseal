import { useCallback, useEffect, useState } from "react";
import { api, withQuery } from "../api/client";
import Layout from "../components/Layout";
import Icon from "../components/Icon";
import { EmptyState, ErrorNote, Spinner } from "../components/Feedback";

function Bar({ label, value, pct, tone }) {
  const colors = {
    success: "bg-success",
    failed: "bg-danger",
  };
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between">
        <span className="text-sm font-semibold text-slate-700">{label}</span>
        <span className="text-sm font-bold text-slate-900">
          {value} <span className="font-medium text-slate-500">({pct}%)</span>
        </span>
      </div>
      <div className="h-3 overflow-hidden rounded-full bg-slate-200">
        <div
          className={`h-full rounded-full transition-all ${colors[tone]}`}
          style={{ width: `${Math.min(100, pct)}%` }}
        />
      </div>
    </div>
  );
}

export default function Dashboard() {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await api(withQuery("/checks/dashboard", { date })));
    } catch (err) {
      setError(err?.message || "Gagal memuat dashboard.");
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [date]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <Layout title="Dashboard" subtitle="Ringkasan pemeriksaan harian">
      <div className="card mb-4">
        <label className="label" htmlFor="dash-date">
          Tanggal
        </label>
        <input
          id="dash-date"
          type="date"
          className="input"
          value={date}
          max={today}
          onChange={(e) => setDate(e.target.value || today)}
        />
      </div>

      {error ? (
        <div className="mb-3">
          <ErrorNote>{error}</ErrorNote>
        </div>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-8 w-8" />
        </div>
      ) : !data ? (
        <EmptyState icon="chart" title="Data tidak tersedia" />
      ) : (
        <>
          <div className="mb-4 grid grid-cols-3 gap-2">
            <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center">
              <p className="text-3xl font-extrabold text-slate-900">{data.total}</p>
              <p className="mt-1 text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Total
              </p>
            </div>
            <div className="rounded-2xl border border-success/30 bg-success-light p-4 text-center">
              <p className="text-3xl font-extrabold text-success-dark">{data.success}</p>
              <p className="mt-1 flex items-center justify-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-success-dark">
                <Icon name="check" className="h-3 w-3" strokeWidth={3} /> Sesuai
              </p>
            </div>
            <div className="rounded-2xl border border-danger/30 bg-danger-light p-4 text-center">
              <p className="text-3xl font-extrabold text-danger-dark">{data.failed}</p>
              <p className="mt-1 flex items-center justify-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-danger-dark">
                <Icon name="close" className="h-3 w-3" strokeWidth={3} /> Tidak
              </p>
            </div>
          </div>

          <div className="card space-y-5">
            <h2 className="text-sm font-bold uppercase tracking-wide text-slate-500">
              Persentase hasil
            </h2>
            {data.total === 0 ? (
              <EmptyState
                icon="chart"
                title="Belum ada pemeriksaan"
                hint={`Tidak ada pemeriksaan pada ${new Date(
                  `${date}T00:00:00`,
                ).toLocaleDateString("id-ID", {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}.`}
              />
            ) : (
              <>
                <Bar label="Sesuai" value={data.success} pct={data.success_pct} tone="success" />
                <Bar
                  label="Tidak Sesuai"
                  value={data.failed}
                  pct={data.failed_pct}
                  tone="failed"
                />
                <div className="flex items-start gap-2 rounded-xl bg-slate-50 p-3 text-xs text-slate-600">
                  <Icon name="clock" className="mt-0.5 h-4 w-4 shrink-0" />
                  <p>
                    Data pemeriksaan dihapus otomatis 24 jam setelah dibuat.
                    Rekap Excel adalah catatan jangka panjang.
                  </p>
                </div>
              </>
            )}
          </div>
        </>
      )}
    </Layout>
  );
}
