import { useState } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import Icon from "../components/Icon";
import { ErrorNote, Spinner } from "../components/Feedback";

export default function Login() {
  const { user, login, booting } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  if (!booting && user) {
    const to = location.state?.from || "/";
    return <Navigate to={to} replace />;
  }

  async function onSubmit(e) {
    e.preventDefault();
    if (submitting) return;
    setError(null);

    if (!username.trim() || !password) {
      setError("Isi username dan password terlebih dahulu.");
      return;
    }

    setSubmitting(true);
    try {
      const profile = await login(username.trim(), password);
      navigate(profile.must_change_password ? "/ganti-password" : "/", {
        replace: true,
      });
    } catch (err) {
      setError(err?.message || "Login gagal.");
      setPassword("");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col justify-center bg-gradient-to-b from-brand to-brand-dark px-5 py-10">
      <div className="mx-auto w-full max-w-sm">
        <div className="mb-7 text-center text-white">
          <span className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/30">
            <Icon name="check" className="h-8 w-8" strokeWidth={3} />
          </span>
          <h1 className="text-xl font-extrabold leading-tight">
            Verifikasi Nomor Seal EIR
          </h1>
          <p className="mt-1 text-sm text-white/80">
            PT. NX Lemo Indonesia Logistik
          </p>
        </div>

        <form
          onSubmit={onSubmit}
          className="rounded-3xl bg-white p-5 shadow-xl"
          noValidate
        >
          <h2 className="mb-4 text-lg font-bold text-slate-900">Masuk</h2>

          <div className="mb-3">
            <label className="label" htmlFor="username">
              Username
            </label>
            <input
              id="username"
              className="input"
              autoComplete="username"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="username"
              disabled={submitting}
            />
          </div>

          <div className="mb-4">
            <label className="label" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              type="password"
              className="input"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              disabled={submitting}
            />
          </div>

          {error ? <div className="mb-3">{<ErrorNote>{error}</ErrorNote>}</div> : null}

          <button
            type="submit"
            className="btn-primary w-full"
            disabled={submitting}
          >
            {submitting ? (
              <>
                <Spinner className="h-5 w-5 border-white/40 border-t-white" />
                Memeriksa…
              </>
            ) : (
              "Masuk"
            )}
          </button>
        </form>

        <p className="mt-5 text-center text-xs leading-relaxed text-white/70">
          Akun diberikan oleh Admin. Akun baru wajib mengganti password saat
          login pertama.
        </p>
      </div>
    </div>
  );
}
