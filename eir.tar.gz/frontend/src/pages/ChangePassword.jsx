import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import Icon from "../components/Icon";
import { ErrorNote, Spinner } from "../components/Feedback";

function strengthOf(pw) {
  let score = 0;
  if (pw.length >= 8) score += 1;
  if (pw.length >= 12) score += 1;
  if (/[A-Za-z]/.test(pw) && /\d/.test(pw)) score += 1;
  if (/[^A-Za-z0-9]/.test(pw)) score += 1;
  return Math.min(score, 4);
}

const STRENGTH_LABEL = ["Sangat lemah", "Lemah", "Cukup", "Kuat", "Sangat kuat"];

export default function ChangePassword() {
  const { user, logout, refreshUser, mustChangePassword } = useAuth();
  const navigate = useNavigate();

  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const strength = strengthOf(newPassword);

  async function onSubmit(e) {
    e.preventDefault();
    setError(null);

    if (newPassword.length < 8) {
      setError("Password baru minimal 8 karakter.");
      return;
    }
    if (!/[A-Za-z]/.test(newPassword) || !/\d/.test(newPassword)) {
      setError("Password harus memuat minimal satu huruf dan satu angka.");
      return;
    }
    if (newPassword !== confirm) {
      setError("Konfirmasi password tidak sama.");
      return;
    }

    setSubmitting(true);
    try {
      if (mustChangePassword) {
        await api("/auth/change-password-first", {
          method: "POST",
          body: { new_password: newPassword },
        });
        await refreshUser();
        setDone(true);
        setTimeout(() => navigate("/", { replace: true }), 900);
      } else {
        await api("/auth/change-password", {
          method: "POST",
          body: { old_password: oldPassword, new_password: newPassword },
        });
        setDone(true);
        setTimeout(() => navigate(-1), 900);
      }
    } catch (err) {
      setError(err?.message || "Gagal mengubah password.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col justify-center bg-slate-100 px-5 py-10">
      <div className="mx-auto w-full max-w-sm">
        <div className="mb-6 text-center">
          <span className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-brand text-white">
            <Icon name="key" className="h-6 w-6" />
          </span>
          <h1 className="text-lg font-extrabold text-slate-900">
            {mustChangePassword ? "Ganti Password Awal" : "Ubah Password"}
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            {mustChangePassword
              ? `Selamat datang, ${user?.full_name}. Password awal wajib diganti sebelum melanjutkan.`
              : "Masukkan password lama Anda untuk melanjutkan."}
          </p>
        </div>

        <form onSubmit={onSubmit} className="card space-y-4" noValidate>
          {!mustChangePassword ? (
            <div>
              <label className="label" htmlFor="old">
                Password lama
              </label>
              <input
                id="old"
                type="password"
                className="input"
                autoComplete="current-password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                disabled={submitting}
              />
            </div>
          ) : null}

          <div>
            <label className="label" htmlFor="new">
              Password baru
            </label>
            <input
              id="new"
              type="password"
              className="input"
              autoComplete="new-password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              disabled={submitting}
            />
            {newPassword ? (
              <div className="mt-2 flex items-center gap-2">
                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-200">
                  <div
                    className={`h-full rounded-full transition-all ${
                      strength >= 3
                        ? "bg-success"
                        : strength === 2
                          ? "bg-warning"
                          : "bg-danger"
                    }`}
                    style={{ width: `${(strength / 4) * 100}%` }}
                  />
                </div>
                <span className="text-xs font-medium text-slate-500">
                  {STRENGTH_LABEL[strength]}
                </span>
              </div>
            ) : (
              <p className="mt-1.5 text-xs text-slate-500">
                Min. 8 karakter, memuat huruf dan angka.
              </p>
            )}
          </div>

          <div>
            <label className="label" htmlFor="confirm">
              Ulangi password baru
            </label>
            <input
              id="confirm"
              type="password"
              className="input"
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              disabled={submitting}
            />
          </div>

          {error ? <ErrorNote>{error}</ErrorNote> : null}
          {done ? (
            <p className="flex items-center gap-2 rounded-xl bg-success-light px-3 py-2.5 text-sm font-medium text-success-dark">
              <Icon name="check" className="h-4 w-4" strokeWidth={3} />
              Password berhasil diubah.
            </p>
          ) : null}

          <button
            type="submit"
            className="btn-primary w-full"
            disabled={submitting || done}
          >
            {submitting ? <Spinner className="h-5 w-5 border-white/40 border-t-white" /> : null}
            Simpan password
          </button>

          {!mustChangePassword ? (
            <button
              type="button"
              className="btn-ghost w-full"
              onClick={() => navigate(-1)}
              disabled={submitting}
            >
              Batal
            </button>
          ) : (
            <button
              type="button"
              className="btn-ghost w-full"
              onClick={logout}
              disabled={submitting}
            >
              Keluar
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
