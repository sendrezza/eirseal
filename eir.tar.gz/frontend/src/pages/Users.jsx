import { useCallback, useEffect, useMemo, useState } from "react";
import { api, withQuery } from "../api/client";
import { useAuth } from "../context/AuthContext";
import Layout from "../components/Layout";
import Icon from "../components/Icon";
import Modal from "../components/Modal";
import { EmptyState, ErrorNote, Spinner } from "../components/Feedback";

const EMPTY_FORM = {
  employee_id: "",
  full_name: "",
  email: "",
  username: "",
  password: "",
  role_id: "",
  location: "",
  is_active: true,
};

function UserForm({ initial, roles, onSubmit, onCancel, submitting, error }) {
  const [form, setForm] = useState(initial);
  const set = (key) => (e) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));
  const isEdit = Boolean(initial.id);

  const valid =
    form.employee_id.trim() &&
    form.full_name.trim() &&
    form.email.trim() &&
    form.username.trim() &&
    form.role_id &&
    (isEdit || (form.password && form.password.length >= 8));

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (valid) onSubmit(form);
      }}
      className="space-y-3"
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="employee_id">ID Karyawan</label>
          <input id="employee_id" className="input input-sm" value={form.employee_id} onChange={set("employee_id")} disabled={submitting} />
        </div>
        <div>
          <label className="label" htmlFor="full_name">Nama lengkap</label>
          <input id="full_name" className="input input-sm" value={form.full_name} onChange={set("full_name")} disabled={submitting} />
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" type="email" className="input input-sm" value={form.email} onChange={set("email")} disabled={submitting} />
        </div>
        <div>
          <label className="label" htmlFor="username">Username</label>
          <input id="username" className="input input-sm" autoCapitalize="none" spellCheck={false} value={form.username} onChange={set("username")} disabled={submitting} />
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="role_id">Role</label>
          <select id="role_id" className="input input-sm" value={form.role_id} onChange={set("role_id")} disabled={submitting}>
            <option value="">— pilih role —</option>
            {roles.map((r) => (
              <option key={r.id} value={r.id}>{r.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="location">Lokasi / cabang</label>
          <input id="location" className="input input-sm" placeholder="cth. Depo Merak" value={form.location} onChange={set("location")} disabled={submitting} />
        </div>
      </div>

      <div>
        <label className="label" htmlFor="password">
          {isEdit ? "Password baru (opsional)" : "Password awal"}
        </label>
        <input
          id="password"
          type="text"
          className="input input-sm"
          autoComplete="new-password"
          placeholder={isEdit ? "Biarkan kosong bila tidak diganti" : "Min. 8 karakter, huruf + angka"}
          value={form.password}
          onChange={set("password")}
          disabled={submitting}
        />
        <p className="mt-1 text-xs text-slate-500">
          {isEdit
            ? "Bila diisi, user wajib mengganti password saat login berikutnya."
            : "User wajib mengganti password saat login pertama."}
        </p>
      </div>

      <label className="flex items-center gap-2.5 rounded-xl bg-slate-50 px-3 py-2.5">
        <input
          type="checkbox"
          className="h-4 w-4 rounded border-slate-300 text-brand focus:ring-brand"
          checked={form.is_active}
          onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
          disabled={submitting}
        />
        <span className="text-sm font-medium text-slate-700">Akun aktif</span>
      </label>

      {error ? <ErrorNote>{error}</ErrorNote> : null}

      <div className="grid grid-cols-2 gap-3 pt-1">
        <button type="button" className="btn-secondary" onClick={onCancel} disabled={submitting}>
          Batal
        </button>
        <button type="submit" className="btn-primary" disabled={submitting || !valid}>
          {submitting ? <Spinner className="h-5 w-5 border-white/40 border-t-white" /> : null}
          {isEdit ? "Simpan" : "Tambah"}
        </button>
      </div>
    </form>
  );
}

export default function Users() {
  const { user: me } = useAuth();
  const [roles, setRoles] = useState([]);
  const [locations, setLocations] = useState([]);
  const [data, setData] = useState({ items: [], total: 0, page: 1, page_size: 50 });
  const [filters, setFilters] = useState({ q: "", role_id: "", location: "", status: "" });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState(null);
  const [tempPassword, setTempPassword] = useState(null);
  const [confirmAction, setConfirmAction] = useState(null);

  const loadUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await api(withQuery("/users", { page_size: 50, ...filters })));
    } catch (err) {
      setError(err?.message || "Gagal memuat daftar user.");
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  useEffect(() => {
    Promise.all([api("/roles").catch(() => []), api("/meta/locations").catch(() => ({ locations: [] }))])
      .then(([roleList, locList]) => {
        setRoles(roleList);
        setLocations(locList?.locations || []);
      })
      .catch(() => {});
  }, []);

  const roleOptions = useMemo(() => roles, [roles]);

  const openCreate = () => {
    setEditing(null);
    setFormError(null);
    setFormOpen(true);
  };

  const openEdit = (u) => {
    setEditing(u);
    setFormError(null);
    setForm({
      ...EMPTY_FORM,
      ...u,
      role_id: String(u.role_id),
      password: "",
    });
    setFormOpen(true);
  };

  const submit = async (values) => {
    setSubmitting(true);
    setFormError(null);
    try {
      const payload = {
        employee_id: values.employee_id.trim(),
        full_name: values.full_name.trim(),
        email: values.email.trim(),
        username: values.username.trim(),
        role_id: Number(values.role_id),
        location: values.location.trim() || null,
        is_active: Boolean(values.is_active),
      };
      if (values.password) payload.password = values.password;

      if (editing) {
        await api(`/users/${editing.id}`, { method: "PUT", body: payload });
      } else {
        await api("/users", { method: "POST", body: payload });
      }
      setFormOpen(false);
      setEditing(null);
      setForm(EMPTY_FORM);
      await loadUsers();
    } catch (err) {
      setFormError(err?.message || "Gagal menyimpan user.");
    } finally {
      setSubmitting(false);
    }
  };

  const resetPassword = async (u) => {
    setSubmitting(true);
    setError(null);
    try {
      const res = await api(`/users/${u.id}/reset-password`, { method: "POST" });
      setTempPassword(res.detail);
      await loadUsers();
    } catch (err) {
      setError(err?.message || "Gagal reset password.");
    } finally {
      setSubmitting(false);
      setConfirmAction(null);
    }
  };

  const deactivate = async (u) => {
    setSubmitting(true);
    setError(null);
    try {
      await api(`/users/${u.id}`, { method: "DELETE" });
      await loadUsers();
    } catch (err) {
      setError(err?.message || "Gagal menonaktifkan user.");
    } finally {
      setSubmitting(false);
      setConfirmAction(null);
    }
  };

  return (
    <Layout
      title="Master User"
      subtitle={`${data.total} pengguna terdaftar`}
      back={() => window.history.back()}
      actions={
        <button
          type="button"
          onClick={openCreate}
          className="flex items-center gap-1 rounded-lg bg-brand px-2.5 py-1.5 text-sm font-semibold text-white hover:bg-brand-dark"
        >
          <Icon name="plus" className="h-4 w-4" />
          Tambah
        </button>
      }
    >
      {/* Pencarian & filter (SEAL-05) */}
      <div className="card mb-4 space-y-2.5">
        <div className="relative">
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
            <Icon name="search" className="h-4 w-4" />
          </span>
          <input
            className="input input-sm !pl-9"
            placeholder="Cari nama, username, ID karyawan, atau email"
            value={filters.q}
            onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))}
          />
        </div>
        <div className="grid grid-cols-3 gap-2">
          <select
            className="input input-sm"
            value={filters.role_id}
            onChange={(e) => setFilters((f) => ({ ...f, role_id: e.target.value }))}
            aria-label="Filter role"
          >
            <option value="">Semua role</option>
            {roleOptions.map((r) => (
              <option key={r.id} value={r.id}>{r.name}</option>
            ))}
          </select>
          <select
            className="input input-sm"
            value={filters.location}
            onChange={(e) => setFilters((f) => ({ ...f, location: e.target.value }))}
            aria-label="Filter lokasi"
          >
            <option value="">Semua lokasi</option>
            {locations.map((l) => (
              <option key={l} value={l}>{l}</option>
            ))}
          </select>
          <select
            className="input input-sm"
            value={filters.status}
            onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}
            aria-label="Filter status"
          >
            <option value="">Semua status</option>
            <option value="active">Aktif</option>
            <option value="inactive">Nonaktif</option>
          </select>
        </div>
      </div>

      {error ? (
        <div className="mb-3">
          <ErrorNote>{error}</ErrorNote>
        </div>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-8 w-8" />
        </div>
      ) : data.items.length === 0 ? (
        <EmptyState icon="users" title="Tidak ada user" hint="Ubah filter atau tambah user baru." />
      ) : (
        <div className="space-y-2">
          {data.items.map((u) => {
            const isMe = u.id === me?.id;
            return (
              <div key={u.id} className="card !p-3.5">
                <div className="flex items-start gap-3">
                  <span
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-sm font-bold ${
                      u.is_active ? "bg-brand-light text-brand-dark" : "bg-slate-200 text-slate-500"
                    }`}
                  >
                    {u.full_name?.slice(0, 2).toUpperCase()}
                  </span>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <p className="truncate font-bold text-slate-900">{u.full_name}</p>
                      {u.is_active ? (
                        <span className="chip bg-success-light text-success-dark">Aktif</span>
                      ) : (
                        <span className="chip bg-slate-100 text-slate-500">Nonaktif</span>
                      )}
                      {u.must_change_password ? (
                        <span className="chip bg-warning-light text-warning-dark">
                          Wajib ganti password
                        </span>
                      ) : null}
                    </div>
                    <p className="truncate text-sm text-slate-500">
                      @{u.username} · {u.employee_id} · {u.email}
                    </p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500">
                      <span className="chip bg-slate-100 text-slate-600">{u.role_name}</span>
                      <span className="inline-flex items-center gap-1">
                        <Icon name="location" className="h-3 w-3" />
                        {u.location || "—"}
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Icon name="clock" className="h-3 w-3" />
                        {u.last_login_at
                          ? `login ${new Date(u.last_login_at).toLocaleString("id-ID")}`
                          : "belum pernah login"}
                      </span>
                    </p>
                  </div>

                  <div className="flex shrink-0 flex-col gap-1">
                    <button
                      type="button"
                      className="btn-secondary btn-sm"
                      onClick={() => openEdit(u)}
                      disabled={submitting}
                    >
                      <Icon name="edit" className="h-4 w-4" /> Ubah
                    </button>
                    <button
                      type="button"
                      className="btn-secondary btn-sm"
                      onClick={() => setConfirmAction({ type: "reset", user: u })}
                      disabled={submitting}
                    >
                      <Icon name="key" className="h-4 w-4" /> Reset
                    </button>
                    {!isMe && u.is_active ? (
                      <button
                        type="button"
                        className="btn-sm rounded-lg border border-danger/40 px-3 font-semibold text-danger hover:bg-danger-light"
                        onClick={() => setConfirmAction({ type: "deactivate", user: u })}
                        disabled={submitting}
                      >
                        Nonaktifkan
                      </button>
                    ) : null}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Form tambah / ubah */}
      <Modal
        open={formOpen}
        title={editing ? `Ubah User — ${editing.full_name}` : "Tambah User"}
        onClose={() => setFormOpen(false)}
        wide
      >
        <UserForm
          initial={editing ? form : EMPTY_FORM}
          roles={roles}
          onSubmit={submit}
          onCancel={() => setFormOpen(false)}
          submitting={submitting}
          error={formError}
        />
      </Modal>

      {/* Konfirmasi aksi */}
      <Modal
        open={Boolean(confirmAction)}
        title={confirmAction?.type === "reset" ? "Reset password" : "Nonaktifkan akun"}
        onClose={() => setConfirmAction(null)}
      >
        <div className="space-y-3 text-sm text-slate-700">
          {confirmAction?.type === "reset" ? (
            <p>
              Password <strong>{confirmAction?.user?.full_name}</strong> akan
              diganti dengan password sementara. User wajib mengganti password
              saat login berikutnya.
            </p>
          ) : (
            <p>
              Akun <strong>{confirmAction?.user?.full_name}</strong> akan
              dinonaktifkan (soft delete). Riwayat dan log tetap tersimpan.
            </p>
          )}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              className="btn-secondary"
              onClick={() => setConfirmAction(null)}
              disabled={submitting}
            >
              Batal
            </button>
            <button
              type="button"
              className={confirmAction?.type === "reset" ? "btn-primary" : "btn-danger"}
              onClick={() =>
                confirmAction?.type === "reset"
                  ? resetPassword(confirmAction.user)
                  : deactivate(confirmAction.user)
              }
              disabled={submitting}
            >
              {submitting ? <Spinner className="h-5 w-5 border-white/40 border-t-white" /> : null}
              Ya, lanjutkan
            </button>
          </div>
        </div>
      </Modal>

      {/* Password sementara hasil reset */}
      <Modal
        open={Boolean(tempPassword)}
        title="Password sementara"
        onClose={() => setTempPassword(null)}
      >
        <div className="space-y-3 text-sm">
          <p className="text-slate-700">
            Berikan password ini kepada{" "}
            <strong>{tempPassword?.username}</strong> dan suruh mereka menggantinya
            saat login.
          </p>
          <div className="flex items-center justify-between gap-3 rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-3">
            <code className="select-all font-mono text-lg font-bold tracking-wider text-slate-900">
              {tempPassword?.temporary_password}
            </code>
            <button
              type="button"
              className="btn-secondary btn-sm"
              onClick={() => {
                navigator.clipboard?.writeText(tempPassword?.temporary_password || "");
              }}
            >
              Salin
            </button>
          </div>
          <button type="button" className="btn-primary w-full" onClick={() => setTempPassword(null)}>
            Selesai
          </button>
        </div>
      </Modal>
    </Layout>
  );
}
