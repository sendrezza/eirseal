import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import Layout from "../components/Layout";
import Icon from "../components/Icon";
import PhotoView from "../components/PhotoView";
import { ErrorNote, LoadingScreen, Spinner } from "../components/Feedback";
import { normalize, RESULT_STYLES } from "../utils/matching";

function Row({ label, value, mono = false }) {
  return (
    <div className="flex items-start justify-between gap-4 py-2">
      <dt className="text-sm text-slate-500">{label}</dt>
      <dd
        className={`text-right text-sm font-semibold text-slate-900 ${
          mono ? "font-mono" : ""
        }`}
      >
        {value ?? "-"}
      </dd>
    </div>
  );
}

export default function HistoryDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { has } = useAuth();

  const [item, setItem] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [followUp, setFollowUp] = useState("");
  const [savingFollowUp, setSavingFollowUp] = useState(false);
  const [followUpError, setFollowUpError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setItem(await api(`/checks/${id}`));
    } catch (err) {
      setError(err?.message || "Pemeriksaan tidak ditemukan.");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  const submitFollowUp = async (e) => {
    e.preventDefault();
    if (!followUp.trim()) return;
    setSavingFollowUp(true);
    setFollowUpError(null);
    try {
      const updated = await api(`/checks/${id}/follow-up`, {
        method: "POST",
        body: { notes: followUp.trim() },
      });
      setItem(updated);
      setFollowUp("");
    } catch (err) {
      setFollowUpError(err?.message || "Gagal menyimpan catatan.");
    } finally {
      setSavingFollowUp(false);
    }
  };

  if (loading) return <LoadingScreen label="Memuat detail…" />;

  if (!item) {
    return (
      <Layout title="Detail Pemeriksaan" back={() => navigate("/riwayat")}>
        <ErrorNote>{error}</ErrorNote>
        <button className="btn-secondary mt-4 w-full" onClick={() => navigate("/riwayat")}>
          Kembali ke riwayat
        </button>
      </Layout>
    );
  }

  const style = RESULT_STYLES[item.result];
  const success = item.result === "SUCCESS";

  return (
    <Layout
      title={`Pemeriksaan #${item.id}`}
      subtitle={new Date(item.checked_at).toLocaleString("id-ID")}
      back={() => navigate(-1)}
      actions={
        <button
          type="button"
          onClick={() => navigate(`/pemeriksaan/baru?ref=${item.id}`)}
          className="rounded-lg p-2 text-brand hover:bg-brand-light"
          aria-label="Buat pemeriksaan baru dengan referensi ini"
          title="Koreksi dengan pemeriksaan baru (aturan bisnis no.5)"
        >
          <Icon name="plus" className="h-5 w-5" />
        </button>
      }
    >
      {/* Hasil */}
      <div
        className={`mb-4 flex items-center gap-3 rounded-2xl px-4 py-4 ${style.bg} ${style.text}`}
      >
        <ResultIcon success={success} />
        <div>
          <p className="result-title !text-4xl">{style.label}</p>
          <p className="text-lg font-extrabold uppercase tracking-wide">
            {style.labelId}
          </p>
        </div>
      </div>

      {/* Kedua nomor */}
      <div className="mb-4 grid grid-cols-2 gap-3">
        <div className="card !p-3">
          <p className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
            Seal EIR
          </p>
          <p className="mt-1 break-all font-mono text-xl font-extrabold text-slate-900">
            {normalize(item.seal_eir_final)}
          </p>
          <p className="mt-1 text-[11px] text-slate-500">
            OCR: {item.seal_eir_ocr_raw || "—"}
          </p>
        </div>
        <div className="card !p-3">
          <p className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
            Segel Aktual
          </p>
          <p className="mt-1 break-all font-mono text-xl font-extrabold text-slate-900">
            {normalize(item.seal_actual_final)}
          </p>
          <p className="mt-1 text-[11px] text-slate-500">
            OCR: {item.seal_actual_ocr_raw || "—"}
          </p>
        </div>
      </div>

      {/* Penanda */}
      <div className="mb-4 flex flex-wrap gap-2">
        {item.edited_flag ? (
          <span className="chip bg-warning-light text-warning-dark">
            <Icon name="edit" className="h-3.5 w-3.5" />
            Hasil OCR diedit manual
          </span>
        ) : null}
        {item.near_match_flag ? (
          <span className="chip bg-warning-light text-warning-dark">
            <Icon name="warning" className="h-3.5 w-3.5" />
            Hampir sama
          </span>
        ) : null}
        {item.ref_check_id ? (
          <Link
            to={`/riwayat/${item.ref_check_id}`}
            className="chip bg-brand-light text-brand-dark hover:underline"
          >
            <Icon name="link" className="h-3.5 w-3.5" />
            Rujukan #{item.ref_check_id}
          </Link>
        ) : null}
      </div>

      {/* Foto bukti */}
      <section className="mb-4">
        <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-500">
          Foto bukti
        </h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <figure className="card overflow-hidden !p-0">
            <figcaption className="border-b border-slate-100 px-3 py-2 text-xs font-bold text-slate-600">
              Dokumen EIR
            </figcaption>
            <PhotoView
              url={item.eir_photo_url}
              alt="Foto dokumen EIR"
              className="h-52 w-full"
            />
          </figure>
          <figure className="card overflow-hidden !p-0">
            <figcaption className="border-b border-slate-100 px-3 py-2 text-xs font-bold text-slate-600">
              Segel container
            </figcaption>
            <PhotoView
              url={item.seal_photo_url}
              alt="Foto segel container"
              className="h-52 w-full"
            />
          </figure>
        </div>
      </section>

      {/* Metadata */}
      <section className="card mb-4">
        <h2 className="mb-1 text-sm font-bold uppercase tracking-wide text-slate-500">
          Metadata
        </h2>
        <dl className="divide-y divide-slate-100">
          <Row label="Waktu pemeriksaan" value={new Date(item.checked_at).toLocaleString("id-ID")} />
          <Row label="Petugas" value={`${item.user_name} (${item.user_username})`} />
          <Row label="Lokasi" value={item.location} />
          <Row label="Nomor EIR" value={item.eir_no} />
          <Row label="Nomor container" value={item.container_no} />
          <Row label="Nomor booking / BL" value={item.booking_no} />
          <Row label="Catatan" value={item.notes} />
        </dl>
      </section>

      {/* Tindak lanjut (SEAL-26) */}
      {has("followup.manage") ? (
        <section className="card mb-4">
          <h2 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-500">
            Tindak lanjut
          </h2>

          {item.follow_up_notes ? (
            <div className="mb-3 rounded-xl bg-slate-50 p-3">
              <p className="whitespace-pre-wrap text-sm text-slate-800">
                {item.follow_up_notes}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                {item.follow_up_by_name} ·{" "}
                {item.follow_up_at
                  ? new Date(item.follow_up_at).toLocaleString("id-ID")
                  : "-"}
              </p>
            </div>
          ) : !success ? (
            <p className="mb-2 text-xs text-slate-500">
              Belum ada catatan untuk kasus ini.
            </p>
          ) : null}

          {!success ? (
            <form onSubmit={submitFollowUp} className="space-y-2">
              <textarea
                className="input input-sm"
                rows={3}
                placeholder="Tulis tindak lanjut untuk kasus Tidak Sesuai…"
                value={followUp}
                onChange={(e) => setFollowUp(e.target.value)}
              />
              {followUpError ? <ErrorNote>{followUpError}</ErrorNote> : null}
              <button
                type="submit"
                className="btn-primary btn-sm w-full"
                disabled={savingFollowUp || !followUp.trim()}
              >
                {savingFollowUp ? <Spinner className="h-4 w-4 border-white/40 border-t-white" /> : null}
                Simpan catatan
              </button>
            </form>
          ) : null}
        </section>
      ) : null}

      <div className="grid gap-2 sm:grid-cols-2">
        <button
          type="button"
          className="btn-primary"
          onClick={() => navigate(`/pemeriksaan/baru?ref=${item.id}`)}
        >
          <Icon name="plus" className="h-5 w-5" />
          Pemeriksaan baru (referensi)
        </button>
        <button type="button" className="btn-secondary" onClick={() => navigate("/riwayat")}>
          <Icon name="history" className="h-5 w-5" />
          Kembali ke riwayat
        </button>
      </div>
    </Layout>
  );
}

function ResultIcon({ success }) {
  return (
    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-4 border-white/70">
      <Icon
        name={success ? "check" : "close"}
        className="h-7 w-7"
        strokeWidth={3}
      />
    </span>
  );
}
