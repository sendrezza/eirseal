import { useCallback, useEffect, useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";
import Icon from "../components/Icon";
import Modal from "../components/Modal";
import { EmptyState, ErrorNote, Spinner } from "../components/Feedback";

const EMPTY = { name: "", description: "", permissions: [], history_scope: "own" };

const SCOPE_LABEL = {
  all: "Semua lokasi",
  location: "Lokasi sendiri",
  own: "Milik sendiri",
};

export default function Roles() {
  const [roles, setRoles] = useState([]);
  const [catalog, setCatalog] = useState({ permissions: [], history_scopes: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [formError, setFormError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setRoles(await api("/roles"));
    } catch (err) {
      setError(err?.message || "Gagal memuat daftar role.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    api("/roles/permissions")
      .then(setCatalog)
      .catch(() => {});
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setForm(EMPTY);
    setFormError(null);
    setFormOpen(true);
  };

  const openEdit = (role) => {
    setEditing(role);
    setForm({
      name: role.name,
      description: role.description || "",
      permissions: [...(role.permissions || [])],
      history_scope: role.history_scope,
    });
    setFormError(null);
    setFormOpen(true);
  };

  const togglePermission = (key) =>
    setForm((f) => ({
      ...f,
      permissions: f.permissions.includes(key)
        ? f.permissions.filter((p) => p !== key)
        : [...f.permissions, key],
    }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setFormError("Nama role wajib diisi.");
      return;
    }
    setSubmitting(true);
    setFormError(null);
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description.trim() || null,
        permissions: form.permissions,
        history_scope: form.history_scope,
      };
      if (editing) await api(`/roles/${editing.id}`, { method: "PUT", body: payload });
      else await api("/roles", { method: "POST", body: payload });
      setFormOpen(false);
      await load();
    } catch (err) {
      setFormError(err?.message || "Gagal menyimpan role.");
    } finally {
      setSubmitting(false);
    }
  };

  const remove = async () => {
    setSubmitting(true);
    setError(null);
    try {
      await api(`/roles/${confirmDelete.id}`, { method: "DELETE" });
      setConfirmDelete(null);
      await load();
    } catch (err) {
      setError(err?.message || "Gagal menghapus role.");
      setConfirmDelete(null);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Layout
      title="Master Role"
      subtitle="Hak akses per fitur"
      back={() => window.history.back()}
      actions={
        <button
          type="button"
          onClick={openCreate}
          className="flex items-center gap-1 rounded-lg bg-brand px-2.5 py-1.5 text-sm font-semibold text-white hover:bg-brand-dark"
        >
          <Icon name="plus" className="h-4 w-4" />
          Tambah
        </button>
      }
    >
      {error ? (
        <div className="mb-3">
          <ErrorNote>{error}</ErrorNote>
        </div>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-8 w-8" />
        </div>
      ) : roles.length === 0 ? (
        <EmptyState icon="shield" title="Belum ada role" />
      ) : (
        <div className="space-y-3">
          {roles.map((role) => (
            <div key={role.id} className="card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <h2 className="font-bold text-slate-900">{role.name}</h2>
                    {role.is_system ? (
                      <span className="chip bg-slate-100 text-slate-500">Bawaan</span>
                    ) : null}
                  </div>
                  <p className="mt-0.5 text-sm text-slate-500">
                    {role.description || "Tanpa deskripsi"}
                  </p>
                  <p className="mt-1 flex items-center gap-1.5 text-xs text-slate-500">
                    <Icon name="users" className="h-3.5 w-3.5" />
                    {role.user_count} user · Riwayat:{" "}
                    <strong>{SCOPE_LABEL[role.history_scope]}</strong>
                  </p>
                </div>

                <div className="flex shrink-0 gap-1.5">
                  <button type="button" className="btn-secondary btn-sm" onClick={() => openEdit(role)}>
                    <Icon name="edit" className="h-4 w-4" /> Ubah
                  </button>
                  {!role.is_system ? (
                    <button
                      type="button"
                      className="btn-sm rounded-lg border border-danger/40 px-3 font-semibold text-danger hover:bg-danger-light"
                      onClick={() => setConfirmDelete(role)}
                    >
                      Hapus
                    </button>
                  ) : null}
                </div>
              </div>

              <div className="mt-3 flex flex-wrap gap-1.5">
                {role.permissions.length ? (
                  role.permissions.map((p) => (
                    <span key={p} className="chip bg-brand-light text-brand-dark">
                      {catalog.permissions.find((x) => x.key === p)?.label || p}
                    </span>
                  ))
                ) : (
                  <span className="chip bg-slate-100 text-slate-500">
                    Tidak ada hak akses
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form role */}
      <Modal
        open={formOpen}
        title={editing ? `Ubah Role — ${editing.name}` : "Tambah Role"}
        onClose={() => setFormOpen(false)}
        wide
        footer={
          <div className="grid grid-cols-2 gap-3">
            <button type="button" className="btn-secondary" onClick={() => setFormOpen(false)} disabled={submitting}>
              Batal
            </button>
            <button type="submit" form="role-form" className="btn-primary" disabled={submitting}>
              {submitting ? <Spinner className="h-5 w-5 border-white/40 border-t-white" /> : null}
              Simpan
            </button>
          </div>
        }
      >
        <form id="role-form" onSubmit={submit} className="space-y-4">
          <div>
            <label className="label" htmlFor="role-name">Nama role</label>
            <input
              id="role-name"
              className="input input-sm"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              disabled={Boolean(editing?.is_system)}
              placeholder="cth. Admin Lokasi"
            />
          </div>

          <div>
            <label className="label" htmlFor="role-desc">Deskripsi</label>
            <input
              id="role-desc"
              className="input input-sm"
              value={form.description}
              onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            />
          </div>

          <div>
            <label className="label" htmlFor="role-scope">
              Cakupan riwayat pemeriksaan
            </label>
            <select
              id="role-scope"
              className="input input-sm"
              value={form.history_scope}
              onChange={(e) => setForm((f) => ({ ...f, history_scope: e.target.value }))}
            >
              {catalog.history_scopes.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <p className="label">Hak akses per fitur (Lampiran A)</p>
            <div className="space-y-1.5">
              {catalog.permissions.map((perm) => {
                const checked = form.permissions.includes(perm.key);
                return (
                  <label
                    key={perm.key}
                    className={`flex items-center gap-3 rounded-xl border px-3 py-2.5 transition ${
                      checked
                        ? "border-brand bg-brand-light"
                        : "border-slate-200 bg-white hover:bg-slate-50"
                    }`}
                  >
                    <input
                      type="checkbox"
                      className="h-4 w-4 rounded border-slate-300 text-brand focus:ring-brand"
                      checked={checked}
                      onChange={() => togglePermission(perm.key)}
                    />
                    <span className="text-sm font-medium text-slate-800">{perm.label}</span>
                    <span className="ml-auto font-mono text-[11px] text-slate-400">
                      {perm.key}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          {formError ? <ErrorNote>{formError}</ErrorNote> : null}
        </form>
      </Modal>

      {/* Konfirmasi hapus */}
      <Modal open={Boolean(confirmDelete)} title="Hapus role" onClose={() => setConfirmDelete(null)}>
        <div className="space-y-3 text-sm text-slate-700">
          <p>
            Role <strong>{confirmDelete?.name}</strong> akan dihapus. Role yang
            masih dipakai user tidak dapat dihapus.
          </p>
          <div className="grid grid-cols-2 gap-3">
            <button type="button" className="btn-secondary" onClick={() => setConfirmDelete(null)} disabled={submitting}>
              Batal
            </button>
            <button type="button" className="btn-danger" onClick={remove} disabled={submitting}>
              {submitting ? <Spinner className="h-5 w-5 border-white/40 border-t-white" /> : null}
              Hapus
            </button>
          </div>
        </div>
      </Modal>
    </Layout>
  );
}
