import { useCallback, useEffect, useState } from "react";
import { api, withQuery } from "../api/client";
import { useAuth } from "../context/AuthContext";
import Layout from "../components/Layout";
import Icon from "../components/Icon";
import Modal from "../components/Modal";
import { EmptyState, ErrorNote, Spinner } from "../components/Feedback";

const CONFIRM_PHRASE = "HAPUS";

function DiffList({ before, after }) {
  const keys = Array.from(
    new Set([...Object.keys(before || {}), ...Object.keys(after || {})]),
  );
  if (!keys.length) return null;

  return (
    <div className="mt-2 space-y-1 rounded-xl bg-slate-50 p-2.5">
      {keys.map((key) => {
        const prev = before?.[key];
        const next = after?.[key];
        if (JSON.stringify(prev) === JSON.stringify(next)) return null;
        return (
          <div key={key} className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="font-semibold text-slate-600">{key}:</span>
            <span className="rounded bg-danger-light px-1.5 py-0.5 font-mono text-danger-dark line-through">
              {prev === null || prev === undefined ? "—" : String(prev)}
            </span>
            <Icon name="chevron" className="h-3 w-3 text-slate-400" />
            <span className="rounded bg-success-light px-1.5 py-0.5 font-mono text-success-dark">
              {next === null || next === undefined ? "—" : String(next)}
            </span>
          </div>
        );
      })}
    </div>
  );
}

export default function AuditLog() {
  const { has } = useAuth();
  const [data, setData] = useState({ items: [], total: 0, page: 1, page_size: 25 });
  const [page, setPage] = useState(1);
  const [action, setAction] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(null);
  const [clearOpen, setClearOpen] = useState(false);
  const [phrase, setPhrase] = useState("");
  const [clearing, setClearing] = useState(false);
  const [clearError, setClearError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(
        await api(withQuery("/audit", { page, page_size: 25, action })),
      );
    } catch (err) {
      setError(err?.message || "Gagal memuat log audit.");
    } finally {
      setLoading(false);
    }
  }, [page, action]);

  useEffect(() => {
    load();
  }, [load]);

  const doClear = async () => {
    if (phrase.trim().toUpperCase() !== CONFIRM_PHRASE) {
      setClearError(`Konfirmasi salah. Ketik "${CONFIRM_PHRASE}" untuk melanjutkan.`);
      return;
    }
    setClearing(true);
    setClearError(null);
    try {
      await api("/audit", {
        method: "DELETE",
        body: { confirmation: phrase.trim() },
      });
      setClearOpen(false);
      setPhrase("");
      setPage(1);
      await load();
    } catch (err) {
      setClearError(err?.message || "Gagal menghapus log audit.");
    } finally {
      setClearing(false);
    }
  };

  const totalPages = Math.max(1, Math.ceil(data.total / data.page_size));

  return (
    <Layout
      title="Log Audit"
      subtitle={`${data.total} entri · tidak dihapus otomatis`}
      back={() => window.history.back()}
      actions={
        has("audit.clear") ? (
          <button
            type="button"
            onClick={() => {
              setPhrase("");
              setClearError(null);
              setClearOpen(true);
            }}
            className="flex items-center gap-1 rounded-lg border border-danger/40 px-2.5 py-1.5 text-sm font-semibold text-danger hover:bg-danger-light"
          >
            <Icon name="x" className="h-4 w-4" />
            Clear Log
          </button>
        ) : null
      }
    >
      <div className="card mb-4">
        <label className="label" htmlFor="action-filter">
          Filter aksi
        </label>
        <select
          id="action-filter"
          className="input input-sm"
          value={action}
          onChange={(e) => {
            setAction(e.target.value);
            setPage(1);
          }}
        >
          <option value="">Semua aksi</option>
          <option value="user.create">user.create</option>
          <option value="user.update">user.update</option>
          <option value="user.deactivate">user.deactivate</option>
          <option value="user.reset_password">user.reset_password</option>
          <option value="user.change_password">user.change_password</option>
          <option value="role.create">role.create</option>
          <option value="role.update">role.update</option>
          <option value="role.delete">role.delete</option>
          <option value="check.create">check.create</option>
          <option value="check.follow_up">check.follow_up</option>
          <option value="audit.clear">audit.clear</option>
        </select>
      </div>

      {error ? (
        <div className="mb-3">
          <ErrorNote>{error}</ErrorNote>
        </div>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-8 w-8" />
        </div>
      ) : data.items.length === 0 ? (
        <EmptyState icon="list" title="Log audit kosong" hint="Perubahan master user/role akan tercatat di sini." />
      ) : (
        <div className="space-y-2">
          {data.items.map((log) => (
            <button
              key={log.id}
              type="button"
              onClick={() => setExpanded(expanded === log.id ? null : log.id)}
              className="card block w-full !p-3.5 text-left"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="chip bg-brand-light text-brand-dark">
                      {log.action}
                    </span>
                    {log.target_type ? (
                      <span className="text-xs text-slate-500">
                        {log.target_type}
                        {log.target_id ? ` #${log.target_id}` : ""}
                      </span>
                    ) : null}
                  </div>
                  <p className="mt-1 text-sm text-slate-600">
                    oleh <strong>{log.actor_name || "Sistem"}</strong>
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-xs text-slate-500">
                    {new Date(log.created_at).toLocaleString("id-ID")}
                  </p>
                  <span className="mt-1 inline-flex items-center gap-1 text-[11px] font-semibold text-brand">
                    {expanded === log.id ? "Sembunyikan" : "Detail"}
                    <Icon name="chevron" className="h-3 w-3" />
                  </span>
                </div>
              </div>

              {expanded === log.id ? (
                <div className="mt-2 border-t border-slate-100 pt-2">
                  <DiffList before={log.before_json} after={log.after_json} />
                </div>
              ) : null}
            </button>
          ))}

          <div className="mt-4 flex items-center justify-between">
            <p className="text-xs text-slate-500">{data.total} entri</p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                className="btn-secondary btn-sm"
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                Sebelumnya
              </button>
              <span className="text-xs font-medium text-slate-600">
                {data.page} / {totalPages}
              </span>
              <button
                type="button"
                className="btn-secondary btn-sm"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                Berikutnya
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear Log (SEAL-31) — hanya Admin, dengan konfirmasi */}
      <Modal open={clearOpen} title="Clear Log Audit" onClose={() => setClearOpen(false)}>
        <div className="space-y-3 text-sm text-slate-700">
          <div className="flex items-start gap-2 rounded-xl bg-danger-light px-3 py-2.5 text-danger-dark">
            <Icon name="warning" className="mt-0.5 h-4 w-4 shrink-0" />
            <p>
              Seluruh entri log audit akan dihapus permanen dan tidak dapat
              dikembalikan. Ekspor terlebih dahulu bila diperlukan.
            </p>
          </div>

          <p>
            Ketik <strong className="font-mono">{CONFIRM_PHRASE}</strong> untuk
            melanjutkan.
          </p>
          <input
            className="input font-mono uppercase"
            value={phrase}
            onChange={(e) => setPhrase(e.target.value)}
            placeholder={CONFIRM_PHRASE}
            autoComplete="off"
          />

          {clearError ? <ErrorNote>{clearError}</ErrorNote> : null}

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              className="btn-secondary"
              onClick={() => setClearOpen(false)}
              disabled={clearing}
            >
              Batal
            </button>
            <button
              type="button"
              className="btn-danger"
              onClick={doClear}
              disabled={clearing || phrase.trim().toUpperCase() !== CONFIRM_PHRASE}
            >
              {clearing ? <Spinner className="h-5 w-5 border-white/40 border-t-white" /> : null}
              Hapus log
            </button>
          </div>
        </div>
      </Modal>
    </Layout>
  );
}
