import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { api, apiDownload, withQuery } from "../api/client";
import { useAuth } from "../context/AuthContext";
import Layout from "../components/Layout";
import Icon from "../components/Icon";
import Modal from "../components/Modal";
import { EmptyState, ErrorNote, Spinner } from "../components/Feedback";
import { RESULT_LABELS } from "../utils/matching";

const EMPTY_FILTERS = {
  date_from: "",
  date_to: "",
  result: "",
  location: "",
  q: "",
};

function ResultChip({ result }) {
  const success = result === "SUCCESS";
  return (
    <span
      className={`chip ${success ? "bg-success-light text-success-dark" : "bg-danger-light text-danger-dark"}`}
    >
      <Icon name={success ? "check" : "close"} className="h-3.5 w-3.5" strokeWidth={3} />
      {RESULT_LABELS[result] || result}
    </span>
  );
}

export default function History() {
  const { has, user } = useAuth();
  const [params, setParams] = useSearchParams();

  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [data, setData] = useState({ items: [], total: 0, page: 1, page_size: 20 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [locations, setLocations] = useState([]);

  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  const query = useMemo(
    () => ({
      ...filters,
      page,
      page_size: data.page_size,
    }),
    [filters, page, data.page_size],
  );

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api(withQuery("/checks", query));
      setData(result);
    } catch (err) {
      setError(err?.message || "Gagal memuat riwayat.");
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    api("/meta/locations")
      .then((res) => setLocations(res.locations || []))
      .catch(() => {});
  }, []);

  // ?export=1 → langsung tawarkan unduhan (dari pintasan Beranda)
  useEffect(() => {
    if (params.get("export") === "1") {
      setShowFilters(true);
      setParams({}, { replace: true });
    }
  }, [params, setParams]);

  const applyFilters = (next) => {
    setFilters(next);
    setPage(1);
  };

  const onExport = async () => {
    setExporting(true);
    setError(null);
    try {
      const { blob, filename } = await apiDownload(
        withQuery("/checks/export", filters),
      );
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch (err) {
      setError(err?.message || "Gagal mengunduh rekap.");
    } finally {
      setExporting(false);
    }
  };

  const totalPages = Math.max(1, Math.ceil(data.total / data.page_size));

  return (
    <Layout
      title="Riwayat Pemeriksaan"
      subtitle={
        user?.history_scope === "all"
          ? "Seluruh lokasi"
          : user?.history_scope === "location"
            ? `Lokasi: ${user?.location || "-"}`
            : "Milik sendiri"
      }
      actions={
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setShowFilters((v) => !v)}
            className="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100"
            aria-label="Filter"
            aria-pressed={showFilters}
          >
            <Icon name="filter" className="h-5 w-5" />
            {activeFilterCount ? (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 text-[10px] font-bold text-white">
                {activeFilterCount}
              </span>
            ) : null}
          </button>
          {has("reports.export") ? (
            <button
              type="button"
              onClick={onExport}
              disabled={exporting}
              className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 disabled:opacity-50"
              aria-label="Ekspor Excel"
            >
              {exporting ? (
                <Spinner className="h-5 w-5" />
              ) : (
                <Icon name="download" className="h-5 w-5" />
              )}
            </button>
          ) : null}
        </div>
      }
    >
      {showFilters ? (
        <div className="card mb-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label" htmlFor="date_from">
                Dari tanggal
              </label>
              <input
                id="date_from"
                type="date"
                className="input input-sm"
                value={filters.date_from}
                onChange={(e) => applyFilters({ ...filters, date_from: e.target.value })}
              />
            </div>
            <div>
              <label className="label" htmlFor="date_to">
                Sampai
              </label>
              <input
                id="date_to"
                type="date"
                className="input input-sm"
                value={filters.date_to}
                onChange={(e) => applyFilters({ ...filters, date_to: e.target.value })}
              />
            </div>
          </div>

          <div>
            <label className="label" htmlFor="result">
              Hasil
            </label>
            <select
              id="result"
              className="input input-sm"
              value={filters.result}
              onChange={(e) => applyFilters({ ...filters, result: e.target.value })}
            >
              <option value="">Semua hasil</option>
              <option value="SUCCESS">Sesuai</option>
              <option value="FAILED">Tidak Sesuai</option>
            </select>
          </div>

          {locations.length ? (
            <div>
              <label className="label" htmlFor="location">
                Lokasi
              </label>
              <select
                id="location"
                className="input input-sm"
                value={filters.location}
                onChange={(e) => applyFilters({ ...filters, location: e.target.value })}
              >
                <option value="">Semua lokasi</option>
                {locations.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>
          ) : null}

          <div>
            <label className="label" htmlFor="q">
              Pencarian
            </label>
            <div className="relative">
              <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                <Icon name="search" className="h-4 w-4" />
              </span>
              <input
                id="q"
                className="input input-sm !pl-9"
                placeholder="Nomor container, EIR, booking, atau seal"
                value={filters.q}
                onChange={(e) => applyFilters({ ...filters, q: e.target.value })}
              />
            </div>
          </div>

          <div className="flex gap-2">
            <button
              type="button"
              className="btn-secondary btn-sm flex-1"
              onClick={() => applyFilters(EMPTY_FILTERS)}
            >
              Reset
            </button>
            <button
              type="button"
              className="btn-primary btn-sm flex-1"
              onClick={() => {
                load();
                setShowFilters(false);
              }}
            >
              Terapkan
            </button>
          </div>

          {has("reports.export") ? (
            <button type="button" className="btn-secondary btn-sm w-full" onClick={onExport} disabled={exporting}>
              <Icon name="download" className="h-4 w-4" />
              {exporting ? "Menyiapkan…" : "Ekspor Excel sesuai filter ini"}
            </button>
          ) : null}
        </div>
      ) : null}

      {error ? (
        <div className="mb-3">
          <ErrorNote>{error}</ErrorNote>
        </div>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-8 w-8" />
        </div>
      ) : data.items.length === 0 ? (
        <EmptyState
          icon="history"
          title="Belum ada pemeriksaan"
          hint="Pemeriksaan yang Anda lakukan akan tampil di sini. Catatan hanya disimpan 24 jam — ekspor ke Excel bila perlu arsip jangka panjang."
        />
      ) : (
        <>
          {/* Tampilan daftar untuk layar sempit */}
          <div className="space-y-2 lg:hidden">
            {data.items.map((item) => (
              <Link
                key={item.id}
                to={`/riwayat/${item.id}`}
                className="card block !p-3.5"
              >
                <div className="mb-1.5 flex items-center justify-between gap-2">
                  <span className="text-xs font-medium text-slate-500">
                    #{item.id} ·{" "}
                    {new Date(item.checked_at).toLocaleString("id-ID")}
                  </span>
                  <ResultChip result={item.result} />
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-slate-400">
                      Seal EIR
                    </p>
                    <p className="font-mono font-bold text-slate-900">
                      {item.seal_eir_final}
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-slate-400">
                      Segel Aktual
                    </p>
                    <p className="font-mono font-bold text-slate-900">
                      {item.seal_actual_final}
                    </p>
                  </div>
                </div>
                <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
                  {item.container_no ? (
                    <span className="chip bg-slate-100 text-slate-600">
                      {item.container_no}
                    </span>
                  ) : null}
                  <span>{item.user_name}</span>
                  {item.edited_flag ? (
                    <span className="chip bg-warning-light text-warning-dark">
                      Diedit
                    </span>
                  ) : null}
                </div>
              </Link>
            ))}
          </div>

          {/* Tabel untuk layar lebar (Master data tetap nyaman di desktop) */}
          <div className="card hidden overflow-hidden !p-0 lg:block">
            <table className="table-base">
              <thead>
                <tr>
                  <th>Waktu</th>
                  <th>User</th>
                  <th>Container / EIR</th>
                  <th>Seal EIR</th>
                  <th>Segel Aktual</th>
                  <th>Hasil</th>
                  <th>Penanda</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50">
                    <td>
                      <Link
                        to={`/riwayat/${item.id}`}
                        className="font-medium text-brand hover:underline"
                      >
                        #{item.id}
                      </Link>
                      <div className="text-xs text-slate-500">
                        {new Date(item.checked_at).toLocaleString("id-ID")}
                      </div>
                    </td>
                    <td>
                      <div className="font-medium">{item.user_name}</div>
                      <div className="text-xs text-slate-500">{item.location}</div>
                    </td>
                    <td>
                      <div className="font-medium">{item.container_no || "-"}</div>
                      <div className="text-xs text-slate-500">{item.eir_no || "-"}</div>
                    </td>
                    <td className="font-mono font-semibold">{item.seal_eir_final}</td>
                    <td className="font-mono font-semibold">{item.seal_actual_final}</td>
                    <td>
                      <ResultChip result={item.result} />
                    </td>
                    <td>
                      <div className="flex flex-wrap gap-1">
                        {item.edited_flag ? (
                          <span className="chip bg-warning-light text-warning-dark">
                            Diedit
                          </span>
                        ) : null}
                        {item.near_match_flag ? (
                          <span className="chip bg-warning-light text-warning-dark">
                            Hampir sama
                          </span>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Navigasi halaman */}
          <div className="mt-4 flex items-center justify-between gap-3">
            <p className="text-xs text-slate-500">
              {data.total} pemeriksaan
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                className="btn-secondary btn-sm"
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                Sebelumnya
              </button>
              <span className="text-xs font-medium text-slate-600">
                {data.page} / {totalPages}
              </span>
              <button
                type="button"
                className="btn-secondary btn-sm"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                Berikutnya
              </button>
            </div>
          </div>
        </>
      )}

      <Modal
        open={exporting}
        title="Menyiapkan rekap"
        onClose={() => {}}
        dismissible={false}
      >
        <div className="flex flex-col items-center gap-3 py-6">
          <Spinner className="h-8 w-8" />
          <p className="text-sm text-slate-600">
            Mengunduh data sesuai filter yang aktif…
          </p>
        </div>
      </Modal>
    </Layout>
  );
}
