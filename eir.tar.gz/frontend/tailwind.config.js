/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // Kontras tinggi agar terbaca di bawah sinar matahari (Bagian 7 PRD)
        success: {
          DEFAULT: "#15803D",
          dark: "#14532D",
          light: "#DCFCE7",
        },
        danger: {
          DEFAULT: "#B91C1C",
          dark: "#7F1D1D",
          light: "#FEE2E2",
        },
        warning: {
          DEFAULT: "#A16207",
          dark: "#713F12",
          light: "#FEF9C3",
        },
        brand: {
          DEFAULT: "#1D4ED8",
          dark: "#1E3A8A",
          light: "#DBEAFE",
        },
      },
      minHeight: {
        screen: "100dvh",
      },
      boxShadow: {
        card: "0 1px 3px rgba(15, 23, 42, 0.12), 0 1px 2px rgba(15, 23, 42, 0.06)",
      },
    },
  },
  plugins: [],
};
