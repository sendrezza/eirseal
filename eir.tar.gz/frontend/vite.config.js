import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Target backend: lewat reverse proxy Nginx ("" = same origin) saat produksi,
// atau ke API lokal saat `npm run dev`.
const target = process.env.VITE_API_PROXY || "http://localhost:80";

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    proxy: {
      "/api": {
        target,
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: "dist",
    sourcemap: false,
    chunkSizeWarningLimit: 900,
  },
});
