/**
 * Pembuat ikon PWA (tanpa dependensi eksternal).
 *
 *   node scripts/gen-icons.mjs
 *
 * Menghasilkan icon-192.png, icon-512.png, dan icon-maskable-512.png berisi
 * tanda centang putih di atas kotak biru membulat.
 */

import { deflateSync } from "node:zlib";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const OUT_DIR = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "icons");

/* ---------- Penulisan PNG minimal (RGBA, tanpa palet) ---------- */

let CRC_TABLE = null;
function crc32(buf) {
  if (!CRC_TABLE) {
    CRC_TABLE = new Int32Array(256);
    for (let n = 0; n < 256; n += 1) {
      let c = n;
      for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      CRC_TABLE[n] = c;
    }
  }
  let c = -1;
  for (let i = 0; i < buf.length; i += 1) {
    c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, "ascii");
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([length, typeBuf, data, crcBuf]);
}

function encodePng(width, height, pixelAt) {
  const stride = width * 4 + 1;
  const raw = Buffer.alloc(stride * height);
  let offset = 0;
  for (let y = 0; y < height; y += 1) {
    raw[offset] = 0; // filter: None
    offset += 1;
    for (let x = 0; x < width; x += 1) {
      const [r, g, b, a] = pixelAt(x, y);
      raw[offset] = r;
      raw[offset + 1] = g;
      raw[offset + 2] = b;
      raw[offset + 3] = a;
      offset += 4;
    }
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type: RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr),
    chunk("IDAT", deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

/* ---------- Geometri ---------- */

const BLUE = [29, 78, 216];
const WHITE = [255, 255, 255];

// Jarak ke kotak membulat (SDF), dalam satuan ternormalisasi
function sdRoundBox(px, py, half, radius) {
  const qx = Math.abs(px) - half + radius;
  const qy = Math.abs(py) - half + radius;
  return (
    Math.min(Math.max(qx, qy), 0) +
    Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) -
    radius
  );
}

// Jarak dari titik ke segmen
function distToSegment(px, py, ax, ay, bx, by) {
  const dx = bx - ax;
  const dy = by - ay;
  const lenSq = dx * dx + dy * dy || 1;
  let t = ((px - ax) * dx + (py - ay) * dy) / lenSq;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

const CHECK_A = [0.29, 0.52];
const CHECK_B = [0.45, 0.68];
const CHECK_C = [0.73, 0.33];

function renderIcon(size, { inset = 0.08, radius = 0.17 }) {
  const half = 0.5 - inset;
  return encodePng(size, size, (x, y) => {
    const u = (x + 0.5) / size;
    const v = (y + 0.5) / size;
    const px = u - 0.5;
    const py = v - 0.5;

    // Alpha kotak membulat (anti-alias 1 piksel)
    const dBox = sdRoundBox(px, py, half, radius);
    const boxAlpha = Math.max(0, Math.min(1, 0.5 - dBox * size));
    if (boxAlpha <= 0) return [0, 0, 0, 0];

    // Alpha tanda centang
    const thickness = 0.055;
    const d1 = distToSegment(u, v, CHECK_A[0], CHECK_A[1], CHECK_B[0], CHECK_B[1]);
    const d2 = distToSegment(u, v, CHECK_B[0], CHECK_B[1], CHECK_C[0], CHECK_C[1]);
    const dCheck = Math.min(d1, d2);
    const checkAlpha = Math.max(0, Math.min(1, (thickness - dCheck) * size * 1.2));

    // Komposit: biru sebagai dasar, putih di atasnya
    const k = checkAlpha;
    const r = Math.round(BLUE[0] + (WHITE[0] - BLUE[0]) * k);
    const g = Math.round(BLUE[1] + (WHITE[1] - BLUE[1]) * k);
    const b = Math.round(BLUE[2] + (WHITE[2] - BLUE[2]) * k);
    return [r, g, b, Math.round(boxAlpha * 255)];
  });
}

mkdirSync(OUT_DIR, { recursive: true });

const targets = [
  ["icon-192.png", 192, { inset: 0.06, radius: 0.2 }],
  ["icon-512.png", 512, { inset: 0.05, radius: 0.2 }],
  // Maskable: logo dijaga agar tetap berada di zona aman 80%
  ["icon-maskable-512.png", 512, { inset: 0.16, radius: 0.02 }],
];

for (const [name, size, opts] of targets) {
  const buffer = renderIcon(size, opts);
  writeFileSync(join(OUT_DIR, name), buffer);
  console.log(`✓ ${name} (${size}x${size}, ${buffer.length} byte)`);
}
